@extends('layouts.master')
@section('main_content')

<!--================= About Us Start Here =================-->
<section class="about-us-area pt-120 pb-75 pt-md-60 pb-md-15 pt-xs-50 pb-xs-10">
    <div class="container">
        <div class="image-section">
            <div class="row">
                <div class="col-lg-6">
                    <div class="image-1">
                        <img src="{{ asset('frontend/assets/images/about/design1.jpg') }}" alt="img">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="image-2">
                        <img src="{{ asset('frontend/assets/images/about/design2.jpg') }}" alt="img">
                    </div>
                </div>
            </div>
            <div class="section-title">
                <div class="title-inner">
                    <div class="wrapper">
                        <div class="sub-content">
                            <img class="line-1" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="">
                            <span class="sub-text">Since From 2021</span>
                            <img class="line-2" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="">
                        </div>
                        <h2 class="title">About Our Story</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="section-text">
            <div class="row">
                <div class="col-lg-4">
                    <h3>Our Mission</h3>
                    <p class="description">At 4J Traders, we offer sophisticated, functional, and timeless furniture that enhances both home and office spaces. Our mission is to be the top choice for corporates, home office enthusiasts, and designers in Bangladesh, providing pieces that reflect the unique style and needs of our customers. We are committed to innovation, sustainability, and eco-friendly practices, ensuring our designs meet high aesthetic standards while contributing to a greener future.</p>
                </div>
                <div class="col-lg-4">
                    <h3>Our Vision</h3>
                    <p class="description">At 4J Traders, our vision is to redefine elegance in Bangladesh’s furniture industry by setting new standards for design, quality, and customer satisfaction. We aim to be the go-to destination for corporates, home office enthusiasts, and interior designers seeking stylish, functional furnishings. Beyond selling furniture, we curate experiences that turn spaces into expressions of individuality, while building lasting relationships with our customers through personalized service and tailored solutions.</p>
                </div>
                <div class="col-lg-4">
                    <div class="service-list">
                        <ul>
                            <H4>Products</H4>
                            <li><a href="#">Office Chair</a></li>
                            <li><a href="#">Office Desk</a></li>
                            <li><a href="#">Sofa</a></li>
                            <h4>Services</h4>
                            <li><a href="#">Office Interior</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================= About Us End Here =================-->

<!--================= Team Area Start Here =================-->
<div class="team-area d-none">
    <div class="container">
        <div class="sub-content">
            <img class="line-1" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="">
            <span class="sub-text">Team</span>
            <img class="line-2" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="">
        </div>
        <h2 class="title">Meet With Team</h2>
        <div class="slider-div">
            <div class="swiper rts-cmmnSlider-over2" data-swiper="pagination">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="team-wraper">
                            <div class="team-thumb">
                                <a href="#"><img src="{{ asset('frontend/assets/images/about/1.jpg') }}" alt="collection-image"></a>
                            </div>
                            <div class="team-content">
                                <h3>
                                    <a href="#" class="item-catagory-box">Richard John</a>
                                </h3>
                                <h6>Founder</h6>
                                <div class="footer__social">
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-facebook-f"></i></a>
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-twitter"></i></a>
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="team-wraper">
                            <div class="team-thumb">
                                <a href="#"><img src="{{ asset('frontend/assets/images/about/2.jpg') }}" alt="collection-image"></a>
                            </div>
                            <div class="team-content">
                                <h3>
                                    <a href="#" class="item-catagory-box">Larry Mord</a>
                                </h3>
                                <h6>Founder</h6>
                                <div class="footer__social">
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-facebook-f"></i></a>
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-twitter"></i></a>
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="team-wraper">
                            <div class="team-thumb">
                                <a href="#"><img src="{{ asset('frontend/assets/images/about/3.jpg') }}"
                                        alt="collection-image"></a>
                            </div>
                            <div class="team-content">
                                <h3>
                                    <a href="#" class="item-catagory-box">Tom Ashik</a>
                                </h3>
                                <h6>Founder</h6>
                                <div class="footer__social">
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-facebook-f"></i></a>
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-twitter"></i></a>
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="team-wraper">
                            <div class="team-thumb">
                                <a href="#"><img src="{{ asset('frontend/assets/images/about/4.jpg') }}" alt="collection-image"></a>
                            </div>
                            <div class="team-content">
                                <h3>
                                    <a href="#" class="item-catagory-box">John Milo</a>
                                </h3>
                                <h6>Founder</h6>
                                <div class="footer__social">
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-facebook-f"></i></a>
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-twitter"></i></a>
                                    <a class="footer-icon" href="#"><i aria-hidden="true"
                                            class="fab fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--================= Team Area End Here =================-->

<!--================= Feature Area Start Here =================-->
<div class="features-area">
    <div class="container">
        <div class="features-1">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="image-section">
                        <a href="#"><img src="{{ asset('frontend/assets/images/md1.png') }}" alt="features-1"></a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="section-content">
                        <div class="sub-content">
                            <img class="line-1" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="">
                            <span class="sub-text">Our Managing Director</span>
                            <img class="line-2" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="">
                        </div>
                        <h2 class="title">MD JASHIM UDDIN</h2>
                        <p class="description">At 4J Traders, our mission is to redefine the
                            essence of living and working spaces by
                            providing an exclusive range of furniture that
                            seamlessly blends sophistication, functionality,
                            and ageless design. Committed to elevating
                            the aesthetic appeal and comfort of interiors,
                            we strive to be the foremost choice for
                            corporates, home office enthusiasts, and
                            interior designers in Bangladesh. We aspire to
                            create pieces that not only enhance the
                            ambiance of spaces but also reflect the unique
                            personality and aspirations of our discerning
                            customers.
                            Dedicated to innovation and sustainability, we
                            continually explore cutting-edge designs and
                            eco-friendly practices, ensuring that our
                            furniture not only meets the highest standards
                            of aesthetics but also contributes to a greener
                            and more responsible future.</p>
                        <div class="section-button">
                            <a href="#">Get In Touch</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="features-2 d-none">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="section-content">
                        <div class="sub-content">
                            <img class="line-1" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="">
                            <span class="sub-text">Features #01</span>
                            <img class="line-2" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="">
                        </div>
                        <h2 class="title">Our Vision       </h2>
                        <p class="description">At 4J Traders, our vision is to be the epitome of elegance in the furniture industry in
                            Bangladesh by setting new benchmarks for design innovation, quality, and customer
                            satisfaction. We will cater to the distinct needs of corporates, home office enthusiasts, and
                            interior designers, and we envision becoming the go-to destination for those who seek
                            elegant furnishings that will also have functionality.
                            Our vision extends beyond just selling furniture; we aim to curate complete experiences,
                            cultivating an environment where every piece tells a story and every space becomes a
                            canvas of individual expression. We also aspire to foster lasting relationships with our
                            customers, offering personalized service and solutions catering to their unique tastes and
                            requirements.</p>
                        <div class="section-button">
                            <a href="#">Contact With Us</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="image-section">
                        <a href="#"><img src="{{ asset('frontend/assets/images/about/features-2.jpg') }}" alt="#"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--================= Feature Area End Here =================-->

@endsection