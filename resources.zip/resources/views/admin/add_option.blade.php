
@extends('admin.master')
@section('main_content')    

  <div class="page-content container container-plus">
    <div class="page-header pb-2">
      <h1 class="page-title text-primary-d2 text-150">
        Add Options     
      </h1> 
      <a href="/options"class="btn btn-default px-3 text-95 radius-round border-2 brc-black-tp10 float-left">
        <i class="fa fa-list mr-1"></i>
        <span class="d-sm-none d-md-inline">All</span> Options
      </a>
    </div>   


    <div class="row-md-3">
      <div class="col-12">
        <div class="card dcard">
          <div class="card-body px-1 px-md-3">                                   
            <div role="main" class="main-content">         
              <div class="page-content container container-plus">               

                <form action="save-option" method="post" enctype="multipart/form-data">
                  @csrf
                    <div class="row">                      
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="">Title</label>
                          <input type="text" class="form-control" name="title" id="" placeholder="Title here" required="" autofocus />
                        </div>  
                      </div>

                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="">Sub Title</label>
                          <input type="text" class="form-control" name="sub_title" id="" placeholder="Sub title here" required="" />
                        </div>  
                      </div>
                      
                      <div class="col-md-12">
                        <div class="form-group">
                          <label for="">Description</label>
                          <textarea id="" name="description" class="form-control" rows="3"></textarea>   
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                            <label for="image">Image</label>
                            <input type="file" class="" name="image" id="image" accept="image/*" required="" />
                        </div>  
                    </div>
                    </div>
                  <button type="submit" class="btn btn-primary">Submit</button>
                  <a href="add-option" class="btn btn-default">Cancel</a>
                </form>
              </div>
            </div>    
          </div>
        </div>           
      </div>
    </div>
  </div>
@endsection