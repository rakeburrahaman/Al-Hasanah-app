
@extends('admin.master')
@section('main_content')    

  <div class="page-content container container-plus">
    <div class="page-header pb-2">
      <h1 class="page-title text-primary-d2 text-150">
        Update Case Study     
      </h1> 
      <a href="case-studies"class="btn btn-default px-3 text-95 radius-round border-2 brc-black-tp10 float-left">
        <i class="fa fa-list mr-1"></i>
        <span class="d-sm-none d-md-inline">All</span> Case Study
      </a>
    </div>   


    <div class="row-md-3">
      <div class="col-12">
        <div class="card dcard">
          <div class="card-body px-1 px-md-3">                                   
            <div role="main" class="main-content">         
              <div class="page-content container container-plus">               

                <form action="update_case_study" method="post" enctype="multipart/form-data">
                  @csrf
                 
                  <div class="row">

                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Name</label>
                        <select class="form-control ss" name="customer_id">
                          <?php                            
                            $collection=DB::table('customers')
                                ->where('active','on')
                                ->where('client_id', session('client_id')) 
                                ->orderBy('id','desc')
                                ->get();                                
                            ?>
                            @foreach ($collection as $item)
                              <option value="{{$item->id}}">{{$item->title}} - {{$item->mobile}}</option>
                           @endforeach
                 
                        </select>
                      </div>  
                    </div>
                 
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Age</label>
                        <input type="text" class="form-control" name="age_" 
                        placeholder="Age Here" value="{{ $data->age_ }}">
                      </div> 
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Gender</label>
                        <select class="form-control ss" name="gender" value="{{ $data->gender }}"  >
                          <option value="">Gender</option>
                            <option value="">Male</option>
                            <option value="">Female</option>
                            <option value="">Others</option>
                        </select>
                      </div>  
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Reference No</label>
                        <input type="text" class="form-control" name="reference_no" required="" value="{{ $data->reference_no }}">
                      </div>  
                    </div>

                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Date</label>
                        <input type="date" name="date" class="form-control" id="date" value="{{ $data->date }}">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Symptoms</label>
                        <input type="text" class="form-control" name="symptoms" value="{{ $data->symptoms }}" /> 
                      </div>  
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Diabetes Days</label>
                        <input type="text" class="form-control" name="diabetes_days" id="sourceCode"  value="{{ $data->diabetes_days }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Previous Treatment</label>
                        <input type="text" class="form-control" name="previous_treatment" id=""  value="{{ $data->previous_treatment }}" /> 
                      </div>  
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Monthly Expenses</label>
                        <input type="text" class="form-control" name="monthly_expenses"  value="{{ $data->monthly_expenses }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Height</label>
                        <input type="text" class="form-control" name="height" id=""  value="{{ $data->height }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Weight</label>
                        <input type="text" class="form-control" name="weight" id=""  value="{{ $data->weight }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Extra Weight</label>
                        <input type="text" class="form-control" name="extra_weight" id=""  value="{{ $data->extra_weight }}" /> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">BMI</label>
                        <input type="text" class="form-control" name="bmi" id="" value="{{ $data->bmi }}"> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Hip</label>
                        <input type="text" class="form-control" name="hip" id=""value="{{ $data->hip }}"> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Waist</label>
                        <input type="text" class="form-control" name="waist" id="" value="{{ $data->waist }}"> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Temperature</label>
                        <input type="text" class="form-control" name="temperature" id="" value="{{ $data->temperature }}"> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Pulse Rate</label>
                        <input type="text" class="form-control" name="pulse_rate" id="" value="{{ $data->pulse_rate }}"> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Blood Pressure</label>
                        <input type="text" class="form-control" name="blood_pressure" id="" value="{{ $data->blood_pressure }}"> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Lying Down</label>
                        <input type="text" class="form-control" name="lying_down" id="" value="{{ $data->lying_down }}"> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">While Standing</label>
                        <input type="text" class="form-control" name="while_standing" id="" value="{{ $data->while_standing }}"> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Heart</label>
                        <input type="text" class="form-control" name="heart" id="" value="{{ $data->heart }}"/> 
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Lungs</label>
                        <input type="text" class="form-control" name="lungs" id="" value="{{ $data->lungs }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Liver</label>
                        <input type="text" class="form-control" name="liver" id="" value="{{ $data->liver }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Spleen</label>
                        <input type="text" class="form-control" name="spleen" id="" value="{{ $data->spleen }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Nervous System</label>
                        <input type="text" class="form-control" name="nervous_system" id=""  value="{{ $data->nervous_system }}"/>
                      </div>  
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Power of Vision</label>
                        <input type="text" class="form-control" name="power_of_vision" id="" value="{{ $data->power_of_vision }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Right Eye</label>
                        <input type="text" class="form-control" name="right_eye" id="" value="{{ $data->right_eye }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label for="">Left Eye</label>
                        <input type="text" class="form-control" name="left_eye" id="" value="{{ $data->left_eye }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Leg Blood Circulation</label>
                        <input type="text" class="form-control" name="leg_blood_circulation" id="" value="{{ $data->leg_blood_circulation }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Allergy to Medicine</label>
                        <input type="text" class="form-control" name="allergy_to_medicine" id="" value="{{ $data->allergy_to_medicine }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Fundoscopic Test</label>
                        <input type="text" class="form-control" name="fundoscopic_test" id="" value="{{ $data->fundoscopic_test }}"/> 
                      </div>  
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="">Others</label>
                        <input type="text" class="form-control" name="others" id="" value="{{ $data->others }}"/> 
                      </div>  
                    </div>

                  </div>


                   
                  <input type="hidden" name="id" value="{{$data->id}}">
                  <button type="submit" class="btn btn-primary">Update</button>
                  <a href="add-lead" class="btn btn-default">Cancel</a>
                </form>
              </div>
            </div>    
          </div>
        </div>           
      </div>
    </div>
  </div>
@endsection