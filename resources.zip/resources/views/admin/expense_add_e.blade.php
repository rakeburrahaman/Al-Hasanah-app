
@extends('admin.master')
@section('main_content')    

  <div class="page-content container container-plus">
    <div class="page-header pb-2">
      <h1 class="page-title text-primary-d2 text-150">
        New Expense     
      </h1> 
      <a href="expenses"class="btn btn-default px-3 text-95 radius-round border-2 brc-black-tp10 float-left">
        <i class="fa fa-plus mr-1"></i>
        <span class="d-sm-none d-md-inline">All</span> Expenses
      </a>
    </div>   


    <div class="row mt-3">
      <div class="col-12">
        <div class="card dcard">
          <div class="card-body px-1 px-md-3">                                   
            <div role="main" class="main-content">         
              <div class="page-content container container-plus">               

                <form action="save_expense" method="post" enctype="multipart/form-data">
                  @csrf
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Expense Particular</label>
                        <input type="text" name="title" class="form-control" id=""  placeholder="Enter particular here">
                      </div>  
                    </div>  
                    
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Date</label>
                        <input type="date" name="date" class="form-control" id="date"
                        value="<?php echo date('Y-m-d'); ?>">
                      </div> 
                    </div>          
                  </div>

                  <div class="row"> 
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Expense Type</label>
                         <select class="form-control select2-single" name="expense_type" id="expenseType" required>  
                            @include('admin._expense_type')
                        </select>
                      </div>      
                    </div> 

                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Expensed By</label>                    
                        <input type="text" name="expensed_by" class="form-control" required  value="Manager">
                      </div>     
                    </div>

                    <div class="col-md-6" id="investment" style="display: none">
                      <div class="form-group">
                        <label for="" style="display: block; width:100%">Select Investment</label>                    
                            <select class="form-control select2-single" name="investment_id" style="display: block; width:100%">  
                              <option value="">-- Select Investment --</option> 
                              <?php                            
                                  $investments = DB::table('investments')
                                          ->where('client_id', session('client_id'))
                                          ->where('active', 'on')
                                          ->orderBy('id','desc')
                                          ->get();
                              ?> 
                                @foreach($investments as $item)
                                <option value="{{$item->id}}">{{$item->title}}</option>
                                @endforeach  
                            </select>
                      </div>        
                    </div> 

                  </div> 

                 

                  
                  <div class="row">                     
                    <div class="col-md-6" id="employee" style="display: none">
                      <div class="form-group">
                        <label for="" style="display: block; width:100%">Select Employee</label>                    
                            <select class="form-control select2-single" name="employee_id" style="display: block; width:100%">  
                              <option value="">-- Select Employee --</option> 
                              <?php                            
                                  $employees = DB::table('hr_employees')
                                          ->where('client_id', session('client_id'))
                                          ->where('active', 'on')
                                          ->orderBy('id','desc')
                                          ->get();
                              ?>
                                @foreach($employees as $item)
                                <option value="{{$item->id}}">{{$item->name}}</option>
                                @endforeach  
                            </select>
                      </div>        
                    </div>
                                             
                    <div class="col-md-6" id="purchaseVoucher" style="display: none">
                      <div class="form-group">
                        <label for="">Purchase Voucher</label>
                        <select class="form-control select2-single" name="purchase_id" style="display: block; width:100%">  
                          <option value="">-- Select Purchase Voucher --</option>                       
                          <?php                            
                             $purchases = DB::table('purchases')
                                      ->where('client_id', session('client_id'))
                                      ->where('active', 'on')
                                      ->orderBy('id','desc')
                                      ->get();
                             ?>
                            @foreach($purchases as $item) 
                            <option value="{{$item->id}}">{{$item->title}}</option>
                            @endforeach  
                        </select>
                      </div>        
                    </div>                                                
                  </div>  
                  
                  <div class="row" id="companyData" style="display: none">                     
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="" style="display: block; width:100%">Select Product</label>                    
                            <select class="form-control select2-single" name="product_id" style="display: block; width:100%">  
                              <option value="">-- Select Product --</option> 
                                <?php                            
                                 $products=DB::table('products')
                                 ->where('product_type', 'Product')
                                 ->where('client_id', session('client_id'))
                                 ->where('active', 'on')
                                 ->orderBy('name','asc')
                                 ->get();?>
                                @foreach($products as $item) 
                                <option value="{{$item->id}}">{{$item->name}}</option>
                                @endforeach  
                            </select>
                      </div>        
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Company Name</label>
                        <select class="form-control select2-single" name="company_id" style="display: block; width:100%">  
                          <option value="">-- Select Company --</option>                       
                          <?php                            
                             $companies=DB::table('companies')->where('client_id', session('client_id'))->where('active', 'on')->orderBy('title','asc')->get();
                             ?>
                            @foreach($companies as $item) 
                            <option value="{{$item->id}}">{{$item->title}}</option>
                            @endforeach  
                        </select>
                      </div>        
                    </div>                           
                    <div class="col-md-6" id="purchaseVoucher" style="display: none">
                      <div class="form-group">
                        <label for="">Purchase Voucher</label>
                        <select class="form-control select2-single" name="purchase_id" style="display: block; width:100%">  
                          <option value="">-- Select Purchase Voucher --</option>                       
                          <?php                            
                             $purchases = DB::table('purchases')
                                      ->where('client_id', session('client_id'))
                                      ->where('active', 'on')
                                      ->orderBy('id','desc')
                                      ->get();
                             ?>
                            @foreach($purchases as $item) 
                            <option value="{{$item->id}}">{{$item->title}}</option>
                            @endforeach  
                        </select>
                      </div>        
                    </div>                                                
                  </div>     
                  <div class="row" id="partsData" style="display: none">                     
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="" style="display: block; width:100%">Select Ex No</label>                    
                            <select class="form-control select2-single" name="equipement_id" style="display: block; width:100%">  
                              <option value="">-- Select Ex No --</option> 
                                <?php                            
                                 $products=DB::table('products')
                                 ->where('product_type', 'Service')
                                 ->where('client_id', session('client_id'))
                                 ->where('active', 'on')
                                 ->orderBy('name','asc')
                                 ->get();?>
                                @foreach($products as $item) 
                                <option value="{{$item->id}}">{{$item->name}}</option>
                                @endforeach  
                            </select>
                      </div>        
                    </div>                                     
                                                             
                  </div> 

                  <div class="row">
                  <div class="col-md-6">
                      <label class="payment_details" style="font-weight: bold; border-bottom: 1px solid #ddd; display: block">Payment Methods(Source):</label>
                      <div class="row">
                        {{-- cash payment --}}
                        <div class="col-md-2">
                          <label for="" class="payment_details">Cash:</label>
                        </div>
                        <div class="col-md-6"></div>
                        <div class="col-md-4">
                          <input type="text" name="payment_cash" id="payment_cash" class="form-control payment_details tr" placeholder="0.00">
                        </div>
                        {{-- cash payment --}}
                      </div>
                      <div class="row mt-2">
                         {{-- bank payment --}}
                        <div class="col-md-2">
                          <label for="" class="payment_details">Bank:</label>
                        </div>
                        <div class="col-md-6">
                          <div id="bank_details">
                            <div class="form-group">
                                <select class="form-control payment_details ss" name="bank_id_general" style="margin-top: -15px; float:left;margin-bottom:5px; margin-right: 5%">
                                  <option value="">Select bank</option>
                                  @php
                                        $banks = DB::table('banks')
                                            ->where('client_id',session('client_id'))
                                            ->where('banking_type', '!=', 'Mobile Banking')
                                            ->orderBy('title','asc')
                                            ->get();  
                                        $mobile_banking = DB::table('banks')
                                          ->where('client_id',session('client_id'))
                                          ->where('banking_type', 'Mobile Banking')
                                          ->orderBy('title','asc')
                                          ->get();     
                                  @endphp   
                                  @foreach ($banks as $bank)
                                    <option value="{{$bank->id}}">{{$bank->title}} - A/C No-{{$bank->ac_no}}</option>
                                  @endforeach 
                                </select> 
                            </div> 
                          </div>
                        </div>
                        <div class="col-md-4">
                          <input type="text" name="payment_bank" id="payment_bank" class="form-control payment_details tr" placeholder="0.00">
                        </div> 
                        {{-- bank payment --}}
                      </div>
                      <div class="row">
                         {{-- bkash payment // Mobile Financial Service --}}
                        <div class="col-md-2">
                          <label for="" class="payment_details">MFS:</label> 
                        </div> 
                        <div class="col-md-6">
                          <div id="bank_details">
                            <div class="form-group">
                                <select class="form-control payment_details ss" name="bank_id_mfs" style="margin-top: -15px; float:left;margin-bottom:5px; margin-right: 5%">
                                  {{-- <option value="">Select mobile banking</option> --}}
                                  @foreach ($mobile_banking as $bank)
                                    <option value="{{$bank->id}}">{{$bank->title}}-{{$bank->ac_no}}</option>
                                  @endforeach 
                                </select> 
                            </div>
                          </div>
                        </div>
                        <div class="col-md-4"> 
                          <input type="text" name="payment_mfs" id="payment_mfs" class="form-control payment_details tr"  placeholder="0.00">
                          <p class="payment_details" style="text-align: right; font-weight: 600">Total: <span id="totalPayment">0.00</span> </p>
                          <input type="hidden" name="amount" id="amount">
                        </div>
                        {{-- bkash payment --}}
                    
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="row">
                        {{-- <div class="col-md-12 d-none">
                          <div class="form-group">
                            <label for="">Amount</label>
                            <input type="text" name="amount" class="form-control" id="amount" required  placeholder="Enter amount here">
                          </div>  
                        </div> --}}

                        <div class="col-md-12">
                          <div class="form-group">
                            <label for="">Voucher No</label>
                            <input type="text" name="boucher_no" class="form-control" id=""  placeholder="Enter boucher number">
                          </div>      
                        </div>
                        <div class="col-md-12">
                          <div class="form-group">
                            <label for="">Reference</label>
                            <input type="text" name="reference" class="form-control" id=""  placeholder="Enter reference name">
                          </div>      
                        </div>
                      </div>          
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Description</label>
                        <textarea id="summernote1" name="description" class="form-control" rows="1"></textarea>  
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Notes</label>
                        <textarea name="notes" class="form-control" rows="1"></textarea>  
                      </div>       
                    </div>
                  </div>

                  
                          

                  <div class="form-group">
                    <label for="">Image: </label>
                    <img id="uploadPreview" style="width: 200px; height: 150px; display:none" />
                    <input id="uploadImage"  type="file" name="image" onchange="PreviewImage();" />

                    <p class="d-none">NB: Best image resolutions -> [slider: 1200px*500px] [featured: 260px*640px] </p>
                  </div>

                  <div class="form-group">                    
                    <label class="form-check-label" for="exampleCheck1">
                     Active
                    </label>
                    <input type="checkbox" name="active" checked class="form-check-input" id="exampleCheck1">
                  </div>
                  <br>
                  <button type="submit" class="btn btn-primary">Submit</button>
                  <button type="button" class="btn btn-default">Cancel</button>
                </form>
                
             </div>
            </div>
          </div>
        </div>           
      </div>
    </div>

  </div>

  <script>
    $(document).ready(function() {  
      $(document).on('change', '.stock_type', function(){  
          //var row_id = $(this).parent().parent().parent().attr('id').split('_').pop();
          
          var storeType = $(this).val();
          //console.log(row_id);
          $.ajax({
            url: "find_store",
            data: {
              _token: '{{csrf_token()}}',
              storeType: storeType
            },
            type: 'POST',
            success: function (response) {
                  if(response.total>0){
                      $('#storeID').empty();
                      $('#storeID').focus;
                      $('#storeID').append('<option value="">-- Select one --</option>'); 
                      $.each(response.data, function(key, value){
                          $('select[id="storeID"]').append('<option value="'+ value.id +'">' + value.title+ '</option>');
                      });
                  }else{
                    $('#storeID').empty();
                  }       
            }
          });
         
      });  

      $("#unitPrice").change(function () {       
        var unitPrice = $(this).val();
        console.log(unitPrice);
        var new_amount = $('#quantity').val() * unitPrice;
        $("#totalPrice").val(new_amount);
      });
      $("#quantity").change(function () {       
        var quantity = $(this).val();
        console.log(quantity);
        var new_amount = $('#unitPrice').val() * quantity;
        $("#totalPrice").val(new_amount);
      });

      $(document).on('change', '#expenseType', function () {       
        var type = $(this).val();
        if(type == 'Product Purchase'){
          $("#companyData").show();
          $("#purchaseVoucher").show();
          $("#partsData").hide();
        }
        else if(type == 'Ex Expense'){
          $("#partsData").show();
          $("#purchaseVoucher").hide();
          $("#companyData").hide();
        }
        else if(type == 'Investment Return'){
          $("#investment").show();
          $("#bankAccount").hide();
          $("#purchaseVoucher").hide();
          $("#companyData").hide();
        }
        else if(type == 'Salary Pay'){
          $("#employee").show();
          $("#purchaseVoucher").hide();
          $("#companyData").hide();
          $("#partsData").hide();
        } 
        else if(type == 'Advance Payment'){
          $("#companyData").show();
          $("#purchaseVoucher").hide();
          $("#partsData").hide();
        }
        else{
          $("#companyData").hide();
          $("#purchaseVoucher").hide();
          $("#partsData").hide();
        }       
      });

      function updateTotalPayment() {
      var payment_cash = $('#payment_cash').val();
      var payment_bank = $('#payment_bank').val();
      var payment_mfs =  $('#payment_mfs').val();

      if(payment_cash == null || payment_cash == ''){ payment_cash = 0; }
      if(payment_bank == null || payment_bank == ''){ payment_bank = 0; }
      if(payment_mfs == null || payment_mfs == ''){ payment_mfs = 0; }

      var totalPayment = parseInt(payment_cash) + parseInt(payment_bank) + parseInt(payment_mfs);    

      console.log(payment_cash);
      console.log(payment_bank);
      console.log(payment_mfs);
      console.log(totalPayment);
      $("input#amount").val(totalPayment);
      $("#totalPayment").text(totalPayment);
    }

    $(document).on('change', '#payment_cash', function () {
      updateTotalPayment();
    }); 
    $(document).on('change', '#payment_bank', function () {
      updateTotalPayment();
    });
    $(document).on('change', '#payment_mfs', function () {
      updateTotalPayment();
    });

      $(document).on('change', '#paymentMethod', function () {       
            var payment_method = $(this).val();
            
            if(payment_method == 'Bank'){
                $("#bankAccount").show();
                $("#MFS").hide();
                $("#bankAcc").hide();
            } 
            else if(payment_method == 'MFS'){
                $("#MFS").show();
                $("#bankAccount").hide();
                $("#bankAcc").hide();
            }
            else{
                $("#bankAccount").hide();
                $("#MFS").hide();
                $("#bankAcc").hide();
            }       
        });



    });
  </script>
 
@endsection