
@extends('layouts.master')
@section('main_content')
	<section class="page-header">
		<div class="page-header__bg" style="background-image: url('{{ asset('frontend/assets/images/about.png') }}');"></div><!-- /.page-header__bg -->
		<div class="container">
			<div class="page-header__content">
				<h2 class="page-header__title">Blog Details </h2>
				<ul class="cherito-breadcrumb list-unstyled">
					<li><a href="/">Home</a></li>
					<li><span>Our Blog</span></li>
					<li><span>Blog Details </span></li>
				</ul><!-- /.cherito-breadcrumb list-unstyled -->
			</div><!-- /.page-header__content -->
		</div><!-- /.container -->
	</section><!-- /.page-header -->

	<section class="blog-details-page section-space">
		<div class="container">

			
			<div class="row gutter-y-60">
				<div class="col-xl-8 col-lg-7">
					<div class="blog-details">
						<div class="blog-card-seven">
							<div class="blog-card-seven__image wow fadeInUp" data-wow-duration="1500ms">
								<img src="{{ URL::asset('storage/app/public/'.$data->image.'')}}" alt="{{$data->title}}">

								<div class="blog-card-seven__date d-none">
									<span class="blog-card-seven__date__day">08</span>
									<span class="blog-card-seven__date__month">Jun</span>
								</div><!-- /.blog-card-seven__date -->
							</div><!-- /.blog-card-seven__image -->
							<div class="blog-card-seven__content wow fadeInUp" data-wow-duration="1500ms">
								<ul class="blog-card-seven__meta list-unstyled d-none">
									<li>
										<a href="#">
											<span class="blog-card-seven__meta__icon"><i class="icon-user"></i></span>
											By Admin
										</a>
									</li>
									<li>
										<a href="#">
											<span class="blog-card-seven__meta__icon"><i class="icon-bubble-chat"></i></span>
											2 Comment
										</a>
									</li>
								</ul><!-- /.blog-card-seven__meta -->
								<h3 class="blog-card-seven__title">{{$data->title}}</h3><!-- /.blog-card-seven__title -->
								<div class="blog-card-seven__description">
									<p class="blog-card-three__text">{{$data->description}}</p>
								</div><!-- /.blog-card-seven__description -->
							</div><!-- /.blog-card-seven__content -->
						</div><!-- /.blog-card-seven -->
						

						<div class="blog-details__form comments-form wow fadeInUp d-none" data-wow-duration="1500ms">
							<h3 class="blog-details__form__title comments-form__title wow fadeInUp" data-wow-duration="1500ms">Leave a Comment</h3><!-- /.blog-details__form__title -->
							<form action="https://pixydrops.com/cherito-html/assets/inc/sendemail.php" class="blog-details__form__form contact-form-validated form-one">
								<div class="form-one__group">
									<div class="form-one__control wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
										<input type="text" name="name" placeholder="Your Name">
									</div><!-- /.form-one__control -->
									<div class="form-one__control wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="20ms">
										<input type="email" name="email" placeholder="Email Address">
									</div><!-- /.form-one__control -->
									<div class="form-one__control form-one__control--full wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="40ms">
										<textarea name="message" placeholder="Write Message"></textarea>
									</div><!-- /.form-one__control -->
									<div class="form-one__control form-one__control--full wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="60ms">
										<button type="submit" class="cherito-btn">
											<span class="cherito-btn__text">Submit a Comment</span>
											<span class="cherito-btn__hover cherito-btn__hover--1"></span>
											<span class="cherito-btn__hover cherito-btn__hover--2"></span>
											<span class="cherito-btn__hover cherito-btn__hover--3"></span>
											<span class="cherito-btn__hover cherito-btn__hover--4"></span>
											<span class="cherito-btn__hover cherito-btn__hover--5"></span>
										</button><!-- /.cherito-btn -->
									</div><!-- /.form-one__control -->
								</div><!-- /.form-one__group -->
							</form><!-- /.blog-details__form__form -->
							<div class="result"></div><!-- /.result -->
						</div><!-- /.blog-details__form -->
					</div><!-- /.blog-details -->
				</div><!-- /.col-xl-8 col-lg-7 -->
				<div class="col-xl-4 col-lg-5">
					<div class="sidebar">
						<aside class="widget-area">
							
							<div class="sidebar__posts-wrapper sidebar__single wow fadeInRight" data-wow-duration="1500ms">
								<h4 class="sidebar__posts-title sidebar__title">Latest Post</h4><!-- /.sidebar__title -->
								<ul class="sidebar__posts list-unstyled">
									@foreach ($blogs as $item)
										<li class="sidebar__posts__item">
											<div class="sidebar__posts__image">
												<a href="/blog/{{$item->slug}}"><img src="{{ URL::asset('storage/app/public/'.$data->image.'')}}" alt="{{$data->title}}"></a>
											</div><!-- /.sidebar__posts__image -->
											<div class="sidebar__posts__content">
												<div class="sidebar__posts__meta">
													<span class="sidebar__posts__meta__icon">
														<i class="icon-time-2"></i>
													</span><!-- /.sidebar__posts__meta__icon -->
													{{$item->created_at->diffForHumans()}}
												</div>
												
												<!-- /.sidebar__posts__date -->
												<h4 class="sidebar__posts__title"><a href="/blog/{{$item->slug}}">{{$item->title}}</a></h4><!-- /.sidebar__posts__title -->
											</div><!-- /.sidebar__posts__content -->
										</li>
									@endforeach
									
								</ul><!-- /.sidebar__posts list-unstyled -->
							</div><!-- /.sidebar__posts-wrapper sidebar__single -->
							
							<div class="sidebar__tags-wrapper sidebar__single wow fadeInRight" data-wow-duration="1500ms">
								<h4 class="sidebar__tags-title sidebar__title">Tags</h4><!-- /.sidebar__title -->
								<div class="sidebar__tags">
									<a href="blog-details-right.html" class="cherito-btn">
										<span class="cherito-btn__text">Charity</span>
										<span class="cherito-btn__hover cherito-btn__hover--1"></span>
										<span class="cherito-btn__hover cherito-btn__hover--2"></span>
										<span class="cherito-btn__hover cherito-btn__hover--3"></span>
										<span class="cherito-btn__hover cherito-btn__hover--4"></span>
										<span class="cherito-btn__hover cherito-btn__hover--5"></span>
									</a>
									<a href="blog-details-right.html" class="cherito-btn">
										<span class="cherito-btn__text">Education</span>
										<span class="cherito-btn__hover cherito-btn__hover--1"></span>
										<span class="cherito-btn__hover cherito-btn__hover--2"></span>
										<span class="cherito-btn__hover cherito-btn__hover--3"></span>
										<span class="cherito-btn__hover cherito-btn__hover--4"></span>
										<span class="cherito-btn__hover cherito-btn__hover--5"></span>
									</a>
									<a href="blog-details-right.html" class="cherito-btn">
										<span class="cherito-btn__text">Treatment</span>
										<span class="cherito-btn__hover cherito-btn__hover--1"></span>
										<span class="cherito-btn__hover cherito-btn__hover--2"></span>
										<span class="cherito-btn__hover cherito-btn__hover--3"></span>
										<span class="cherito-btn__hover cherito-btn__hover--4"></span>
										<span class="cherito-btn__hover cherito-btn__hover--5"></span>
									</a>
									<a href="blog-details-right.html" class="cherito-btn">
										<span class="cherito-btn__text">Food</span>
										<span class="cherito-btn__hover cherito-btn__hover--1"></span>
										<span class="cherito-btn__hover cherito-btn__hover--2"></span>
										<span class="cherito-btn__hover cherito-btn__hover--3"></span>
										<span class="cherito-btn__hover cherito-btn__hover--4"></span>
										<span class="cherito-btn__hover cherito-btn__hover--5"></span>
									</a>
									<a href="blog-details-right.html" class="cherito-btn">
										<span class="cherito-btn__text">Help</span>
										<span class="cherito-btn__hover cherito-btn__hover--1"></span>
										<span class="cherito-btn__hover cherito-btn__hover--2"></span>
										<span class="cherito-btn__hover cherito-btn__hover--3"></span>
										<span class="cherito-btn__hover cherito-btn__hover--4"></span>
										<span class="cherito-btn__hover cherito-btn__hover--5"></span>
									</a>
								</div><!-- /.sidebar__tags -->
							</div><!-- /.sidebar__tags-wrapper sidebar__single -->
							<!-- /.sidebar__comments-wrapper sidebar__single -->
						</aside><!-- /.widget-area -->
					</div><!-- /.sidebar -->
				</div><!-- /.col-xl-4 col-lg-5 -->
			</div><!-- /.row -->
		</div><!-- /.container -->
	</section><!-- /.blog-details-page -->
 @endsection