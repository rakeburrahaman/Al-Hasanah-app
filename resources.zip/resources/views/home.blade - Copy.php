@extends('layouts.master')
@section('main_content')


<section class="main-slider-three">
	<div class="main-slider-three__carousel cherito-owl__carousel cherito-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
"items": 1,
"margin": 0,
"animateIn": "fadeIn",
"animateOut": "fadeOut",
"loop": true,
"smartSpeed": 700,
"nav": false,
"dots": true,
"autoplay": true,
"navText": ["<i class=\"icon-left-arrow\"></i>","<i class=\"icon-right-arrow\"></i>"]
}'>
		<div class="main-slider-three__item">
			<div class="main-slider-three__bg" style="background-image: url('{{ asset('frontend/assets/images/backgrounds/main-slider-bg-3-1.jpg') }}');">
			</div>
			
			<!-- /.main-slider-three__bg -->
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-xl-10">
						<div class="main-slider-three__content">
							<div class="main-slider-three__top">
								<h6 class="main-slider-three__tagline">Start Donating They Deserve</h6>
							</div><!-- /.main-slider-three__top -->
							<h2 class="main-slider-three__title">
								<span class="main-slider-three__title__inner">
									Build the House of Allah & <br> Gain the Rewards
								</span>
							</h2><!-- /.main-slider-three__title -->
							<div class="main-slider-three__description">
								<p class="main-slider-three__text">There are many variations of passages of lorem ip available, but the <br> majority have suffered aeration in some form.</p><!-- /.text -->
							</div><!-- /.main-slider-three__description -->
							<div class="main-slider-three__button">
								<div class="main-slider-three__button__inner">
									<a href="about.html" class="cherito-btn cherito-btn--white">
										<span class="cherito-btn__text">Discover More</span>
										<span class="cherito-btn__hover cherito-btn__hover--1"></span>
										<span class="cherito-btn__hover cherito-btn__hover--2"></span>
										<span class="cherito-btn__hover cherito-btn__hover--3"></span>
										<span class="cherito-btn__hover cherito-btn__hover--4"></span>
										<span class="cherito-btn__hover cherito-btn__hover--5"></span>
									</a><!-- /.cherito-btn -->
								</div><!-- /.main-slider-three__button__inner -->
							</div><!-- /.main-slider-three__button -->
						</div><!-- /.main-slider-three__content -->
					</div><!-- /.col-xl-10 -->
				</div><!-- /.row -->
			</div><!-- /.container -->
			<img src="{{ asset('frontend/assets/images/shapes/main-slider-shape-3-1.png') }}" alt="shape" class="main-slider-three__shape">
		</div><!-- /.main-slider-three__item -->
		<div class="main-slider-three__item">
			<div class="main-slider-three__bg" style="background-image: url('{{ asset('frontend/assets/images/backgrounds/main-slider-bg-3-2.jpg') }}');"></div>

			<!-- /.main-slider-three__bg -->
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-xl-10">
						<div class="main-slider-three__content">
							<div class="main-slider-three__top">
								<h6 class="main-slider-three__tagline">Start Donating They Deserve</h6>
							</div><!-- /.main-slider-three__top -->
							<h2 class="main-slider-three__title">
								<span class="main-slider-three__title__inner">
									A Non-Profit Charity <br> & Muslim Organization
								</span>
							</h2><!-- /.main-slider-three__title -->
							<div class="main-slider-three__description">
								<p class="main-slider-three__text">My capacity is full note for the previous submit: the devil should be on <br> the left shoulder, yet meeting assassin shoot me.</p><!-- /.text -->
							</div><!-- /.main-slider-three__description -->
							<div class="main-slider-three__button">
								<div class="main-slider-three__button__inner">
									<a href="about.html" class="cherito-btn cherito-btn--white">
										<span class="cherito-btn__text">Discover More</span>
										<span class="cherito-btn__hover cherito-btn__hover--1"></span>
										<span class="cherito-btn__hover cherito-btn__hover--2"></span>
										<span class="cherito-btn__hover cherito-btn__hover--3"></span>
										<span class="cherito-btn__hover cherito-btn__hover--4"></span>
										<span class="cherito-btn__hover cherito-btn__hover--5"></span>
									</a><!-- /.cherito-btn -->
								</div><!-- /.main-slider-three__button__inner -->
							</div><!-- /.main-slider-three__button -->
						</div><!-- /.main-slider-three__content -->
					</div><!-- /.col-xl-10 -->
				</div><!-- /.row -->
			</div><!-- /.container -->
			<img src="{{ asset('frontend/assets/images/shapes/main-slider-shape-3-1.png') }}" alt="shape" class="main-slider-three__shape">
		</div><!-- /.main-slider-three__item -->
		<div class="main-slider-three__item">
			<div class="main-slider-three__bg" style="background-image: url('{{ asset('frontend/assets/images/backgrounds/main-slider-bg-3-3.jpg') }}');"></div>

			<!-- /.main-slider-three__bg -->
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-xl-10">
						<div class="main-slider-three__content">
							<div class="main-slider-three__top">
								<h6 class="main-slider-three__tagline">Start Donating They Deserve</h6>
							</div><!-- /.main-slider-three__top -->
							<h2 class="main-slider-three__title">
								<span class="main-slider-three__title__inner">
									Get Inspire Donate Help <br> Change a Life
								</span>
							</h2><!-- /.main-slider-three__title -->
							<div class="main-slider-three__description">
								<p class="main-slider-three__text">Blue sky thinking closing these latest prospects is like putting socks on <br> an octopus, nor where the metal hits the meat.</p><!-- /.text -->
							</div><!-- /.main-slider-three__description -->
							<div class="main-slider-three__button">
								<div class="main-slider-three__button__inner">
									<a href="about.html" class="cherito-btn cherito-btn--white">
										<span class="cherito-btn__text">Discover More</span>
										<span class="cherito-btn__hover cherito-btn__hover--1"></span>
										<span class="cherito-btn__hover cherito-btn__hover--2"></span>
										<span class="cherito-btn__hover cherito-btn__hover--3"></span>
										<span class="cherito-btn__hover cherito-btn__hover--4"></span>
										<span class="cherito-btn__hover cherito-btn__hover--5"></span>
									</a><!-- /.cherito-btn -->
								</div><!-- /.main-slider-three__button__inner -->
							</div><!-- /.main-slider-three__button -->
						</div><!-- /.main-slider-three__content -->
					</div><!-- /.col-xl-10 -->
				</div><!-- /.row -->
			</div><!-- /.container -->
			<img src="{{ asset('frontend/assets/images/shapes/main-slider-shape-3-1.png') }}" alt="shape" class="main-slider-three__shape">
		</div><!-- /.main-slider-three__item -->
	</div><!-- /.main-slider-three__carousel -->
</section><!-- /.main-slider-three -->

<section class="about-three">
	<div class="container">
		<div class="row gutter-y-60 align-items-center">
			<div class="col-lg-6">
				<div class="about-three__content">
					<div class="sec-title @@extraClassName wow fadeInUp" data-wow-duration="1500ms">
						<div class="sec-title__top">
							<img src="{{ asset('frontend/assets/images/shapes/sec-title-s-1-3.png') }}" alt="shape" class="sec-title__shape">
							<h6 class="sec-title__tagline">Join Us and Start Donating</h6><!-- /.sec-title__tagline -->
						</div><!-- /.sec-title__top -->
						<h3 class="sec-title__title">We’re Non-Profit Charity <br> & Muslim Organization</h3><!-- /.sec-title__title -->
					</div><!-- /.sec-title -->
					<div class="about-three__text-box wow fadeInUp" data-wow-duration="1500ms">
						<p class="about-three__text">There are many variations of passages of Lorem Ipsum avalab but the majority have suffered alteration in some form, by injected humour, or randomised words which don't.</p><!-- /.about-three__text -->
					</div><!-- /.about-three__text-box -->
					<div class="about-three__inner">
						<ul class="about-three__list list-unstyled wow fadeInUp" data-wow-duration="1500ms">
							<li>
								<span class="about-three__list__icon">
									<i class="icon-check"></i>
								</span>
								Feeding Hungry People
							</li>
							<li>
								<span class="about-three__list__icon">
									<i class="icon-check"></i>
								</span>
								Education, Charitable, Sports
							</li>
							<li>
								<span class="about-three__list__icon">
									<i class="icon-check"></i>
								</span>
								Charity Events Schooling Children
							</li>
							<li>
								<span class="about-three__list__icon">
									<i class="icon-check"></i>
								</span>
								Improving individuals and Society
							</li>
						</ul><!-- /.about-three__list list-unstyled -->
						<div class="about-three__establish wow fadeInUp" data-wow-duration="1500ms">
							<div class="about-three__establish__inner">
								<img src="{{ asset('frontend/assets/images/shapes/about-shape-3-4.png') }}" alt="logo">
								<h5 class="about-three__establish__text">Establish <br> 1999</h5><!-- /.about-three__establish__text -->
							</div><!-- /.about-three__establish__inner -->
						</div><!-- /.about-three__establish -->
					</div><!-- /.about-three__inner -->
					<div class="about-three__button wow fadeInUp" data-wow-duration="1500ms">
						<a href="about.html" class="cherito-btn">
							<span class="cherito-btn__text">Discover More</span>
							<span class="cherito-btn__hover cherito-btn__hover--1"></span>
							<span class="cherito-btn__hover cherito-btn__hover--2"></span>
							<span class="cherito-btn__hover cherito-btn__hover--3"></span>
							<span class="cherito-btn__hover cherito-btn__hover--4"></span>
							<span class="cherito-btn__hover cherito-btn__hover--5"></span>
						</a><!-- /.cherito-btn -->
					</div><!-- /.about-three__button -->
				</div><!-- /.about-three__content -->
			</div><!-- /.col-lg-6 -->
			<div class="col-lg-6 wow fadeInUp" data-wow-duration="1500ms">
				<div class="about-three__image">
					<div class="about-three__image__inner">
						<div class="about-three__image__one">
							<img src="{{ asset('frontend/assets/images/about/about-3-1.jpg') }}" alt="about">
						</div><!-- /.about-three__image__one -->
						<img src="{{ asset('frontend/assets/images/shapes/about-shape-3-2.png') }}" alt="shape" class="about-three__image__shape-1">
						<img src="{{ asset('frontend/assets/images/shapes/about-shape-3-3.png') }}" alt="shape" class="about-three__image__shape-2">
					</div><!-- /.about-three__image__inner -->
				</div><!-- /.about-three__image -->
			</div><!-- /.col-lg-6 -->
		</div><!-- /.row gutter-y-60 -->
	</div><!-- /.container -->
	<img src="{{ asset('frontend/assets/images/shapes/about-shape-3-1.png') }}" alt="shape" class="about-three__shape">
</section><!-- /.about-three -->

<section class="pillar-one section-space-top">
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				<img src="{{ asset('frontend/assets/images/shapes/sec-title-s-1-3.png') }}" alt="shape" class="sec-title__shape">
				<h6 class="sec-title__tagline">Pillar</h6><!-- /.sec-title__tagline -->
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">The Pillar of Islam</h3><!-- /.sec-title__title -->
		</div><!-- /.sec-title -->
		<div class="pillar-one__carousel cherito-owl__carousel cherito-owl__carousel--with-shadow cherito-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
	"items": 1,
	"margin": 0,
	"loop": false,
	"smartSpeed": 700,
	"nav": false,
	"dots": true,
	"navText": ["<i class=\"icon-left-arrow\"></i>","<i class=\"icon-right-arrow\"></i>"],
	"autoplay": true,
	"responsive": {
		"0": {
			"items": 1,
			"nav": true,
			"dots": false
		},
		"576": {
			"items": 2
		},
		"768": {
			"items": 3
		},
		"992": {
			"items": 4
		},
		"1200": {
			"items": 5,
			"dots": false
		}
	}
}'>
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
				<div class="pillar-card pillar-card--1">
					<div class="pillar-card__overlay"></div><!-- /.pillar-card__overlay -->
					<div class="pillar-card__content">
						<div class="pillar-card__icon-box">
							<span class="pillar-card__icon">
								<i class="icon-quran"></i>
							</span><!-- /.pillar-card__icon -->
						</div><!-- /.pillar-card__icon-box -->
						<h3 class="pillar-card__title">Kalima</h3><!-- /.pillar-card__title -->
						<div class="pillar-card__image">
							<img src="{{ asset('frontend/assets/images/pillar/pillar-1-1.jpg') }}" alt="Kalima">
						</div><!-- /.pillar-card__image -->
					</div><!-- /.pillar-card__content -->
				</div><!-- /.pillar-card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
				<div class="pillar-card pillar-card--2">
					<div class="pillar-card__overlay"></div><!-- /.pillar-card__overlay -->
					<div class="pillar-card__content">
						<div class="pillar-card__icon-box">
							<span class="pillar-card__icon">
								<i class="icon-salat"></i>
							</span><!-- /.pillar-card__icon -->
						</div><!-- /.pillar-card__icon-box -->
						<h3 class="pillar-card__title">Salat</h3><!-- /.pillar-card__title -->
						<div class="pillar-card__image">
							<img src="{{ asset('frontend/assets/images/pillar/pillar-1-2.jpg') }}" alt="Salat">
						</div><!-- /.pillar-card__image -->
					</div><!-- /.pillar-card__content -->
				</div><!-- /.pillar-card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
				<div class="pillar-card pillar-card--3">
					<div class="pillar-card__overlay"></div><!-- /.pillar-card__overlay -->
					<div class="pillar-card__content">
						<div class="pillar-card__icon-box">
							<span class="pillar-card__icon">
								<i class="icon-crescent-moon"></i>
							</span><!-- /.pillar-card__icon -->
						</div><!-- /.pillar-card__icon-box -->
						<h3 class="pillar-card__title">Fasting</h3><!-- /.pillar-card__title -->
						<div class="pillar-card__image">
							<img src="{{ asset('frontend/assets/images/pillar/pillar-1-3.jpg') }}" alt="Fasting">
						</div><!-- /.pillar-card__image -->
					</div><!-- /.pillar-card__content -->
				</div><!-- /.pillar-card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="300ms">
				<div class="pillar-card pillar-card--4">
					<div class="pillar-card__overlay"></div><!-- /.pillar-card__overlay -->
					<div class="pillar-card__content">
						<div class="pillar-card__icon-box">
							<span class="pillar-card__icon">
								<i class="icon-kaaba"></i>
							</span><!-- /.pillar-card__icon -->
						</div><!-- /.pillar-card__icon-box -->
						<h3 class="pillar-card__title">Hajj</h3><!-- /.pillar-card__title -->
						<div class="pillar-card__image">
							<img src="{{ asset('frontend/assets/images/pillar/pillar-1-4.jpg') }}" alt="Hajj">
						</div><!-- /.pillar-card__image -->
					</div><!-- /.pillar-card__content -->
				</div><!-- /.pillar-card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="400ms">
				<div class="pillar-card pillar-card--5">
					<div class="pillar-card__overlay"></div><!-- /.pillar-card__overlay -->
					<div class="pillar-card__content">
						<div class="pillar-card__icon-box">
							<span class="pillar-card__icon">
								<i class="icon-pure-water"></i>
							</span><!-- /.pillar-card__icon -->
						</div><!-- /.pillar-card__icon-box -->
						<h3 class="pillar-card__title">Zakat</h3><!-- /.pillar-card__title -->
						<div class="pillar-card__image">
							<img src="{{ asset('frontend/assets/images/pillar/pillar-1-5.jpg') }}" alt="Zakat">
						</div><!-- /.pillar-card__image -->
					</div><!-- /.pillar-card__content -->
				</div><!-- /.pillar-card -->
			</div><!-- /.item -->
		</div><!-- /.pillar-one__carousel -->
	</div><!-- /.container -->
</section><!-- /.pillar-one section-space-top -->

<section class="donations-three section-space-top">
	<div class="donations-three__bg" style="background-image: url('{{ asset('frontend/assets/images/shapes/donations-bg-3-1.png') }}');"></div>

	<!-- /.donations-three__bg -->
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				<img src="{{ asset('frontend/assets/images/shapes/sec-title-s-1-7.png') }}" alt="shape" class="sec-title__shape">
				<h6 class="sec-title__tagline">Help & Donate</h6><!-- /.sec-title__tagline -->
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">Find the Popular Cause <br> and Donate Them</h3><!-- /.sec-title__title -->
		</div><!-- /.sec-title -->
	</div><!-- /.container -->
	<div class="container">
		<div class="donations-three__carousel cherito-owl__carousel cherito-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
	"items": 1,
	"margin": 10,
	"loop": false,
	"smartSpeed": 700,
	"nav": false,
	"dots": true,
	"navText": ["<i class=\"icon-left-arrow\"></i>","<i class=\"icon-right-arrow\"></i>"],
	"autoplay": true,
	"responsive": {
		"0": {
			"items": 1,
			"margin": 10,
			"nav": true,
			"dots": false
		},
		"768": {
			"items": 2,
			"margin": 30
		},
		"1200": {
			"items": 3,
			"margin": 30,
			"dots": false
		}
	}
}'>
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
				<div class="donation-card-three">
					<div class="donation-card-three__content">
						<a href="donation-details-right.html" class="donation-card-three__category">Charity</a><!-- /.donation-card-three__category -->
						<h3 class="donation-card-three__title"><a href="donation-details-right.html">It is a Long Established Fact Quran Teaching</a></h3>
						<p class="donation-card-three__text">There are many variations of passages of Lorem Ip available, but the majority have suffered</p><!-- /.donation-card-three__text -->
						<div class="progress-box">
							<div class="progress-box__bar">
								<div class="progress-box__bar__inner count-bar--noappear" data-percent="65.66%">
									<div class="progress-box__number count-text">65.66%</div>
								</div><!-- /.progress-box__bar__inner -->
							</div><!-- /.progress-box_bar -->
							<div class="progress-box__content">
								<p class="progress-box__text">$4,599 <span class="progress-box__text__inner">Raised</span></p>
								<!-- /.progress-box__text -->
								<p class="progress-box__text">$5,000 <span class="progress-box__text__inner">Goal</span></p>
								<!-- /.progress-box__text -->
							</div><!-- /.progress-box__content -->
						</div><!-- /.progress-box -->
					</div><!-- /.donation-card-three__content -->
					<div class="donation-card-three__image">
						<img src="{{ asset('frontend/assets/images/donations/donation-3-1.jpg') }}" alt="It is a Long Established Fact Quran Teaching">
					</div><!-- /.donation-card-three__image -->
				</div><!-- /.donation-card-three -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
				<div class="donation-card-three">
					<div class="donation-card-three__content">
						<a href="donation-details-right.html" class="donation-card-three__category">Charity</a><!-- /.donation-card-three__category -->
						<h3 class="donation-card-three__title"><a href="donation-details-right.html">Quick win future-proof, and move the needle</a></h3>
						<p class="donation-card-three__text">Make it more corporate please drive awareness to increase engagement ensure to follow</p><!-- /.donation-card-three__text -->
						<div class="progress-box">
							<div class="progress-box__bar">
								<div class="progress-box__bar__inner count-bar--noappear" data-percent="70.87%">
									<div class="progress-box__number count-text">70.87%</div>
								</div><!-- /.progress-box__bar__inner -->
							</div><!-- /.progress-box_bar -->
							<div class="progress-box__content">
								<p class="progress-box__text">$1,529 <span class="progress-box__text__inner">Raised</span></p>
								<!-- /.progress-box__text -->
								<p class="progress-box__text">$2,100 <span class="progress-box__text__inner">Goal</span></p>
								<!-- /.progress-box__text -->
							</div><!-- /.progress-box__content -->
						</div><!-- /.progress-box -->
					</div><!-- /.donation-card-three__content -->
					<div class="donation-card-three__image">
						<img src="{{ asset('frontend/assets/images/donations/donation-3-2.jpg') }}" alt="Quick win future-proof, and move the needle">
					</div><!-- /.donation-card-three__image -->
				</div><!-- /.donation-card-three -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
				<div class="donation-card-three">
					<div class="donation-card-three__content">
						<a href="donation-details-right.html" class="donation-card-three__category">Charity</a><!-- /.donation-card-three__category -->
						<h3 class="donation-card-three__title"><a href="donation-details-right.html">Golden goose. We need to crystallize a plan</a></h3>
						<p class="donation-card-three__text">Who the goto on this job with the way forward great plan! let me diarize this and we can</p><!-- /.donation-card-three__text -->
						<div class="progress-box">
							<div class="progress-box__bar">
								<div class="progress-box__bar__inner count-bar--noappear" data-percent="85.79%">
									<div class="progress-box__number count-text">85.79%</div>
								</div><!-- /.progress-box__bar__inner -->
							</div><!-- /.progress-box_bar -->
							<div class="progress-box__content">
								<p class="progress-box__text">$9,511 <span class="progress-box__text__inner">Raised</span></p>
								<!-- /.progress-box__text -->
								<p class="progress-box__text">$8,220 <span class="progress-box__text__inner">Goal</span></p>
								<!-- /.progress-box__text -->
							</div><!-- /.progress-box__content -->
						</div><!-- /.progress-box -->
					</div><!-- /.donation-card-three__content -->
					<div class="donation-card-three__image">
						<img src="{{ asset('frontend/assets/images/donations/donation-3-3.jpg') }}" alt="Golden goose. We need to crystallize a plan">
					</div><!-- /.donation-card-three__image -->
				</div><!-- /.donation-card-three -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
				<div class="donation-card-three">
					<div class="donation-card-three__content">
						<a href="donation-details-right.html" class="donation-card-three__category">Charity</a><!-- /.donation-card-three__category -->
						<h3 class="donation-card-three__title"><a href="donation-details-right.html">Land it in region can you champion this that</a></h3>
						<p class="donation-card-three__text">We are running out of runway quick sync, so deploy incentivization, yet bottleneck nice</p><!-- /.donation-card-three__text -->
						<div class="progress-box">
							<div class="progress-box__bar">
								<div class="progress-box__bar__inner count-bar--noappear" data-percent="90.21%">
									<div class="progress-box__number count-text">90.21%</div>
								</div><!-- /.progress-box__bar__inner -->
							</div><!-- /.progress-box_bar -->
							<div class="progress-box__content">
								<p class="progress-box__text">$2,799 <span class="progress-box__text__inner">Raised</span></p>
								<!-- /.progress-box__text -->
								<p class="progress-box__text">$9,100 <span class="progress-box__text__inner">Goal</span></p>
								<!-- /.progress-box__text -->
							</div><!-- /.progress-box__content -->
						</div><!-- /.progress-box -->
					</div><!-- /.donation-card-three__content -->
					<div class="donation-card-three__image">
						<img src="{{ asset('frontend/assets/images/donations/donation-3-4.jpg') }}" alt="Land it in region can you champion this that">
					</div><!-- /.donation-card-three__image -->
				</div><!-- /.donation-card-three -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
				<div class="donation-card-three">
					<div class="donation-card-three__content">
						<a href="donation-details-right.html" class="donation-card-three__category">Charity</a><!-- /.donation-card-three__category -->
						<h3 class="donation-card-three__title"><a href="donation-details-right.html">We have to leverage up the messaging root</a></h3>
						<p class="donation-card-three__text">Collaboration through advanced technlogy gain traction we need more paper, so put your</p><!-- /.donation-card-three__text -->
						<div class="progress-box">
							<div class="progress-box__bar">
								<div class="progress-box__bar__inner count-bar--noappear" data-percent="75.99%">
									<div class="progress-box__number count-text">75.99%</div>
								</div><!-- /.progress-box__bar__inner -->
							</div><!-- /.progress-box_bar -->
							<div class="progress-box__content">
								<p class="progress-box__text">$1,112 <span class="progress-box__text__inner">Raised</span></p>
								<!-- /.progress-box__text -->
								<p class="progress-box__text">$8,210 <span class="progress-box__text__inner">Goal</span></p>
								<!-- /.progress-box__text -->
							</div><!-- /.progress-box__content -->
						</div><!-- /.progress-box -->
					</div><!-- /.donation-card-three__content -->
					<div class="donation-card-three__image">
						<img src="{{ asset('frontend/assets/images/donations/donation-3-5.jpg') }}" alt="We have to leverage up the messaging root">
					</div><!-- /.donation-card-three__image -->
				</div><!-- /.donation-card-three -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
				<div class="donation-card-three">
					<div class="donation-card-three__content">
						<a href="donation-details-right.html" class="donation-card-three__category">Charity</a><!-- /.donation-card-three__category -->
						<h3 class="donation-card-three__title"><a href="donation-details-right.html">Technologically savvy productize, so we need</a></h3>
						<p class="donation-card-three__text">High touch client through the lens of, so big data keep it lean meeting assassin the flagpole bazooka</p><!-- /.donation-card-three__text -->
						<div class="progress-box">
							<div class="progress-box__bar">
								<div class="progress-box__bar__inner count-bar--noappear" data-percent="85.31%">
									<div class="progress-box__number count-text">85.31%</div>
								</div><!-- /.progress-box__bar__inner -->
							</div><!-- /.progress-box_bar -->
							<div class="progress-box__content">
								<p class="progress-box__text">$5,871 <span class="progress-box__text__inner">Raised</span></p>
								<!-- /.progress-box__text -->
								<p class="progress-box__text">$7,954 <span class="progress-box__text__inner">Goal</span></p>
								<!-- /.progress-box__text -->
							</div><!-- /.progress-box__content -->
						</div><!-- /.progress-box -->
					</div><!-- /.donation-card-three__content -->
					<div class="donation-card-three__image">
						<img src="{{ asset('frontend/assets/images/donations/donation-3-6.jpg') }}" alt="Technologically savvy productize, so we need">
					</div><!-- /.donation-card-three__image -->
				</div><!-- /.donation-card-three -->
			</div><!-- /.item -->
		</div><!-- /.donations-three__carousel -->
	</div><!-- /.container -->
</section><!-- /.donations-three section-space-top -->

<section class="gallery-two">
	<div class="container">
		<div class="gallery-two__carousel cherito-owl__carousel cherito-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
	"items": 1,
	"margin": 10,
	"loop": false,
	"smartSpeed": 700,
	"nav": false,
	"dots": true,
	"navText": ["<i class=\"icon-left-arrow\"></i>","<i class=\"icon-right-arrow\"></i>"],
	"autoplay": true,
	"responsive": {
		"0": {
			"items": 1,
			"margin": 10,
			"nav": true,
			"dots": false
		},
		"768": {
			"items": 2,
			"margin": 24
		},
		"992": {
			"items": 3,
			"margin": 24
		},
		"1200": {
			"items": 4,
			"margin": 24
		},
		"1400": {
			"items": 5,
			"margin": 24,
			"dots": false
		}
	}
}'>
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
				<div class="gallery-two__card">
					<img src="{{ asset('frontend/assets/images/gallery/gallery-3-1.jpg') }}" alt="gallery">
					<div class="gallery-two__card__overlay"></div><!-- /.gallery-two__card__overlay -->
					<a href="assets/images/gallery/gallery-3-1.jpg') }}" class="gallery-two__card__icon-box img-popup">
						<i class="icon-ramadan-border"></i>
						<span class="gallery-two__card__icon">
							<i class="icon-right-arrow"></i>
						</span><!-- /.gallery-two__card__icon -->
					</a><!-- /.gallery-two__card__icon-box -->
				</div><!-- /.gallery-two__card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
				<div class="gallery-two__card">
					<img src="{{ asset('frontend/assets/images/gallery/gallery-3-2.jpg') }}" alt="gallery">
					<div class="gallery-two__card__overlay"></div><!-- /.gallery-two__card__overlay -->
					<a href="assets/images/gallery/gallery-3-2.jpg') }}" class="gallery-two__card__icon-box img-popup">
						<i class="icon-ramadan-border"></i>
						<span class="gallery-two__card__icon">
							<i class="icon-right-arrow"></i>
						</span><!-- /.gallery-two__card__icon -->
					</a><!-- /.gallery-two__card__icon-box -->
				</div><!-- /.gallery-two__card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
				<div class="gallery-two__card">
					<img src="{{ asset('frontend/assets/images/gallery/gallery-3-3.jpg') }}" alt="gallery">
					<div class="gallery-two__card__overlay"></div><!-- /.gallery-two__card__overlay -->
					<a href="assets/images/gallery/gallery-3-3.jpg') }}" class="gallery-two__card__icon-box img-popup">
						<i class="icon-ramadan-border"></i>
						<span class="gallery-two__card__icon">
							<i class="icon-right-arrow"></i>
						</span><!-- /.gallery-two__card__icon -->
					</a><!-- /.gallery-two__card__icon-box -->
				</div><!-- /.gallery-two__card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="300ms">
				<div class="gallery-two__card">
					<img src="{{ asset('frontend/assets/images/gallery/gallery-3-4.jpg') }}" alt="gallery">
					<div class="gallery-two__card__overlay"></div><!-- /.gallery-two__card__overlay -->
					<a href="assets/images/gallery/gallery-3-4.jpg') }}" class="gallery-two__card__icon-box img-popup">
						<i class="icon-ramadan-border"></i>
						<span class="gallery-two__card__icon">
							<i class="icon-right-arrow"></i>
						</span><!-- /.gallery-two__card__icon -->
					</a><!-- /.gallery-two__card__icon-box -->
				</div><!-- /.gallery-two__card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="400ms">
				<div class="gallery-two__card">
					<img src="{{ asset('frontend/assets/images/gallery/gallery-3-5.jpg') }}" alt="gallery">
					<div class="gallery-two__card__overlay"></div><!-- /.gallery-two__card__overlay -->
					<a href="assets/images/gallery/gallery-3-5.jpg') }}" class="gallery-two__card__icon-box img-popup">
						<i class="icon-ramadan-border"></i>
						<span class="gallery-two__card__icon">
							<i class="icon-right-arrow"></i>
						</span><!-- /.gallery-two__card__icon -->
					</a><!-- /.gallery-two__card__icon-box -->
				</div><!-- /.gallery-two__card -->
			</div><!-- /.item -->
		</div><!-- /.gallery-two__carousel -->
	</div><!-- /.container -->
</section><!-- /.gallery-two -->

<div class="testimonials-three section-space">
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				<img src="{{ asset('frontend/assets/images/shapes/sec-title-s-1-3.png') }}" alt="shape" class="sec-title__shape">
				<h6 class="sec-title__tagline">Testimonials</h6><!-- /.sec-title__tagline -->
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">What They are Talking <br> About Cherito</h3><!-- /.sec-title__title -->
		</div><!-- /.sec-title -->
		<div class="testimonials-three__carousel cherito-owl__carousel cherito-owl__carousel--with-shaow cherito-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
	"items": 1,
	"margin": 10,
	"loop": true,
	"smartSpeed": 700,
	"nav": false,
	"dots": true,
	"navText": ["<i class=\"icon-left-arrow\"></i>","<i class=\"icon-right-arrow\"></i>"],
	"autoplay": true,
	"responsive": {
		"0": {
			"items": 1,
			"margin": 10,
			"nav": true,
			"dots": false
		},
		"768": {
			"items": 2,
			"margin": 30
		},
		"1200": {
			"items": 3,
			"margin": 30,
			"dots": false
		}
	}
}'>
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
				<div class="testimonial-card-two">
					<div class="testimonial-card-two__icon-box">
						<span class="testimonial-card-two__icon"><i class="icon-quote"></i></span>
						<div class="testimonial-card-two__icon-box__shape"></div><!-- /.testimonial-card-two__icon-box__shape -->
					</div><!-- /.testimonial-card-two__icon-box -->
					<div class="testimonial-card-two__content">
						<div class="testimonial-card-two__content__inner">
							<div class="cherito-ratings">
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
							</div><!-- /.cherito-ratings -->
							<p class="testimonial-card-two__quote">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more</p><!-- /.testimonial-card-two__quote -->
							<div class="testimonial-card-two__identity">
								<div class="testimonial-card-two__identity__inner">
									<img src="{{ asset('frontend/assets/images/testimonials/testimonial-3-1.png') }}" alt="Hasibul Islam" class="testimonial-card-two__image">
									<div class="testimonial-card-two__identity__info">
										<h3 class="testimonial-card-two__name">Hasibul Islam</h3><!-- /.testimonial-card-two__name -->
										<p class="testimonial-card-two__designation">Guest</p><!-- /.testimonial-card-two__designation -->
									</div><!-- /.testimonial-card-two__identity__info -->
								</div><!-- /.testimonial-card-two__identity__inner -->
							</div><!-- /.testimonial-card-two__identity -->
						</div><!-- /.testimonial-card-two__content__inner -->
					</div><!-- /.testimonial-card-two__content -->
				</div><!-- /.testimonial-card-two -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
				<div class="testimonial-card-two">
					<div class="testimonial-card-two__icon-box">
						<span class="testimonial-card-two__icon"><i class="icon-quote"></i></span>
						<div class="testimonial-card-two__icon-box__shape"></div><!-- /.testimonial-card-two__icon-box__shape -->
					</div><!-- /.testimonial-card-two__icon-box -->
					<div class="testimonial-card-two__content">
						<div class="testimonial-card-two__content__inner">
							<div class="cherito-ratings">
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
							</div><!-- /.cherito-ratings -->
							<p class="testimonial-card-two__quote">Thanks for taking the time to make the website, but i already made it in wix labrador. What is a hamburger menu the target audience is makes and famles aged zero and up, so this red</p><!-- /.testimonial-card-two__quote -->
							<div class="testimonial-card-two__identity">
								<div class="testimonial-card-two__identity__inner">
									<img src="{{ asset('frontend/assets/images/testimonials/testimonial-3-2.png') }}" alt="Fatima Akter" class="testimonial-card-two__image">
									<div class="testimonial-card-two__identity__info">
										<h3 class="testimonial-card-two__name">Fatima Akter</h3><!-- /.testimonial-card-two__name -->
										<p class="testimonial-card-two__designation">Guest</p><!-- /.testimonial-card-two__designation -->
									</div><!-- /.testimonial-card-two__identity__info -->
								</div><!-- /.testimonial-card-two__identity__inner -->
							</div><!-- /.testimonial-card-two__identity -->
						</div><!-- /.testimonial-card-two__content__inner -->
					</div><!-- /.testimonial-card-two__content -->
				</div><!-- /.testimonial-card-two -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
				<div class="testimonial-card-two">
					<div class="testimonial-card-two__icon-box">
						<span class="testimonial-card-two__icon"><i class="icon-quote"></i></span>
						<div class="testimonial-card-two__icon-box__shape"></div><!-- /.testimonial-card-two__icon-box__shape -->
					</div><!-- /.testimonial-card-two__icon-box -->
					<div class="testimonial-card-two__content">
						<div class="testimonial-card-two__content__inner">
							<div class="cherito-ratings">
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
							</div><!-- /.cherito-ratings -->
							<p class="testimonial-card-two__quote">Give us a complimentary logo along with the website can you put find us on facebook by the facebook logo?, for can you make it look more designed , and i was wondering if my cat</p><!-- /.testimonial-card-two__quote -->
							<div class="testimonial-card-two__identity">
								<div class="testimonial-card-two__identity__inner">
									<img src="{{ asset('frontend/assets/images/testimonials/testimonial-3-3.png') }}" alt="Maryam Begum" class="testimonial-card-two__image">
									<div class="testimonial-card-two__identity__info">
										<h3 class="testimonial-card-two__name">Maryam Begum</h3><!-- /.testimonial-card-two__name -->
										<p class="testimonial-card-two__designation">Guest</p><!-- /.testimonial-card-two__designation -->
									</div><!-- /.testimonial-card-two__identity__info -->
								</div><!-- /.testimonial-card-two__identity__inner -->
							</div><!-- /.testimonial-card-two__identity -->
						</div><!-- /.testimonial-card-two__content__inner -->
					</div><!-- /.testimonial-card-two__content -->
				</div><!-- /.testimonial-card-two -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
				<div class="testimonial-card-two">
					<div class="testimonial-card-two__icon-box">
						<span class="testimonial-card-two__icon"><i class="icon-quote"></i></span>
						<div class="testimonial-card-two__icon-box__shape"></div><!-- /.testimonial-card-two__icon-box__shape -->
					</div><!-- /.testimonial-card-two__icon-box -->
					<div class="testimonial-card-two__content">
						<div class="testimonial-card-two__content__inner">
							<div class="cherito-ratings">
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
							</div><!-- /.cherito-ratings -->
							<p class="testimonial-card-two__quote">Can you make it pop was i smoking crack when i sent this? hahaha!, yet we are a non-profit organization, yet other agencies charge much lesser can you remove my double chin on my</p><!-- /.testimonial-card-two__quote -->
							<div class="testimonial-card-two__identity">
								<div class="testimonial-card-two__identity__inner">
									<img src="{{ asset('frontend/assets/images/testimonials/testimonial-3-4.png') }}" alt="Abdur Rahman" class="testimonial-card-two__image">
									<div class="testimonial-card-two__identity__info">
										<h3 class="testimonial-card-two__name">Abdur Rahman</h3><!-- /.testimonial-card-two__name -->
										<p class="testimonial-card-two__designation">Guest</p><!-- /.testimonial-card-two__designation -->
									</div><!-- /.testimonial-card-two__identity__info -->
								</div><!-- /.testimonial-card-two__identity__inner -->
							</div><!-- /.testimonial-card-two__identity -->
						</div><!-- /.testimonial-card-two__content__inner -->
					</div><!-- /.testimonial-card-two__content -->
				</div><!-- /.testimonial-card-two -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
				<div class="testimonial-card-two">
					<div class="testimonial-card-two__icon-box">
						<span class="testimonial-card-two__icon"><i class="icon-quote"></i></span>
						<div class="testimonial-card-two__icon-box__shape"></div><!-- /.testimonial-card-two__icon-box__shape -->
					</div><!-- /.testimonial-card-two__icon-box -->
					<div class="testimonial-card-two__content">
						<div class="testimonial-card-two__content__inner">
							<div class="cherito-ratings">
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
							</div><!-- /.cherito-ratings -->
							<p class="testimonial-card-two__quote">I have an awesome idea for a startup, i need you to build it for me i'll know it when i see it, the hair is just too polarising, nor the website doesn't have the theme i was going for.</p><!-- /.testimonial-card-two__quote -->
							<div class="testimonial-card-two__identity">
								<div class="testimonial-card-two__identity__inner">
									<img src="{{ asset('frontend/assets/images/testimonials/testimonial-3-5.png') }}" alt="Abdul Hafiz" class="testimonial-card-two__image">
									<div class="testimonial-card-two__identity__info">
										<h3 class="testimonial-card-two__name">Abdul Hafiz</h3><!-- /.testimonial-card-two__name -->
										<p class="testimonial-card-two__designation">Guest</p><!-- /.testimonial-card-two__designation -->
									</div><!-- /.testimonial-card-two__identity__info -->
								</div><!-- /.testimonial-card-two__identity__inner -->
							</div><!-- /.testimonial-card-two__identity -->
						</div><!-- /.testimonial-card-two__content__inner -->
					</div><!-- /.testimonial-card-two__content -->
				</div><!-- /.testimonial-card-two -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
				<div class="testimonial-card-two">
					<div class="testimonial-card-two__icon-box">
						<span class="testimonial-card-two__icon"><i class="icon-quote"></i></span>
						<div class="testimonial-card-two__icon-box__shape"></div><!-- /.testimonial-card-two__icon-box__shape -->
					</div><!-- /.testimonial-card-two__icon-box -->
					<div class="testimonial-card-two__content">
						<div class="testimonial-card-two__content__inner">
							<div class="cherito-ratings">
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
								<span class="cherito-ratings__icon"><i class="fas fa-star"></i></span>
							</div><!-- /.cherito-ratings -->
							<p class="testimonial-card-two__quote">I have an awesome idea for a startup, i need you to build it for me. I need a website. How much will it cost you might wanna give it another shot. Could you rotate the picture</p><!-- /.testimonial-card-two__quote -->
							<div class="testimonial-card-two__identity">
								<div class="testimonial-card-two__identity__inner">
									<img src="{{ asset('frontend/assets/images/testimonials/testimonial-3-6.png') }}" alt="Maymuna Akter" class="testimonial-card-two__image">
									<div class="testimonial-card-two__identity__info">
										<h3 class="testimonial-card-two__name">Maymuna Akter</h3><!-- /.testimonial-card-two__name -->
										<p class="testimonial-card-two__designation">Guest</p><!-- /.testimonial-card-two__designation -->
									</div><!-- /.testimonial-card-two__identity__info -->
								</div><!-- /.testimonial-card-two__identity__inner -->
							</div><!-- /.testimonial-card-two__identity -->
						</div><!-- /.testimonial-card-two__content__inner -->
					</div><!-- /.testimonial-card-two__content -->
				</div><!-- /.testimonial-card-two -->
			</div><!-- /.item -->
		</div><!-- /.testimonials-three__carousel -->
	</div><!-- /.container -->
</div><!-- /.testimonials-three section-space -->

<section class="cta-two">
	<div class="cta-two__image">
		<img src="{{ asset('frontend/assets/images/resources/cta-2-1.jpg') }}" alt="cta">
	</div><!-- /.cta-two__image -->
	<div class="container">
		<div class="cta-two__content">
			<div class="cta-two__sec-title wow fadeInUp" data-wow-duration="1500ms">
				<h2 class="cta-two__title">The Mosque is a Symbol of the Strength and Resilience of Muslim Communities</h2><!-- /.cta-two__title -->
			</div><!-- /.cta-two__sec-title -->
			<div class="cta-two__button wow fadeInUp" data-wow-duration="1500ms">
				<a href="about.html" class="cherito-btn cherito-btn--primary">
					<span class="cherito-btn__text">Discover More</span>
					<span class="cherito-btn__hover cherito-btn__hover--1"></span>
					<span class="cherito-btn__hover cherito-btn__hover--2"></span>
					<span class="cherito-btn__hover cherito-btn__hover--3"></span>
					<span class="cherito-btn__hover cherito-btn__hover--4"></span>
					<span class="cherito-btn__hover cherito-btn__hover--5"></span>
				</a><!-- /.cherito-btn -->
			</div><!-- /.cta-two__button -->
		</div><!-- /.cta-two__content -->
	</div><!-- /.container -->
	<div class="cta-two__shape">
		<img src="{{ asset('frontend/assets/images/shapes/cta-shape-2-1.png') }}" alt="shape" class="cta-two__shape__1">
		<img src="{{ asset('frontend/assets/images/shapes/cta-shape-2-2.png') }}" alt="shape" class="cta-two__shape__2">
		<img src="{{ asset('frontend/assets/images/shapes/cta-shape-2-3.png') }}" alt="shape" class="cta-two__shape__3">
	</div><!-- /.cta-two__shape -->
</section><!-- /.cta-two -->

<section class="funfact-two">
	<div class="container">
		<div class="row">
			<div class="funfact-two__image wow fadeInUp" data-wow-duration="1500ms">
				<img src="{{ asset('frontend/assets/images/resources/funfact-2-1.jpg') }}" alt="funfact">
			</div><!-- /.funfact-two__image -->
			<div class="funfact-two__content">
				<div class="funfact-two__grid">
					<div class="funfact-card wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
						<div class="funfact-card__inner">
							<span class="funfact-card__icon">
								<i class="icon-user-2"></i>
							</span><!-- /.funfact-card__icon -->
							<div class="funfact-card__content">
								<h3 class="funfact-card__count count-box">
									<span class="count-text" data-stop="26" data-speed="1500">0</span>
									<span>K</span>
								</h3><!-- /.funfact-card__count -->
								<p class="funfact-card__text">Team Support</p><!-- /.funfact-card__text -->
							</div><!-- /.funfact-card__content -->
						</div><!-- /.funfact-card__inner -->
					</div><!-- /.funfact-card -->
					<div class="funfact-card wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
						<div class="funfact-card__inner">
							<span class="funfact-card__icon">
								<i class="icon-charity"></i>
							</span><!-- /.funfact-card__icon -->
							<div class="funfact-card__content">
								<h3 class="funfact-card__count count-box">
									<span class="count-text" data-stop="360" data-speed="1500">0</span>
									<span>K</span>
								</h3><!-- /.funfact-card__count -->
								<p class="funfact-card__text">Total Donation</p><!-- /.funfact-card__text -->
							</div><!-- /.funfact-card__content -->
						</div><!-- /.funfact-card__inner -->
					</div><!-- /.funfact-card -->
					<div class="funfact-card wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
						<div class="funfact-card__inner">
							<span class="funfact-card__icon">
								<i class="icon-help"></i>
							</span><!-- /.funfact-card__icon -->
							<div class="funfact-card__content">
								<h3 class="funfact-card__count count-box">
									<span class="count-text" data-stop="80" data-speed="1500">0</span>
									<span>M</span>
								</h3><!-- /.funfact-card__count -->
								<p class="funfact-card__text">Clients Help</p><!-- /.funfact-card__text -->
							</div><!-- /.funfact-card__content -->
						</div><!-- /.funfact-card__inner -->
					</div><!-- /.funfact-card -->
					<div class="funfact-card wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
						<div class="funfact-card__inner">
							<span class="funfact-card__icon">
								<i class="icon-book"></i>
							</span><!-- /.funfact-card__icon -->
							<div class="funfact-card__content">
								<h3 class="funfact-card__count count-box">
									<span class="count-text" data-stop="320" data-speed="1500">0</span>
									<span>K</span>
								</h3><!-- /.funfact-card__count -->
								<p class="funfact-card__text">Poor Educate</p><!-- /.funfact-card__text -->
							</div><!-- /.funfact-card__content -->
						</div><!-- /.funfact-card__inner -->
					</div><!-- /.funfact-card -->
				</div><!-- /.funfact-two__grid -->
				<div class="funfact-two__logo">
					<div class="funfact-two__logo__inner">
						<img src="{{ asset('frontend/assets/images/shapes/funfact-logo-2-1.png') }}" alt="logo">
					</div><!-- /.funfact-two__logo__inner -->
				</div><!-- /.funfact-two__logo -->
			</div><!-- /.funfact-two__content -->
		</div><!-- /.row -->
	</div><!-- /.container -->
</section><!-- /.funfact-two -->

<section class="donate-two section-space-top">
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				<img src="{{ asset('frontend/assets/images/shapes/sec-title-s-1-3.png') }}" alt="shape" class="sec-title__shape">
				<h6 class="sec-title__tagline">Donate Now</h6><!-- /.sec-title__tagline -->
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">Get Inspire Donate Help <br> Change a Life</h3><!-- /.sec-title__title -->
		</div><!-- /.sec-title -->
		<div class="donate-two__inner">
			<div class="donate-two__bg" style="background-image: url('{{ asset('frontend/assets/images/backgrounds/donate-bg-2-1.jpg') }}');"></div>

			
			<!-- /.donate-two__bg -->
			<div class="donate-two__wrapper">
				<div class="donate-two__row row">
					<div class="donate-two__content">
						<div class="donate-two__content__inner">
							<div class="donate-two__sec-title">
								<p class="donate-two__top-title">$4,599 <span>Goal</span></p><!-- /.donate-two__top-title -->
								<h2 class="donate-two__title">Hajj For Elderly</h2><!-- /.donate-two__title -->
								<p class="donate-two__text">It is a long established fact that a reader will be distracted by the readable content.</p><!-- /.donate-two__text -->
							</div><!-- /.donate-two__sec-title -->
							<form action="#" class="donate-form">
								<div class="donate-form__amount">
									<div class="donate-form__amount__box">
										<input type="text" value="$200" name="donate_amount" id="donate_amount" placeholder="Amount" class="donate-form__amount__input">
									</div><!-- /.donate-form__amount__box -->
									<div class="donate-form__amount__buttons">
										<button type="button" class="donate-form__amount__btn donate-form__amount__btn--amount">
											$<span class="donate-form__amount__btn__text">50</span>
										</button>
										<button type="button" class="donate-form__amount__btn donate-form__amount__btn--amount">
											$<span class="donate-form__amount__btn__text">100</span>
										</button>
										<button type="button" class="donate-form__amount__btn donate-form__amount__btn--amount active">
											$<span class="donate-form__amount__btn__text">200</span>
										</button>
										<button type="button" class="donate-form__amount__btn donate-form__amount__btn--custom">Custom</button>
									</div><!-- /.donate-form__amount__buttons -->
								</div><!-- /.donate-form__amount -->
								<button type="submit" class="cherito-btn">
									<span class="cherito-btn__text">Donate Now</span>
									<span class="cherito-btn__hover cherito-btn__hover--1"></span>
									<span class="cherito-btn__hover cherito-btn__hover--2"></span>
									<span class="cherito-btn__hover cherito-btn__hover--3"></span>
									<span class="cherito-btn__hover cherito-btn__hover--4"></span>
									<span class="cherito-btn__hover cherito-btn__hover--5"></span>
								</button><!-- /.cherito-btn -->
							</form><!-- /.donate-form -->
						</div><!-- /.donate-two__content__inner -->
					</div><!-- /.donate-two__content -->
					<div class="donate-two__image">
						<img src="{{ asset('frontend/assets/images/resources/donate-2-1.jpg') }}" alt="dpnate">
					</div><!-- /.donate-two__image -->
					<div class="donate-two__progress">
						<div class="donate-two__progress__inner">
							<div class="donate-two__progress__box">
								<svg class="radial-progress" data-countervalue="40" viewBox="0 0 80 80">
									<circle class="bar-static" cx="40" cy="40" r="35"></circle>
									<circle class="bar--animated count-1" cx="40" cy="40" r="35" style="stroke-dashoffset: 217.8;"></circle>
									<text class="countervalue start" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">40</text>
								</svg>
							</div><!-- /.donate-two__progress__box -->
							<h3 class="donate-two__progress__amount">$2,599</h3><!-- /.donate-two__progress__amount -->
							<p class="donate-two__progress__text">Raised</p><!-- /.donate-two__progress__text -->
						</div><!-- /.donate-two__progress__inner -->
					</div><!-- /.donate-two__progress -->
				</div><!-- /.donate-two__row row -->
			</div><!-- /.donate-two__wrapper -->
		</div><!-- /.donate-two__inner -->
	</div><!-- /.container -->
	<div class="donate-two__shape">
		<div class="donate-two__shape__bg" style="background-image: url('{{ asset('frontend/assets/images/shapes/donate-shape-2-1.png') }}');"></div>
<!-- /.donate-two__shape__bg -->
	</div><!-- /.donate-two__shape -->
</section><!-- /.donate-two section-space-top -->

<section class="blog-three section-space-top">
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				<img src="{{ asset('frontend/assets/images/shapes/sec-title-s-1-3.png') }}" alt="shape" class="sec-title__shape">
				<h6 class="sec-title__tagline">Our Latest Blog</h6><!-- /.sec-title__tagline -->
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">Explore the Our Recent <br> News & Blog</h3><!-- /.sec-title__title -->
		</div><!-- /.sec-title -->
		<div class="row gutter-y-30">
			<div class="col-lg-4 col-md-6">
				<div class="blog-card-three wow fadeInUp">
					<div class="blog-card-three__image">
						<img src="{{ asset('frontend/assets/images/blog/blog-3-1.jpg') }}" alt="Thanking to the Graces of Almighty Allah">
						<a href="blog-details-right.html" class="blog-card-three__image__link"><span class="sr-only">Thanking to the Graces of Almighty Allah</span></a>
						<div class="blog-card-three__image__inner">
							<div class="blog-card-three__date">
								<p>23</p>
								<p><span>July</span> <span>2024</span></p>
							</div><!-- /.blog-card-three__date -->
							<ul class="blog-card-three__meta list-unstyled">
								<li>
									<a href="#">
										<span class="blog-card-three__meta__icon"><i class="icon-bubble-chat"></i></span>
										2 Comment
									</a>
								</li>
							</ul><!-- /.blog-card-three__meta -->
						</div><!-- /.blog-card-three__image__inner -->
					</div><!-- /.blog-card-three__image -->
					<div class="blog-card-three__content">
						<h3 class="blog-card-three__title"><a href="blog-details-right.html">Thanking to the Graces of Almighty Allah</a></h3><!-- /.blog-card-three__title -->
						<p class="blog-card-three__text">There are many variations of passages of Lorem Ip available, but the majority have suffered</p><!-- /.blog-card-three__text -->
						<div class="blog-card-three__bottom">
							<div class="blog-card-three__admin">
								<img src="{{ asset('frontend/assets/images/blog/blog-admin-3-1.png') }}" alt="Hasanul Islam" class="blog-card-three__admin__image">
								<div class="blog-card-three__admin__content">
									<h3 class="blog-card-three__admin__name"><a href="#">Hasanul Islam</a></h3>
									<p class="blog-card-three__admin__designation">Admin</p>
								</div><!-- /.blog-card-three__admin__content -->
							</div><!-- /.blog-card-three__admin -->
							<a href="blog-details-right.html" class="blog-card-three__btn">
								<span class="blog-card-three__btn__icon"><i class="icon-right-arrow"></i></span>
							</a><!-- /.blog-card-three__icon-box -->
						</div><!-- /.blog-card-three__bottom -->
					</div><!-- /.blog-card-three__content -->
				</div><!-- /.blog-card-three -->
			</div><!-- /.col-lg-4 col-md-6 -->
			<div class="col-lg-4 col-md-6">
				<div class="blog-card-three wow fadeInUp">
					<div class="blog-card-three__image">
						<img src="{{ asset('frontend/assets/images/blog/blog-3-2.jpg') }}" alt="Get Inspire Donate Help Change a Life">
						<a href="blog-details-right.html" class="blog-card-three__image__link"><span class="sr-only">Get Inspire Donate Help Change a Life</span></a>
						<div class="blog-card-three__image__inner">
							<div class="blog-card-three__date">
								<p>10</p>
								<p><span>June</span> <span>2024</span></p>
							</div><!-- /.blog-card-three__date -->
							<ul class="blog-card-three__meta list-unstyled">
								<li>
									<a href="#">
										<span class="blog-card-three__meta__icon"><i class="icon-bubble-chat"></i></span>
										2 Comment
									</a>
								</li>
							</ul><!-- /.blog-card-three__meta -->
						</div><!-- /.blog-card-three__image__inner -->
					</div><!-- /.blog-card-three__image -->
					<div class="blog-card-three__content">
						<h3 class="blog-card-three__title"><a href="blog-details-right.html">Get Inspire Donate Help Change a Life</a></h3><!-- /.blog-card-three__title -->
						<p class="blog-card-three__text">We need to future-proof this please submit the sop and uat files by next monday all hands</p><!-- /.blog-card-three__text -->
						<div class="blog-card-three__bottom">
							<div class="blog-card-three__admin">
								<img src="{{ asset('frontend/assets/images/blog/blog-admin-3-2.png') }}" alt="Rasedul Islam" class="blog-card-three__admin__image">
								<div class="blog-card-three__admin__content">
									<h3 class="blog-card-three__admin__name"><a href="#">Rasedul Islam</a></h3>
									<p class="blog-card-three__admin__designation">Admin</p>
								</div><!-- /.blog-card-three__admin__content -->
							</div><!-- /.blog-card-three__admin -->
							<a href="blog-details-right.html" class="blog-card-three__btn">
								<span class="blog-card-three__btn__icon"><i class="icon-right-arrow"></i></span>
							</a><!-- /.blog-card-three__icon-box -->
						</div><!-- /.blog-card-three__bottom -->
					</div><!-- /.blog-card-three__content -->
				</div><!-- /.blog-card-three -->
			</div><!-- /.col-lg-4 col-md-6 -->
			<div class="col-lg-4 col-md-6">
				<div class="blog-card-three wow fadeInUp">
					<div class="blog-card-three__image">
						<img src="{{ asset('frontend/assets/images/blog/blog-3-3.jpg') }}" alt="Nail jelly to the hothouse wall pixel">
						<a href="blog-details-right.html" class="blog-card-three__image__link"><span class="sr-only">Nail jelly to the hothouse wall pixel</span></a>
						<div class="blog-card-three__image__inner">
							<div class="blog-card-three__date">
								<p>15</p>
								<p><span>Marc</span> <span>2024</span></p>
							</div><!-- /.blog-card-three__date -->
							<ul class="blog-card-three__meta list-unstyled">
								<li>
									<a href="#">
										<span class="blog-card-three__meta__icon"><i class="icon-bubble-chat"></i></span>
										2 Comment
									</a>
								</li>
							</ul><!-- /.blog-card-three__meta -->
						</div><!-- /.blog-card-three__image__inner -->
					</div><!-- /.blog-card-three__image -->
					<div class="blog-card-three__content">
						<h3 class="blog-card-three__title"><a href="blog-details-right.html">Nail jelly to the hothouse wall pixel</a></h3><!-- /.blog-card-three__title -->
						<p class="blog-card-three__text">Agile loop back identify pain points, yet root-and-branch review, yet red flag, for sacred</p><!-- /.blog-card-three__text -->
						<div class="blog-card-three__bottom">
							<div class="blog-card-three__admin">
								<img src="{{ asset('frontend/assets/images/blog/blog-admin-3-3.png') }}" alt="Maryam Begum" class="blog-card-three__admin__image">
								<div class="blog-card-three__admin__content">
									<h3 class="blog-card-three__admin__name"><a href="#">Maryam Begum</a></h3>
									<p class="blog-card-three__admin__designation">Admin</p>
								</div><!-- /.blog-card-three__admin__content -->
							</div><!-- /.blog-card-three__admin -->
							<a href="blog-details-right.html" class="blog-card-three__btn">
								<span class="blog-card-three__btn__icon"><i class="icon-right-arrow"></i></span>
							</a><!-- /.blog-card-three__icon-box -->
						</div><!-- /.blog-card-three__bottom -->
					</div><!-- /.blog-card-three__content -->
				</div><!-- /.blog-card-three -->
			</div><!-- /.col-lg-4 col-md-6 -->
		</div><!-- /.row gutter-y-30 -->
	</div><!-- /.container -->
</section><!-- /.blog-three section-space-top -->

<section class="client-carousel client-carousel--home3">
	<div class="container">
		<div class="client-carousel__content">
			<h4 class="client-carousel__title">2K+ brands trust us</h4><!-- /.client-carousel__title -->
		</div><!-- /.client-carousel__content -->
		<div class="client-carousel__carousel cherito-owl__carousel owl-theme owl-carousel" data-owl-options='{
	"items": 5,
	"margin": 65,
	"smartSpeed": 700,
	"loop": true,
	"autoplay": true,
	"nav":false,
	"dots":false,
	"navText": ["<span class=\"icon-arrow-left\"></span>","<span class=\"icon-arrow-right\"></span>"],
	"responsive":{
		"0":{
			"items": 2,
			"margin": 60
		},
		"500":{
			"items": 3,
			"margin": 60
		},
		"768":{
			"items": 4,
			"margin": 60
		},
		"992":{
			"items": 5,
			"margin": 70
		},
		"1200":{
			"items": 5,
			"margin": 108
		}
	}
	}'>
			<div class="client-carousel__item">
				<img src="{{ asset('frontend/assets/images/resources/brand-2-1.png') }}" alt="cherito" class="client-carousel__image">
				<img src="{{ asset('frontend/assets/images/resources/brand-2-1-hover.png') }}" alt="cherito" class="client-carousel__hover-image">
			</div><!-- /.owl-slide-item-->
			<div class="client-carousel__item">
				<img src="{{ asset('frontend/assets/images/resources/brand-2-1.png') }}" alt="cherito" class="client-carousel__image">
				<img src="{{ asset('frontend/assets/images/resources/brand-2-1-hover.png') }}" alt="cherito" class="client-carousel__hover-image">
			</div><!-- /.owl-slide-item-->
			<div class="client-carousel__item">
				<img src="{{ asset('frontend/assets/images/resources/brand-2-1.png') }}" alt="cherito" class="client-carousel__image">
				<img src="{{ asset('frontend/assets/images/resources/brand-2-1-hover.png') }}" alt="cherito" class="client-carousel__hover-image">
			</div><!-- /.owl-slide-item-->
			<div class="client-carousel__item">
				<img src="{{ asset('frontend/assets/images/resources/brand-2-1.png') }}" alt="cherito" class="client-carousel__image">
				<img src="{{ asset('frontend/assets/images/resources/brand-2-1-hover.png') }}" alt="cherito" class="client-carousel__hover-image">
			</div><!-- /.owl-slide-item-->
			<div class="client-carousel__item">
				<img src="{{ asset('frontend/assets/images/resources/brand-2-1.png') }}" alt="cherito" class="client-carousel__image">
				<img src="{{ asset('frontend/assets/images/resources/brand-2-1-hover.png') }}" alt="cherito" class="client-carousel__hover-image">
			</div><!-- /.owl-slide-item-->
		</div><!-- /.client-carousel__carousel -->
	</div><!-- /.container -->
</section><!-- /.client-carousel -->


@endsection