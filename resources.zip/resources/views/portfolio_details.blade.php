@extends('layouts.master')
@section('main_content')

<!--================= About Us Start Here =================-->
<section class="about-us-area pt-120 pb-75 pt-md-60 pb-md-15 pt-xs-50 pb-xs-10">
    <div class="container">
        <div class="image-section">
            <div class="row">
                <div class="col-lg-6">
                    <div class="image-1">
                        <img src="{{ asset('images/' . $images[0]) }}" alt="img1">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="image-2">
                        <img src="{{ asset('images/' . $images[1]) }}" alt="img2">
                    </div>
                </div>
            </div>
            <div class="section-title">
                <div class="title-inner">
                    <div class="wrapper">
                        <div class="sub-content">
                            <img class="line-1" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="img 3">
                            <span class="sub-text">title</span>
                            <img class="line-2" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="img 4">
                        </div>
                        <h2 class="title">{{$item->name}}</h2>
                    </div>
                </div>
            </div>
            <div class="row" style="padding-top: 20px;">
                <div class="col-lg-4">
                    <div class="image-1">
                        <img src="{{ asset('images/'. $images[2]) }}" alt="img 1">
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="image-2">
                        <img src="{{ asset('images/'. $images[3]) }}" alt="img 2">
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="image-2">
                        <img src="{{ asset('images/'. $images[4]) }}" alt="img">
                    </div>
                </div>
            </div>
        </div>
        <div class="section-text">
            <div class="row">
                <div class="col-lg-8">
                    <h3>Description</h3>
                    <p class="description">
                        {!! $item->description !!}
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="service-list" style="border: 1px solid #ebeaea; padding: 20px;">
                        <ul>
                            <H4>Client:</H4>
                            <li><a href="#">{{$item->client}}</a></li>
                            <h4>Date:</h4>
                            <li><a href="#">{{$item->created_at}}</a></li>
                            <h4>Category:</h4>
                            <li><a href="#">#</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<section class="about-us-area pt-120 pb-75 pt-md-60 pb-md-15 pt-xs-50 pb-xs-10">
<div class="team-area">
    <div class="container">
        <div class="slider-div">
            <div class="swiper rts-cmmnSlider-over2" data-swiper="pagination">
                <div class="swiper-wrapper">

                    @foreach (array_chunk($images, 5) as $chunk)
                        @foreach ($chunk as $image)
                            <div class="swiper-slide">
                                <div class="team-wraper">
                                    <div class="team-thumb">
                                        <a href="#"><img src="{{ asset('images/'. $image) }}" alt="collection-image"></a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
<!--================= Team Area End Here =================-->

<!--================= Feature Area Start Here =================-->
<div class="rts-video-section d-none">
    <div class="container">
        <div class="video-section-inner1">
            <div class="rts-video">
                <div class="about-video-wrapper">
                    <a href="{{ asset('videos/'. $item->video) }}" class="popup-videos" target="_blank" type="video/mp4">
                        <i class="rt-play"></i>
                    </a>

                    <!-- Video Embed -->
                    <video controls>
                        <source src="{{ asset('videos/'.  $item->video) }}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>
            </div>
        </div>
    </div>
</div>

</section>


@endsection