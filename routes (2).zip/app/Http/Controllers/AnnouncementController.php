<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use DB;

class AnnouncementController extends Controller
{
    public function index()
    {
        $data = Announcement::orderBy('id', 'desc')
              // ->where('client_id', session('client_id')) 
              ->where('active', 'on')
              ->get();
        return view('admin.announcement.index', ['data'=>$data]);        
    }

    public function create()
    {        
      return view('admin.announcement.create');
    }

    public function store(Request $request)
    {      
    //  dd($request);  
      $data = new Announcement();
      $data->title = $request->title; 
      $data->sub_title = $request->sub_title; 
      $data->link_title = $request->link_title; 
      $data->link_action = $request->link_action; 


      $data->active = 'on';
      $data->created_by = session('user_id');
      // $data->client_id = session('client_id');
      $data->updated_by = '';
      $data->save();  
      $data->id;

      return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));

    }

    public function edit($id){
      $data = Announcement::find($id);      
      return view('admin.announcement.edit', ['data'=>$data]);
    }

    public function update(Request $request)
    {       
              // dd($request);  
          $data = Announcement::find($request->id);
          $data->title = $request->title; 
          $data->sub_title = $request->sub_title; 
          $data->link_title = $request->link_title; 
          $data->link_action = $request->link_action; 
          $data->updated_by = session('user_id');
          $data->save(); 

          return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));
    }

    public function show($id){
      $data = CaseStudy::find($id);      
      return view('admin.case_study.show', ['data'=>$data]);
    }
    public function destroy($id)
    {
      // DB::table('CaseStudys')
      // ->where('id',$id)
      // ->delete();
      $data = CaseStudy::find($id);
      $data->active = null;
      $data->save();

      return redirect()->back()->with(session()->flash('alert-success', 'CaseStudy has been deleted successfully.'));
    }
}
