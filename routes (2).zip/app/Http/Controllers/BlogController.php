<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use DB;

class BlogController extends Controller
{
      public function index() {
        // Active blogs fetch with pagination
        $blogs = DB::table('blogs')
            ->where('active', 'on')
            ->orderBy('id', 'desc') // Ensure blogs are ordered by ID in descending order
            ->paginate(6); // 6 items per page

        // Return to the view
        return view('blog', [
            'page' => 'blog, home',
            'blogs' => $blogs,
        ]);
    }

    public function show($slug){
      $data = Blog::where('slug', $slug)->first();


      $blogs = Blog::orderBy('id', 'desc')
            ->where('active', 'on')
            ->limit(4)
            ->get();

      return view('blog_details', ['page'=>'blog_detail', 'data'=>$data, 'blogs'=>$blogs,]); 
    }

    
      /*============================
       Blogs
       ============================*/
       public function blogs()
       {     

        $fetch = DB::table('blogs')
        ->join('blog_categories', 'blogs.category_id', '=', 'blog_categories.id')
        ->select('blogs.*', 'blog_categories.name as catName')
        ->orderby('blogs.id', 'desc')
        ->get();        
        
        $data=view('admin.blogs')
        ->with('data',$fetch);



        return view('admin.master')
        ->with('main_content',$data);
      } 

      public function create()
      {        
        return view('admin.blog_add');
      }

      public function store(Request $request)
      {     
           
        $data = new Blog;
        $data->title = $request->title;
        $data->slug = Str::slug($request->title);
        $data->sub_title = $request->sub_title;
  
        $data->description = $request->description;
        $data->short_description = $request->short_description;
        
        if($request->file('image')!= null){
            $data->image = $request->file('image')->store('images');
        } 
        $data->active = $request->active;
        $data->created_by = session('user.id');
        $data->updated_by = '';
        $data->save();

        return redirect()->back()->with(session()->flash('alert-success', 'Data has been inserted successfully.'));    

      }

      public function edit($id)
      {
       
        // $data = DB::table('blogs')
        // ->join('blog_categories', 'blogs.category_id', '=', 'blog_categories.id')
        // ->select('blogs.*', 'blog_categories.name as catName', 'blog_categories.id as catID')
        // ->where('blogs.id',$id)
        // ->first();
        $data = DB::table('blogs')->where('id', $id)->first();

        return view('admin.blog_edit', ['data'=>$data]);
      }

      public function update(Request $request)
    {       
   
          $data = Blog::find($request->id);
          $data->title = $request->title;
          $data->sub_title = $request->sub_title;

          $data->description = $request->description;
          $data->short_description = $request->short_description;
          $data->meta_description = $request->meta_description;
          $data->link_title = $request->link_title;
          $data->link_action = $request->link_action;
          
          if($request->file('image')!= null){
              $data->image = $request->file('image')->store('images');
          }else{
              $data->image = $request->hidden_image;
          }

          if($request->file('image_m')!= null){
              $data->image_m = $request->file('image_m')->store('images');
          }else{
              $data->image_m = $request->hidden_image_m;
          }

          $data->active = $request->active;
          $data->updated_by = session('user.id');
          $data->save(); 

          return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));
    }

    public function destroy($id)
    {
      DB::table('blogs')
      ->where('id',$id)
      ->delete();

      return redirect()->back()->with(session()->flash('alert-success', 'Item has been deleted successfully.'));
    }

    /*============================
       End News Post
       ============================*/

     

}
