<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    // Display the cart items for the current user
    public function index()
    {
        $cartItems = Cart::where('user_id', Auth::id())->with('product')->get();
        $page = 'Cart';
        return view('cart', compact('cartItems', 'page'));
    }

    // Add a product to the cart
    public function add(Request $request, $productId)
    {
        $product = Product::find($productId);

        if ($product) {
            $cartItem = Cart::firstOrCreate(
                ['user_id' => Auth::id(), 'product_id' => $productId],
                ['quantity' => 1]
            );

            // Optionally, you can increase the quantity if it already exists
            if ($cartItem->quantity < $product->stock) {
                $cartItem->increment('quantity');
            }

            return redirect()->route('cart.index')->with('success', 'Product added to cart!');
        }

        return redirect()->route('cart.index')->with('error', 'Product not found!');
    }

    // Remove a product from the cart
    public function remove($productId)
    {
        $cartItem = Cart::where('user_id', Auth::id())->where('product_id', $productId)->first();

        if ($cartItem) {
            $cartItem->delete();
            return redirect()->route('cart.index')->with('success', 'Product removed from cart!');
        }

        return redirect()->route('cart.index')->with('error', 'Product not found in cart!');
    }

    // Update the quantity of a cart item
    public function update(Request $request, $productId)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1',
        ]);

        $cartItem = Cart::where('user_id', Auth::id())->where('product_id', $productId)->first();

        if ($cartItem) {
            $cartItem->update(['quantity' => $request->quantity]);
            return redirect()->route('cart.index')->with('success', 'Cart updated!');
        }

        return redirect()->route('cart.index')->with('error', 'Product not found in cart!');
    }
}
