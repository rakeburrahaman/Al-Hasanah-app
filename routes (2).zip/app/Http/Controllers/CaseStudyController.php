<?php

namespace App\Http\Controllers;

use App\Models\CaseStudy;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use DB;

class CaseStudyController extends Controller
{
    public function index()
    {
        $data = CaseStudy::orderBy('id', 'desc')
              ->where('client_id', session('client_id'))
              ->where('active', 'on')
              ->get();
        return view('admin.case_study.index', ['data'=>$data]);        
    }

    public function create()
    {        
      return view('admin.case_study.create');
    }

    public function store(Request $request)
    {      
     // dd($request);  
      $data = new CaseStudy;
      $data->customer_id = $request->customer_id; 
      $data->age_ = $request->age_;  
      $data->gender = $request->gender; 
      $data->reference_no = $request->reference_no;  
      $data->date = $request->date;  
      $data->symptoms = $request->symptoms;  
      $data->diabetes_days = $request->diabetes_days;  
      $data->previous_treatment = $request->previous_treatment;  
      $data->monthly_expenses = $request->monthly_expenses;  
      $data->height = $request->height;  
      $data->Weight = $request->weight;  
      $data->extra_weight = $request->extra_weight;  
      $data->bmi = $request->bmi;  
      $data->hip = $request->hip;  
      $data->waist = $request->waist;  
      $data->temperature = $request->temperature;  
      $data->pulse_rate = $request->pulse_rate;  
      $data->blood_pressure = $request->blood_pressure;  
      $data->lying_down = $request->lying_down;  
      $data->while_standing = $request->while_standing;  
      $data->heart = $request->heart;  
      $data->lungs = $request->lungs; 
      $data->liver = $request->liver;
      $data->spleen = $request->spleen;
      $data->nervous_system = $request->nervous_system;
      $data->power_of_vision = $request->power_of_vision;
      $data->right_eye = $request->right_eye;
      $data->left_eye = $request->left_eye;  
      $data->leg_blood_circulation = $request->leg_blood_circulation;  
      $data->allergy_to_medicine = $request->allergy_to_medicine;
      $data->fundoscopic_test = $request->fundoscopic_test;
      $data->others = $request->others;

      $data->active = 'on';
      $data->created_by = session('user_id');
      $data->client_id = session('client_id');
      $data->updated_by = '';
      $data->save();  
      $data->id;

      return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));

    }

    public function edit($id){
      $data = CaseStudy::find($id);      
      return view('admin.case_study.edit', ['data'=>$data]);
    }

    public function update(Request $request)
    {       
          $data = CaseStudy::find($request->id);
          $data->customer_id = $request->customer_id;  
          $data->age_ = $request->age_;  
          $data->gender = $request->gender;  
          $data->reference_no = $request->reference_no;  
          $data->date = $request->date;  
          $data->symptoms = $request->symptoms;  
          $data->diabetes_days = $request->diabetes_days;  
          $data->previous_treatment = $request->previous_treatment;  
          $data->monthly_expenses = $request->monthly_expenses;  
          $data->height = $request->height;  
          $data->Weight = $request->weight;  
          $data->extra_weight = $request->extra_weight;  
          $data->bmi = $request->bmi;  
          $data->hip = $request->hip;  
          $data->waist = $request->waist;  
          $data->temperature = $request->temperature;  
          $data->pulse_rate = $request->pulse_rate;  
          $data->blood_pressure = $request->blood_pressure;  
          $data->lying_down = $request->lying_down;  
          $data->while_standing = $request->while_standing;  
          $data->heart = $request->heart;  
          $data->lungs = $request->lungs; 
          $data->liver = $request->liver;
          $data->spleen = $request->spleen;
          $data->nervous_system = $request->nervous_system;
          $data->power_of_vision = $request->power_of_vision;
          $data->right_eye = $request->right_eye;
          $data->left_eye = $request->left_eye;  
          $data->leg_blood_circulation = $request->leg_blood_circulation;  
          $data->allergy_to_medicine = $request->allergy_to_medicine;
          $data->fundoscopic_test = $request->fundoscopic_test;
          $data->others = $request->others;
         
          $data->active = $request->active;
          $data->updated_by = session('user_id');
          $data->save(); 

          return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));
    }

    public function show($id){
      $data = CaseStudy::find($id);      
      return view('admin.case_study.show', ['data'=>$data]);
    }
    public function destroy($id)
    {
      // DB::table('CaseStudys')
      // ->where('id',$id)
      // ->delete();
      $data = CaseStudy::find($id);
      $data->active = null;
      $data->save();

      return redirect()->back()->with(session()->flash('alert-success', 'CaseStudy has been deleted successfully.'));
    }
}
