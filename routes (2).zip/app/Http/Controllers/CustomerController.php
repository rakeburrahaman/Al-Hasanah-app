<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use DB;

class CustomerController extends Controller
{
    public function index()
    {
        $data = Customer::orderBy('id', 'desc')->where('client_id', session('client_id'))->get();
        return view('admin.customers', ['data'=>$data]);        
    } 
    
      public function Customers()
      {     
        $data = Customer::orderBy('id', 'desc')->where('client_id', session('client_id'))->get();
        return view('admin.customers', ['data'=>$data]);
      } 

      public function create()
      {        
        return view('admin.customer_add');
      }

      public function patients()
      {
          $data = Customer::orderBy('id', 'desc')
                ->where('type', 'IPD')
                ->where('client_id', session('client_id'))
                ->where('active', null)
                ->get();
          return view('admin.patients', ['data'=>$data]);        
      }   
      public function releasePatients()
      {
          $data = Customer::orderBy('id', 'desc')->where('type', 'IPD')->where('client_id', session('client_id'))->where('active', 'on')->get();
          return view('admin.patients_release', ['data'=>$data]);        
      }  

      public function createPatient()
      {        
        return view('admin.patient_add');
      }

      public function save_admission(Request $request)
      {        
        $data = new Customer;
        $data->title = $request->title;       
        $data->slug = Str::slug($request->title);
        $data->sub_title = $request->sub_title;
        $data->type = 'IPD'; 
        $data->mobile = $request->mobile;
        $data->email = $request->email;
        $data->parent = $request->parent;
        $data->guardian = $request->guardian;
        $data->occupation = $request->occupation; 
        $data->religion = $request->religion; 
        $data->admission_reason = $request->admission_reason;
        $data->admission_date = $request->admission_date;
        $data->release_date = $request->release_date;
        $data->description = $request->description;
        $data->short_description = $request->short_description;
        $data->address = $request->address;
        $data->age = $request->age;
        $data->gender = $request->gender;
        $data->contract_amount = $request->contract_amount;
        $data->surgeon = $request->surgeon;
        $data->gender = $request->gender;
        $data->bed_type = $request->bed_type;
        $data->bed_no = $request->bed_no;
        
        if($request->file('image')!= null){
            $data->image = $request->file('image')->store('images');
        } 
        $data->active = $request->active;
        $data->client_id = session('client_id');
        $data->created_by = session('user_id');
        $data->updated_by = '';
        $data->save();

        //dd($request);
        return redirect()->back()->with(session()->flash('alert-success', 'Data has been inserted successfully.'));    

      } 
      public function editPatient($id){
        $data = Customer::find($id);      
        return view('admin.patient_edit', ['data'=>$data]);
      }
      public function update_admission(Request $request)
      {        
        $data = Customer::find($request->id);
        $data->title = $request->title;       
        $data->slug = Str::slug($request->title);
        $data->sub_title = $request->sub_title;
        $data->type = 'IPD'; 
        $data->mobile = $request->mobile;
        $data->email = $request->email;
        $data->parent = $request->parent;
        $data->guardian = $request->guardian;
        $data->occupation = $request->occupation; 
        $data->religion = $request->religion; 
        $data->admission_reason = $request->admission_reason;
        $data->admission_date = $request->admission_date;
        if($request->active == 'on'){
          $data->release_date = $request->release_date;
        }else{
          $data->release_date = null;
        }
        $data->description = $request->description;
        $data->short_description = $request->short_description;
        $data->address = $request->address;
        $data->age = $request->age;
        $data->gender = $request->gender;
        $data->contract_amount = $request->contract_amount;
        $data->surgeon = $request->surgeon;
        $data->gender = $request->gender;
        $data->bed_type = $request->bed_type;
        $data->bed_no = $request->bed_no;
        
        if($request->file('image')!= null){
            $data->image = $request->file('image')->store('images');
        } 
        $data->active = $request->active;
        $data->client_id = session('client_id');
        $data->created_by = session('user_id');
        $data->updated_by = '';
        $data->save();

        //dd($request);
        return redirect()->back()->with(session()->flash('alert-success', 'Data has been inserted successfully.'));    

      } 
      public function store(Request $request)
      {        
        $data = new Customer;
        $data->title = $request->title;       
        $data->slug = Str::slug($request->title);
        //dd($data->slug);
        $data->sub_title = $request->sub_title;
        $data->mobile = $request->mobile;
        $data->email = $request->email;
        $data->parent = $request->parent;
        $data->description = $request->description;
        $data->short_description = $request->short_description;
        $data->address = $request->address;
        $data->age = $request->age;
        $data->gender = $request->gender;
        
        if($request->file('image')!= null){
            $data->image = $request->file('image')->store('images');
        } 
        $data->active = $request->active;
        $data->client_id = session('client_id');
        $data->created_by = session('user_id');
        $data->updated_by = '';
        $data->save();

        return redirect()->back()->with(session()->flash('alert-success', 'Data has been inserted successfully.'));    

      }
      public function edit($id, $source=null){
        $data = Customer::find($id);      
        return view('admin.customer_edit', ['data'=>$data, 'source'=>$source]);
      }

      public function show($id){
        $data = Customer::find($id);      
        return view('admin.customer_details', ['data'=>$data]);
      }

      public function update(Request $request)
      {       
          $data = Customer::find($request->id);
          $data->title = $request->title;
          $data->sub_title = $request->sub_title;
          $data->mobile = $request->mobile;
          $data->email = $request->email;
          $data->parent = $request->parent;
          $data->description = $request->description;
          $data->short_description = $request->short_description;
          $data->address = $request->address;
          $data->age = $request->age;
          $data->gender = $request->gender;

          
          
          if($request->file('image')!= null){
              $data->image = $request->file('image')->store('images');
          }else{
              $data->image = $request->hidden_image;
          }
          $data->active = $request->active;
          $data->client_id = session('client_id');
          $data->updated_by = session('user_id');
          $data->save(); 

          if($request->source != null){
            return redirect('invoice-preview/' . $request->source);
          }
          return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));
    }

    public function destroy($id)
    {
      DB::table('customers')
      ->where('id',$id)
      ->delete();

      return redirect()->back()->with(session()->flash('alert-success', 'Customer has been deleted successfully.'));
    }

    /*============================
       End News Post
       ============================*/

     

}
