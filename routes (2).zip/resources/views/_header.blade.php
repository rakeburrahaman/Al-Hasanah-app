	<!-- header-area start -->
	<header class="header-area ">
		<div class="container">
			<div class="row g-0">
				<div class="col-lg-12 col-md-12">
					<div class="header__part">
						<div class="header_logo">
							<a href="#">
								<img src="{{asset('frontend/img/nav_logo.png')}}" alt="logo" />

							</a>
						</div>
						<div class="main_header_nav">
							<div class="menu_close" onclick="myFunction(this)">
								<div class="bar1"></div>
								<div class="bar2"></div>
								<div class="bar3"></div>
							</div>
							<div class="header_nav">
								<ul>
									<li class="active"><a href="/">Home</a></li>
									<li><a href="asphalt">Asphalt</a></li>
									<li><a href="consulting">Consulting</a></li>
									<li><a href="lab">Lab</a></li>
									<li><a href="#">Contact</a></li>
								</ul>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- header-area end --> 



<!-- header-area start -->
		{{-- <header class="header-area">
			<div class="container">
				<div class="row g-0">
					<div class="col-lg-12 col-md-12">
						<div class="header__part">
							<div class="header_logo_d">
								<a href="https://kindjoe.dinocodela.com/">
									<img src="{{asset('frontend/img/desktop_logo.png')}}" alt="logo" />
								</a>																		
							</div>
							<div class="header_logo_m">  
								<a href="https://kindjoe.dinocodela.com/">
									<img src="{{asset('frontend/img/Logo_m.png')}}" alt="logo" />
								</a>  
							</div>

							<div class="main_header_nav">
								<div class="menu_close" onclick="myFunction(this)">
									<div class="bar1"></div>
									<div class="bar2"></div>
									<div class="bar3"></div>
								</div>  
								<div class="header_nav">
									<ul>
										
										<li class="@if ($page=='home') active @endif"><a href="/">Home</a></li>
										<li class="@if ($page=='about') active @endif"><a href="/"><a href="{{'our-story'}}">Our Story</a></li>
										<li class="@if ($page=='project') active @endif"><a href="/"><a href="{{'our-project'}}">Our Project</a></li>
										<li class="@if ($page=='benifit') active @endif"><a href="/"><a href="{{'benifits'}}">Benefits for You</a></li>
									</ul>
								</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</header> --}}
		<!-- header-area end -->
