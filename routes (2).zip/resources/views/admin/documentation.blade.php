<html>


<h3 class="">Nahar Traders Software Setup Guide:</h3>

<ul>
    <ol>1. company add kora lagte pare </ol>
    <ol>2. product category amar sate discuss kore add korben, ami 3 ta koresi. ar baire kisu hobar kotha na. amra sub category use e korbo na.</ol>
    <ol>3. product add korar somoy subcategory debar dorkar nai.  </ol>
    <ol>4. product ar model/size ta khub important. atar upor depend kore auto chalan korar somoy (sft -> box) a convert kora hoy</ol>
</ul>
    
</html>
