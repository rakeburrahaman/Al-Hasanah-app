
@extends('admin.master')
@section('main_content')    

  <div class="page-content container container-plus">
    <div class="page-header pb-2">
      <h1 class="page-title text-primary-d2 text-150">
        Add New Lead     
      </h1> 
      <a href="leads"class="btn btn-default px-3 text-95 radius-round border-2 brc-black-tp10 float-left">
        <i class="fa fa-list mr-1"></i>
        <span class="d-sm-none d-md-inline">All</span> Leads
      </a>
    </div>   


    <div class="row-md-3">
      <div class="col-12">
        <div class="card dcard">
          <div class="card-body px-1 px-md-3">                                   
            <div role="main" class="main-content">         
              <div class="page-content container container-plus">               

                <form action="save-lead" method="post" enctype="multipart/form-data">
                  @csrf
                    <div class="row">                      
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">First Name</label>
                          <input type="text" class="form-control" name="FNAME" id="FNAME" placeholder="First name here" required="" autofocus />
                        </div>  
                      </div>

                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">Last Name</label>
                          <input type="text" class="form-control" name="LNAME" id="LNAME" placeholder="Last name here" required="" />
                        </div>  
                      </div>
                      
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">Email</label>
                          <input type="email" class="form-control" name="EMAIL" id="EMAIL" placeholder="Email address" required="" />
                        </div>  
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">Cell Phone</label>
                          <input type="text" class="form-control" name="CELL_PHONE" id="CELL_PHONE" placeholder="Phone number" required="" />
                        </div>  
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">Best time to call</label>
                          <input type="text" class="form-control" name="BEST_TIME_TO_CALL" id="BEST_TIME_TO_CALL" placeholder="Best time" />
                        </div>  
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">Client</label>

                          <select class="form-control ss" name="client" id="client" >
                            <option value="">Select client</option>
                                <option value="fedtax">Fedtax</option>
                                {{-- <option value="thekindfirm">Thekindfirm</option> --}}
                                {{-- <option value="blueoceantax">Blueoceantax</option> --}}
                                <option value="taxadvocate">Taxadvocate</option>
                                <option value="ftlg">Optimum tax</option>
                                <option value="fivestar">Five Star</option>
                                  {{--  <option value="ustaxresolution">US Tax Resolution</option>
                                <option value="practicaltax">Practical Tax</option>
                                  <option value="taxnetusainc">Tax Netusainc</option>
                                  --}}
                                <option value="allstartax">All Star Tax</option>
                                <option value="mangotax">Mango Tax</option>
                                <option value="andersontax">Anderson Tax</option>
                                <option value="wtaxattorney">W Tax Attorney</option>
                                <option value="ptr">Perfect Tax Relief </option>
                          </select>
                        </div>  
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">Officer Name</label>
                          <input type="text" class="form-control" name="OFFICERNAME" id="OFFICERNAME" placeholder="Officer name" /> 
                        </div>  
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">Source Code</label>
                          <input type="text" class="form-control" name="LEAD_PROVIDER_ID" id="sourceCode" placeholder="Source code" /> 
                        </div>  
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">Tax Relief Tax Amount</label>
                          <input type="text" class="form-control" name="TAX_RELIEF_TAX_AMOUNT" id="" placeholder="Tax Amount" /> 
                        </div>  
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">Short Notes</label>
                          <textarea name="NOTES" rows="1" id="NOTES" class="form-control" placeholder="notes"> </textarea>
                        </div>  
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">TI Notes</label>
                          <textarea name="ti_notes" rows="1" id="" class="form-control" placeholder="TI Notes"> </textarea>
                        </div>  
                      </div>

                    </div>

                 

                    <div class="row d-none">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label for="">Description</label>
                          <textarea id="summernote" name="description" rows="1">
                          </textarea>  
                        </div>
                      </div>
                    </div>
                  <button type="submit" class="btn btn-primary">Submit</button>
                  <a href="add-lead" class="btn btn-default">Cancel</a>
                </form>
              </div>
            </div>    
          </div>
        </div>           
      </div>
    </div>
  </div>
@endsection