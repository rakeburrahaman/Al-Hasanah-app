@php $posts = DB::table('posts')->where('page', 'Contact')->where('active', 'on')->get();@endphp
<?php
use App\Models\Setting;
$settings = Setting::find(1);
?>

@extends('layouts.master')
  @section('main_content')

  <div class="contact-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <form class="contact-form mb-10">
                    <div class="section-header section-header5 text-start">
                        <div class="wrapper">
                            <div class="sub-content">
                                <img class="line-1" src="assets/images/banner/wvbo-icon.png" alt="">
                                <span class="sub-text">Contact Us</span>
                            </div>
                            <h2 class="title">MAKE CUSTOM REQUEST</h2>
                        </div>
                    </div>
                    <div class="info-form">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="input-box mb-20">
                                    <input type="text" id="validationDefault01" placeholder="Full Name" required>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="input-box mail-input mb-20">
                                    <input type="email" id="validationDefault02" placeholder="E-mail Address"
                                        required>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="input-box number-input mb-30">
                                    <input type="number" id="validationDefault03" placeholder="Phone Number"
                                        required>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="input-box sub-input mb-30">
                                    <input type="text" id="validationDefault04" placeholder="Subject..." required>
                                </div>
                            </div>
                            <div class="col-lg-12 col-sm-12">
                                <div class="input-box text-input mb-20">
                                    <textarea name="Message" id="validationDefault05" cols="30" rows="10"
                                        placeholder="Enter message" required></textarea>
                                </div>
                            </div>
                            <div class="col-12 mb-15">
                                <a href="#" class="form-btn form-btn4">
                                    Send Message
                                </a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-4">
                <div class="right-side">
                    <div class="get-in-touch">
                        <h3 class="section-title2">
                            GET IN TOUCH
                        </h3>
                        <div class="contact">
                            <ul>
                                <li class="one">
                                    226, Paikpara, Bottola,<br> Aqua Garden,<br> Mirpur, Dhaka-1216
                                </li>
                                <li class="two"><a href="tel:{{ $settings->mobile }}">{{ $settings->mobile }}</a>
                                    <a href="{{ $settings->mobile }}">{{ $settings->mobile }}</a></li>
                                <li class="three">9:00 AM-10:00 PM</li>
                            </ul>
                        </div>
                    </div>
                    <div class="section-button">
                        <div class="btn-1">
                            <a href="#">Get Support On Call <i class="fal fa-headphones-alt"></i></a>
                        </div>
                        <div class="btn-2">
                            <a href="#">Get Direction <i class="rt-location-dot"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="map">
        <p><iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14607.743863270267!2d90.3455712!3d23.8280263!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c13a21730b43%3A0xb14a9c52d01c00d9!2sMirpur-12%20Bus%20Stand!5e0!3m2!1sen!2sbd!4vYOUR_EMBED_ID"
                 height="500" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe></p>
    </div>
</div>
		
 
@endsection