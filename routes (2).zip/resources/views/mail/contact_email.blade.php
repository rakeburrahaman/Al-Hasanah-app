Name: {{$email_data['name']}} <br>
{{-- Phone: {{$email_data['phone']}} <br> --}}
Subject: {{$email_data['subject']}}<br>
Email: {{$email_data['email']}}<br><br>
Message: <hr>
{{$email_data['message']}} 
