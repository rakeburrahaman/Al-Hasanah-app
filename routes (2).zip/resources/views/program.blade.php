<?php $posts = DB::table('posts')->where('page', 'Blog')->where('active', 'on')->get(); ?>

@extends('layouts.master')
@section('main_content')


		
</style>

<section class="page-header">
	<div class="page-header__bg" style="background-image: url('{{ asset('frontend/assets/images/about.png') }}');"></div>
<!-- /.page-header__bg -->
	<div class="container">
		<div class="page-header__content">
			<h2 class="page-header__title">program </h2>
			<ul class="cherito-breadcrumb list-unstyled">
				<li><a href="/">Home</a></li>
				<li><span>Program</span></li>
			</ul><!-- /.cherito-breadcrumb list-unstyled -->
		</div><!-- /.page-header__content -->
	</div><!-- /.container -->
</section><!-- /.page-header -->




<section class="donations-one section-space">
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				{{-- <img src="{{ asset('frontend/assets/images/shapes/sec-title-s-1-1.png') }}" alt="shape" class="sec-title__shape"> --}}
				{{-- <h6 class="sec-title__tagline">Help & Donate</h6> --}}
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">Our Running Program</h3><!-- /.sec-title__title -->
		</div>
		<div class="row gutter-y-30">
			@foreach ($running_programs as $item)
				
				<div class="col-lg-6 col-md-6">
					<div class="blog-card-five wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='00ms'>
						<div class="blog-card-five__image">
							<img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->title}}">
							<a href="/program/{{$item->slug}}" class="blog-card-five__image__link"><span class="sr-only">{{$item->title}}</span></a>
						</div><!-- /.blog-card-five__image -->
						<div class="blog-card-five__content">
							<div class="blog-card-five__meta d-none">
								<div class="blog-card-five__admin">
									<div class="blog-card-five__admin__image">
										{{-- <img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->title}}"> --}}
									</div><!-- /.blog-card-five__admin__image -->
									<div class="blog-card-five__admin__content">
										<h3 class="blog-card-five__admin__name"><a href="#">Darrell Steward</a></h3>
										<p class="blog-card-five__admin__designation">Admin</p>
									</div><!-- /.blog-card-five__admin__content -->
								</div><!-- /.blog-card-five__admin -->
								<div class="blog-card-five__date">
									<div class="blog-card-five__date__1">10</div><!-- /.blog-card-five__date__1 -->
									<div class="blog-card-five__date__2">
										<div>
											<span>Mar,</span>
											<span>2024</span>
										</div>
									</div><!-- /.blog-card-five__date__2 -->
								</div><!-- /.blog-card-five__date -->
							</div><!-- /.blog-card-five__meta -->
							<h3 class="blog-card-five__title"><a href="/program/{{$item->slug}}">{{$item->title}}</a></h3><!-- /.blog-card-five__title -->
							<p class="blog-card-five__text">{!! $item->description !!}</p>
							
							<div class="blog-card-five__button">
								<a href="/program/{{$item->slug}}" class="cherito-btn">
									<span class="cherito-btn__text">Read More</span>
									<span class="cherito-btn__hover cherito-btn__hover--1"></span>
									<span class="cherito-btn__hover cherito-btn__hover--2"></span>
									<span class="cherito-btn__hover cherito-btn__hover--3"></span>
									<span class="cherito-btn__hover cherito-btn__hover--4"></span>
									<span class="cherito-btn__hover cherito-btn__hover--5"></span>
								</a><!-- /.cherito-btn -->
							</div><!-- /.blog-card-five__button -->
						</div><!-- /.blog-card-five__content -->
					</div><!-- /.blog-card-five -->
				</div><!-- /.col-lg-4 col-md-6 -->
			@endforeach


		</div><!-- /.row -->
		
		
		
		
		
		<!-- /.sec-title -->
	</div><!-- /.container -->
	
			
			

	</div><!-- /.donations-one__container container -->
</section><!-- /.donations-one section-space -->

<section class="donations-one section-space" style="background-color: #f9f4e8">
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				{{-- <img src="{{ asset('frontend/assets/images/shapes/sec-title-s-1-1.png') }}" alt="shape" class="sec-title__shape"> --}}
				{{-- <h6 class="sec-title__tagline">Help & Donate</h6> --}}
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">Our Upcomming Program</h3><!-- /.sec-title__title -->
		</div>
		<div class="row gutter-y-30">
			@foreach ($upcomming_programs as $item)
				
				<div class="col-lg-4 col-md-4">
					<div class="blog-card-five wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='00ms'>
						<div class="blog-card-five__image">
							<img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->title}}">
							<a href="/program/{{$item->slug}}" class="blog-card-five__image__link"><span class="sr-only">{{$item->title}}</span></a>
						</div><!-- /.blog-card-five__image -->
						<div class="blog-card-five__content">
							<div class="blog-card-five__meta d-none">
								<div class="blog-card-five__admin">
									<div class="blog-card-five__admin__image">
										<img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->title}}">
									</div><!-- /.blog-card-five__admin__image -->
									<div class="blog-card-five__admin__content">
										<h3 class="blog-card-five__admin__name"><a href="#">Darrell Steward</a></h3>
										<p class="blog-card-five__admin__designation">Admin</p>
									</div><!-- /.blog-card-five__admin__content -->
								</div><!-- /.blog-card-five__admin -->
								<div class="blog-card-five__date">
									<div class="blog-card-five__date__1">10</div><!-- /.blog-card-five__date__1 -->
									<div class="blog-card-five__date__2">
										<div>
											<span>Mar,</span>
											<span>2024</span>
										</div>
									</div><!-- /.blog-card-five__date__2 -->
								</div><!-- /.blog-card-five__date -->
							</div><!-- /.blog-card-five__meta -->
							<h3 class="blog-card-five__title"><a href="/program/{{$item->slug}}">{{$item->title}}</a></h3><!-- /.blog-card-five__title -->
							<p class="blog-card-five__text">{!! $item->short_description !!}</p>
							
							<div class="blog-card-five__button">
								<a href="/program/{{$item->slug}}" class="cherito-btn">
									<span class="cherito-btn__text">Read More</span>
									<span class="cherito-btn__hover cherito-btn__hover--1"></span>
									<span class="cherito-btn__hover cherito-btn__hover--2"></span>
									<span class="cherito-btn__hover cherito-btn__hover--3"></span>
									<span class="cherito-btn__hover cherito-btn__hover--4"></span>
									<span class="cherito-btn__hover cherito-btn__hover--5"></span>
								</a><!-- /.cherito-btn -->
							</div><!-- /.blog-card-five__button -->
						</div><!-- /.blog-card-five__content -->
					</div><!-- /.blog-card-five -->
				</div><!-- /.col-lg-4 col-md-6 -->
			@endforeach


		</div><!-- /.row -->
		
		
		
		
		
		<!-- /.sec-title -->
	</div><!-- /.container -->
	
			
			

	</div><!-- /.donations-one__container container -->
</section><!-- /.donations-one section-space -->

<section class="donations-one section-space">
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				{{-- <img src="{{ asset('frontend/assets/images/shapes/sec-title-s-1-1.png') }}" alt="shape" class="sec-title__shape"> --}}
				{{-- <h6 class="sec-title__tagline">Help & Donate</h6> --}}
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">Ramadan Connect 2025</h3><!-- /.sec-title__title -->
		</div>
		<div class="row gutter-y-30">
			@foreach ($special as $item)
				
				<div class="col-lg-4 col-md-4">
					<div class="blog-card-five wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='00ms'>
						<div class="blog-card-five__image">
							<img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->title}}">
							<a href="/program/{{$item->slug}}" class="blog-card-five__image__link"><span class="sr-only">{{$item->title}}</span></a>
						</div><!-- /.blog-card-five__image -->
						<div class="blog-card-five__content">
							<div class="blog-card-five__meta d-none">
								<div class="blog-card-five__admin">
									<div class="blog-card-five__admin__image">
										<img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->title}}">
									</div><!-- /.blog-card-five__admin__image -->
									<div class="blog-card-five__admin__content">
										<h3 class="blog-card-five__admin__name"><a href="#">Darrell Steward</a></h3>
										<p class="blog-card-five__admin__designation">Admin</p>
									</div><!-- /.blog-card-five__admin__content -->
								</div><!-- /.blog-card-five__admin -->
								<div class="blog-card-five__date">
									<div class="blog-card-five__date__1">10</div><!-- /.blog-card-five__date__1 -->
									<div class="blog-card-five__date__2">
										<div>
											<span>Mar,</span>
											<span>2024</span>
										</div>
									</div><!-- /.blog-card-five__date__2 -->
								</div><!-- /.blog-card-five__date -->
							</div><!-- /.blog-card-five__meta -->
							<h3 class="blog-card-five__title"><a href="/program/{{$item->slug}}">{{$item->title}}</a></h3><!-- /.blog-card-five__title -->
							<p class="blog-card-five__text">{!! $item->short_description !!}</p>
							
							<div class="blog-card-five__button">
								<a href="/program/{{$item->slug}}" class="cherito-btn">
									<span class="cherito-btn__text">Read More</span>
									<span class="cherito-btn__hover cherito-btn__hover--1"></span>
									<span class="cherito-btn__hover cherito-btn__hover--2"></span>
									<span class="cherito-btn__hover cherito-btn__hover--3"></span>
									<span class="cherito-btn__hover cherito-btn__hover--4"></span>
									<span class="cherito-btn__hover cherito-btn__hover--5"></span>
								</a><!-- /.cherito-btn -->
							</div><!-- /.blog-card-five__button -->
						</div><!-- /.blog-card-five__content -->
					</div><!-- /.blog-card-five -->
				</div><!-- /.col-lg-4 col-md-6 -->
			@endforeach
		</div><!-- /.row -->
	</div><!-- /.container -->
	</div><!-- /.donations-one__container container -->
</section><!-- /.donations-one section-space -->


<section class="contact-page section-space " style="background-color: #f9f4e8">
    <div class="container">
        <div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
            <div class="sec-title__top">
              {{-- <img src="{{ asset('frontend/assets/images/blog/blog-admin-1-1.png') }}" alt="Wade Warren"> --}}

                <h6 class="sec-title__tagline">Contact  us</h6><!-- /.sec-title__tagline -->
            </div><!-- /.sec-title__top -->
            <h3 class="sec-title__title">Have Any Queries?</h3><!-- /.sec-title__title -->
        </div><!-- /.sec-title -->
        <div class="contact-page__form wow fadeInUp" data-wow-duration="1500ms">
            <form action="/save_donetion" method="post" class="contact-form  form-one">
                @csrf
                    <div class="form-one__group">

                        <div class="form-one__control">First Name
                            <input type="text" name="fname" placeholder="Enter First Name">
                        </div><!-- /.form-one__control -->
                        <div class="form-one__control">Last Name
                            <input type="text" name="lname" placeholder="Enter Last Name">
                        </div><!-- /.form-one__control -->

						<div class="form-one__control">Email
                            <input type="email" name="email" placeholder="Email Address">
                        </div><!-- /.form-one__control -->

						
						{{-- <div class="form-one__control">
							<label>Donation Amount</label>
							<div class="donation-options ">
								<label><input type="radio" name="amount" value="25" required> $25</label>
								<label><input type="radio" name="amount" value="50"> $50</label>
								<label><input type="radio" name="amount" value="100"> $100</label>
								<label><input type="radio" name="amount" value="250"> $250</label>
							</div>
						</div> --}}
						<div class="form-one__control">
							<label>Donation Amount</label>
							<div class="donation-options-row">
								<label><input type="radio" name="amount" value="25" required> $25</label>
								<label><input type="radio" name="amount" value="50"> $50</label>
								<label><input type="radio" name="amount" value="100"> $100</label>
								<label><input type="radio" name="amount" value="250"> $250</label>
							</div>
						</div>
						
						
						
                        <div class="form-one__control">Stripe Email Card
                            <input type="email" name="stripe_email_card" placeholder="Email">
                        </div><!-- /.form-one__control -->

						
                        <div class="form-one__control">Card No
                            <input type="text" name="card_no" placeholder="Enter your card no">
                        </div><!-- /.form-one__control -->

                        <div class="form-one__control">Expiration Date
                            <input type="text" name="ex_date" placeholder="Expiration Date">
                        </div><!-- /.form-one__control -->

						
                        <div class="form-one__control">Security Code
                            <input type="text" name="s_code" placeholder="Enter Your Security Code">
                        </div><!-- /.form-one__control -->

						<div class="form-one__control form-one__control--full">
							<label for="country">Country</label>
							<select class="selectpicker" id="country" name="country" required>
								<option value="">Select Country</option>
								<option value="us">United States</option>
								<option value="ca">Canada</option>
								<option value="uk">United Kingdom</option>
								<option value="bd">Bangladesh</option>
								<option value="other">Other</option>
							</select>
                        </div><!-- /.form-one__control -->


                      
                        
                       
                        <div class="form-one__control form-one__control--full">I am contributing to Markham Community Connect in this way… *
                            <textarea name="message" placeholder="Write Message . . ."></textarea>
                        </div><!-- /.form-one__control -->

						<div class="form-group form-one__control form-one__control--full">
							<legend>Categories I am participating in (select up to two)</legend>
							<label><input type="radio" name="category" value="quran"> Quran Recitation Challenge (Boys and Girls, Ages 11–14)</label>
							<label><input type="radio" name="category" value="muazzin"> The Mu’azzin Challenge (Boys 11–14)</label>
							<label><input type="radio" name="category" value="asmaul"> Asma'ul Husna Challenge (Girls 11–14)</label>
							<label><input type="radio" name="category" value="ramadan"> The Ramadan Home Challenge (Family)</label>
						</div>
				
						<div class="form-group form-one__control">
							<legend>I have read the rules and judging criteria</legend>
							<label><input type="radio" name="rules" value="yes" required> Yes</label>
							<label><input type="radio" name="rules" value="no" required> No</label>
						</div>
						
						<div class="form-group form-one__control">
							<legend>I have submitted my video on [LINK]</legend>
							<label><input type="radio" name="video_submission" value="yes" required> Yes</label>
							<label><input type="radio" name="video_submission" value="no" required> No</label>
						</div>
						
				
						
						<div class="form-one__control form-one__control--full">Your video link
                            <input type="text" name="video_link" placeholder="Upload your video link" class="video_link">
                        </div><!-- /.form-one__control -->


                        <div class="form-one__control contact-page__form__button form-one__control--full">

                            <input type="hidden" name="type" value="Contact Form">
                            <button type="submit" class="cherito-btn btn btn-primary cherito-btn1">
                                <span class="cherito-btn__text">Send Message</span>
                                {{-- <span class="cherito-btn__hover cherito-btn__hover--1"></span>
                                <span class="cherito-btn__hover cherito-btn__hover--2"></span>
                                <span class="cherito-btn__hover cherito-btn__hover--3"></span>
                                <span class="cherito-btn__hover cherito-btn__hover--4"></span>
                                <span class="cherito-btn__hover cherito-btn__hover--5"></span> --}}
                            </button><!-- /.cherito-btn -->
                        </div><!-- /.form-one__control -->

						
						
                    </div><!-- /.form-one__group -->
            </form>
            <!-- /.form-one -->
            <div class="result"></div><!-- /.result -->
        </div><!-- /.contact-page__form -->
    </div><!-- /.container -->
  </section><!-- /.contact-page section-space -->

<section class="cta-one d-none">
	<div class="container">
		<div class="row gutter-y-30 align-items-center">
			<div class="col-lg-8 wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
				<div class="cta-one__content">
					<div class="sec-title">
						<h2 class="sec-title__title">Let’s Make a Difference in The <br> Lives of Others</h2><!-- /.sec-title__title -->
					</div><!-- /.sec-title -->
				</div><!-- /.cta-one__content -->
			</div><!-- /.col-lg-8 -->
			<div class="col-lg-4 wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
				<div class="cta-one__button">
					<a href="become-a-volunteer.html" class="cherito-btn cherito-btn--black">
						<span class="cherito-btn__text">Become a Volunteer</span>
						<span class="cherito-btn__hover cherito-btn__hover--1"></span>
						<span class="cherito-btn__hover cherito-btn__hover--2"></span>
						<span class="cherito-btn__hover cherito-btn__hover--3"></span>
						<span class="cherito-btn__hover cherito-btn__hover--4"></span>
						<span class="cherito-btn__hover cherito-btn__hover--5"></span>
					</a><!-- /.cherito-btn -->
				</div><!-- /.cta-one__button -->
			</div><!-- /.col-lg-4 -->
		</div><!-- /.row gutter-y-30 -->
	</div><!-- /.container -->
	<img src="{{ asset('frontend/assets/images/shapes/cta-shape-1-1.png') }}" alt="shape" class="cta-one__shape">
</section>






 @endsection