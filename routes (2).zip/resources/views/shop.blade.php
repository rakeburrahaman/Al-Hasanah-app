@extends('layouts.master')
@section('main_content')

    <!--================= Shop Section Start Here =================-->
    <div class="rts-shop-section">
        <div class="container">
            <div class="row">
                <div class="col-xl-9">
                    <div class="shop-product-topbar">
                        <span class="items-onlist">Showing 1-12 of 70 results</span>
                        <div class="filter-area">
                            <p class="select-area">
                                <select class="select">
                                    <option value="*">Sort by average rating</option>
                                    <option value=".popular">Sort by popularity</option>
                                    <option value=".best-rate">Sort by latest</option>
                                    <option value=".on-sale">Sort by price: low to high</option>
                                    <option value=".featured">Sort by price: high to low</option>
                                </select>
                            </p>
                        </div>
                    </div>
                    <div class="products-area products-area3">
                        <div class="row justify-content-center">
                          
                            {{-- <div class="col-xl-4 col-md-4 col-sm-6">
                                <div class="product-item product-item2 element-item2">
                                    <a href="/product-details"
                                        class="product-image image-slider-variations image-slider-variations3">
                                        <div class="swiper productSlide">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                                                    <div class="image-vari1 image-vari"><img
                                                            src="{{ asset('frontend/assets/images/hand-picked/woman-shirt-338x450.png') }}" alt="product-image">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="image-vari2 image-vari"><img
                                                            src="{{ asset('frontend/assets/images/hand-picked/woman-shirt-2.jpg') }}" alt="product-image">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="slider-buttons">
                                            <div class="button-prev slider-btn"><i class="fal fa-long-arrow-left"></i></div>
                                            <div class="button-next slider-btn"><i class="fal fa-long-arrow-right"></i></div>
                                        </div>
                                    </a>
                                    <div class="bottom-content">
                                        <a href="/product-details" class="product-name">Woman’s Blouse</a>
                                        <div class="action-wrap">
                                            <span class="product-price">$220.00</span>
                                            <a href="https://weiboo.pixcelsthemes.com/weiboo/cart.html" class="addto-cart"><i class="fal fa-shopping-cart"></i> Add To
                                                Cart</a>
                                        </div>
                                    </div>
                                    <div class="product-features">
                                        <div class="new-tag product-tag">NEW</div>
                                        <div class="discount-tag product-tag">-35%</div>
                                    </div>
                                    <div class="product-actions">
                                        <a href="https://weiboo.pixcelsthemes.com/weiboo/wishlist.html" class="product-action"><i class="fal fa-heart"></i></a>
                                        <button class="product-action product-details-popup-btn"><i
                                                class="fal fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-4 col-sm-6">
                                <div class="product-item product-item2 element-item3 popular">
                                    <a href="/product-details"
                                        class="product-image image-gallery-variations image-gallery-variations3">
                                        <div class="swiper productGallerySlide">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                                                    <div class="image-vari1 image-vari"><img
                                                            src="{{ asset('frontend/assets/images/hand-picked/slider-img1.jpg') }}" alt="product-image">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="image-vari2 image-vari"><img
                                                            src="{{ asset('frontend/assets/images/hand-picked/slider-img1-1.jpg') }}" alt="product-image">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="thumbs-area">
                                        <div class="swiper productGallerySlideThumb">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                                                    <div class="image-vari1 image-vari"><img
                                                        src="{{ asset('frontend/assets/images/hand-picked/slider-img1.jpg') }}" alt="product-image">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="image-vari2 image-vari"><img
                                                        src="{{ asset('frontend/assets/images/hand-picked/slider-img1-1.jpg') }}" alt="product-image">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="bottom-content">
                                        <a href="/product-details" class="product-name">Woman’s Blouse</a>
                                        <div class="action-wrap">
                                            <span class="product-price">$250.00</span>
                                            <a href="https://weiboo.pixcelsthemes.com/weiboo/cart.html" class="addto-cart"><i class="fal fa-shopping-cart"></i> Add To
                                                Cart</a>
                                        </div>
                                    </div>
                                    <div class="product-actions">
                                        <a href="https://weiboo.pixcelsthemes.com/weiboo/wishlist.html" class="product-action"><i class="fal fa-heart"></i></a>
                                        <button class="product-action product-details-popup-btn"><i
                                                class="fal fa-eye"></i></button>
                                    </div>
                                </div>
                            </div> --}}

                            @foreach ($products as $item)
                            <?php 
                                if($item->images != null){
                                    $images = explode('|', $item->images);
                                }
                            ?>		

                                <div class="col-xl-4 col-md-4 col-sm-6">
                                    <div class="product-item product-item2 element-item1">
                                        <a href="/product-details/{{$item->slug}}" class="product-image">
                                            @if($item->images != null)
                                                <img src="{{asset('images')}}/{{$images[0]}}" alt="product-image">
                                            @endif
                                        </a>
                                        <div class="bottom-content">
                                            <a href="/product-details/{{$item->slug}}" class="product-name">{{$item->name}}</a>
                                            <div class="action-wrap">
                                                <span class="product-price">{{$item->price}} Tk</span>
                                                <a href="" class="addto-cart"><i class="fal fa-shopping-cart"></i> Add To
                                                    Cart</a>
                                            </div>
                                        </div>
                                        <div class="product-features">
                                            <div class="new-tag product-tag">NEW</div>
                                            <div class="hot-tag product-tag">HOT</div>
                                        </div>
                                        <div class="product-actions">
                                            <a href="" class="product-action"><i class="fal fa-heart"></i></a>
                                            <button class="product-action product-details-popup-btn"><i
                                                    class="fal fa-eye"></i></button>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        
                        </div>
                    </div>

                    <div class="pagination">
                        {{ $products->appends(request()->query())->links('vendor.pagination.bootstrap-4') }}
                    </div>
                    

                 
                </div>
                <div class="col-xl-3">
                    <div class="side-sticky">
                        <div class="shop-side-action">
                            <div class="action-item">
                                <div class="action-top">
                                    <span class="action-title">PRODUCT CATEGORY</span>
                                </div>

                                @foreach ($categories as $item)
                                    <div class="category-item">
                                        <div class="category-item-inner">
                                            <div class="category-title-area">
                                                <span class="point"></span>
                                                <span class="category-title">{{$item->name}} (10)</span>
                                            </div>
                                            <div class="down-icon"><i class="far fa-angle-down"></i></div>
                                        </div>
                                        <div class="sub-categorys">
                                            <ul class="sub-categorys-inner">
                                                <li><span class="point"></span><a href="shop.html">Clothes</a></li>
                                                <li><span class="point"></span><a href="shop.html">Shoes</a></li>
                                                <li><span class="point"></span><a href="shop.html">Toys</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                @endforeach
                               
                              
                            </div>
                            <div class="action-item">
                                <div class="action-top">
                                    <span class="action-title">FILTER BY PRICE</span>
                                </div>
                                <div class="nstSlider" data-range_min="50" data-range_max="20000" data-cur_min="20"
                                    data-cur_max="10000">
    
                                    <div class="bar"></div>
                                    <div class="leftGrip price-range-grip"></div>
                                    <div class="rightGrip price-range-grip"></div>
                                </div>
                                <div class="range-label-area">
                                    <div class="min-price d-flex">
                                        <span class="range-lbl">Min:</span>
                                        <span class="currency-symbol">$</span>
                                        <div class="leftLabel price-range-label"></div>
                                    </div>
                                    <div class="min-price d-flex">
                                        <span class="range-lbl">Max:</span>
                                        <span class="currency-symbol">$</span>
                                        <div class="rightLabel price-range-label"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="action-item">
                                <div class="action-top">
                                    <span class="action-title">FILTER BY COLOR</span>
                                </div>
                                <div class="color-item">
                                    <div class="color black"><i class="fas fa-check"></i></div>
                                    <span class="color-name">Black</span>
                                    <div class="color-arrow"><i class="far fa-long-arrow-right"></i></div>
                                </div>
                                <div class="color-item">
                                    <div class="color blue"><i class="fas fa-check"></i></div>
                                    <span class="color-name">blue</span>
                                    <div class="color-arrow"><i class="far fa-long-arrow-right"></i></div>
                                </div>
                                <div class="color-item selected">
                                    <div class="color gray"><i class="fas fa-check"></i></div>
                                    <span class="color-name">Gray</span>
                                    <div class="color-arrow"><i class="far fa-long-arrow-right"></i></div>
                                </div>
                                <div class="color-item">
                                    <div class="color green"><i class="fas fa-check"></i></div>
                                    <span class="color-name">Green</span>
                                    <div class="color-arrow"><i class="far fa-long-arrow-right"></i></div>
                                </div>
                                <div class="color-item">
                                    <div class="color red"><i class="fas fa-check"></i></div>
                                    <span class="color-name">Red</span>
                                    <div class="color-arrow"><i class="far fa-long-arrow-right"></i></div>
                                </div>
                                <div class="color-item">
                                    <div class="color yellow"><i class="fas fa-check"></i></div>
                                    <span class="color-name">Yellow</span>
                                    <div class="color-arrow"><i class="far fa-long-arrow-right"></i></div>
                                </div>
                            </div>

                            <div class="action-item d-none">
                                <div class="action-top">
                                    <span class="action-title">FILTER BY BRAND</span>
                                </div>
                                <div class="product-brands">
                                    <div class="brands-inner">
                                        <ul>
                                            <li><a class="product-brand" href="shop.html">Alexander McQueen</a></li>
                                            <li><a class="product-brand" href="shop.html">Adidas</a></li>
                                            <li><a class="product-brand" href="shop.html">Balenciaga</a></li>
                                            <li><a class="product-brand" href="shop.html">Balmain</a></li>
                                            <li><a class="product-brand" href="shop.html">Burberry</a></li>
                                            <li><a class="product-brand" href="shop.html">Chloé</a></li>
                                            <li><a class="product-brand" href="shop.html">Dsquared2</a></li>
                                            <li><a class="product-brand" href="shop.html">Givenchy</a></li>
                                            <li><a class="product-brand" href="shop.html">Kenzo</a></li>
                                            <li><a class="product-brand" href="shop.html">Leo</a></li>
                                            <li><a class="product-brand" href="shop.html">Maison Margiela</a></li>
                                            <li><a class="product-brand" href="shop.html">Moschino</a></li>
                                            <li><a class="product-brand" href="shop.html">Nike</a></li>
                                            <li><a class="product-brand" href="shop.html">Versace</a></li>
                                            <li><a class="product-brand" href="shop.html">Alexander McQueen</a></li>
                                            <li><a class="product-brand" href="shop.html">Adidas</a></li>
                                            <li><a class="product-brand" href="shop.html">Balenciaga</a></li>
                                            <li><a class="product-brand" href="shop.html">Balmain</a></li>
                                            <li><a class="product-brand" href="shop.html">Burberry</a></li>
                                            <li><a class="product-brand" href="shop.html">Chloé</a></li>
                                            <li><a class="product-brand" href="shop.html">Dsquared2</a></li>
                                            <li><a class="product-brand" href="shop.html">Givenchy</a></li>
                                            <li><a class="product-brand" href="shop.html">Kenzo</a></li>
                                            <li><a class="product-brand" href="shop.html">Leo</a></li>
                                            <li><a class="product-brand" href="shop.html">Maison Margiela</a></li>
                                            <li><a class="product-brand" href="shop.html">Moschino</a></li>
                                            <li><a class="product-brand" href="shop.html">Nike</a></li>
                                            <li><a class="product-brand" href="shop.html">Versace</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <a href="shop.html" class="banner-item">
                                    <div class="banner-inner">
                                        <span class="pretitle">Winter Fashion</span>
                                        <h1 class="title">Behind the
                                            deseart</h1>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--================= Shop Section Section End Here =================-->


    <!--================= Product-details Section Start Here =================-->
    <div class="product-details-popup-wrapper">
        <div class="rts-product-details-section rts-product-details-section2 product-details-popup-section">
            <div class="product-details-popup">
                <button class="product-details-close-btn"><i class="fal fa-times"></i></button>
                <div class="details-product-area">
                    <div class="product-thumb-area">
                        <div class="cursor"></div>
                        <div class="thumb-wrapper one filterd-items figure">
                            <div class="product-thumb zoom" onmousemove="zoom(event)"
                                style="background-image: url({{ asset('frontend/assets/images/products/product-details.jpg') }}"><img
                                    src="{{ asset('frontend/assets/images/products/product-details.jpg') }}" alt="product-thumb">
                            </div>
                        </div>
                        <div class="thumb-wrapper two filterd-items hide">
                            <div class="product-thumb zoom" onmousemove="zoom(event)"
                                style="background-image: url({{ asset('frontend/assets/images/products/product-filt2.jpg') }}"><img
                                    src="{{ asset('frontend/assets/images/products/product-filt2.jpg') }}" alt="product-thumb">
                            </div>
                        </div>
                        <div class="thumb-wrapper three filterd-items hide">
                            <div class="product-thumb zoom" onmousemove="zoom(event)"
                                style="background-image: url({{ asset('frontend/assets/images/products/product-filt3.jpg') }}"><img
                                    src="{{ asset('frontend/assets/images/products/product-filt3.jpg') }}" alt="product-thumb">
                            </div>
                        </div>
                        <div class="product-thumb-filter-group">
                            <div class="thumb-filter filter-btn active" data-show=".one"><img
                                    src="{{ asset('frontend/assets/images/products/product-filt1.jpg') }}" alt="product-thumb-filter"></div>
                            <div class="thumb-filter filter-btn" data-show=".two"><img
                                    src="{{ asset('frontend/assets/images/products/product-filt2.jpg') }}" alt="product-thumb-filter"></div>
                            <div class="thumb-filter filter-btn" data-show=".three"><img
                                    src="{{ asset('frontend/assets/images/products/product-filt3.jpg') }}" alt="product-thumb-filter"></div>
                        </div>
                    </div>
                    <div class="contents">
                        <div class="product-status">
                            <span class="product-catagory">Dress</span>
                            <div class="rating-stars-group">
                                <div class="rating-star"><i class="fas fa-star"></i></div>
                                <div class="rating-star"><i class="fas fa-star"></i></div>
                                <div class="rating-star"><i class="fas fa-star-half-alt"></i></div>
                                <span>10 Reviews</span>
                            </div>
                        </div>
                        <h2 class="product-title">Wide Cotton Tunic Dress <span class="stock">In Stock</span></h2>
                        <span class="product-price"><span class="old-price">$9.35</span> $7.25</span>
                        <p>
                            Priyoshop has brought to you the Hijab 3 Pieces Combo Pack PS23. It is a
                            completely modern design and you feel comfortable to put on this hijab.
                            Buy it at the best price.
                        </p>
                        <div class="product-bottom-action">
                            <div class="cart-edit">
                                <div class="quantity-edit action-item">
                                    <button class="button minus"><i class="fal fa-minus minus"></i></button>
                                    <input type="text" class="input" value="01" />
                                    <button class="button plus">+<i class="fal fa-plus plus"></i></button>
                                </div>
                            </div>
                            <a href="https://weiboo.pixcelsthemes.com/weiboo/cart.html" class="addto-cart-btn action-item"><i class="rt-basket-shopping"></i>
                                Add To
                                Cart</a>
                            <a href="https://weiboo.pixcelsthemes.com/weiboo/wishlist.html" class="wishlist-btn action-item"><i class="rt-heart"></i></a>
                        </div>
                        <div class="product-uniques">
                            <span class="sku product-unipue"><span>SKU: </span> BO1D0MX8SJ</span>
                            <span class="catagorys product-unipue"><span>Categories: </span> T-Shirts, Tops, Mens</span>
                            <span class="tags product-unipue"><span>Tags: </span> fashion, t-shirts, Men</span>
                        </div>
                        <div class="share-social"> 
                            <span>Share:</span>
                            <a class="platform" href="http://facebook.com/" target="_blank"><i
                                    class="fab fa-facebook-f"></i></a>
                            <a class="platform" href="http://twitter.com/" target="_blank"><i
                                    class="fab fa-twitter"></i></a>
                            <a class="platform" href="http://behance.com/" target="_blank"><i
                                    class="fab fa-behance"></i></a>
                            <a class="platform" href="http://youtube.com/" target="_blank"><i
                                    class="fab fa-youtube"></i></a>
                            <a class="platform" href="http://linkedin.com/" target="_blank"><i
                                    class="fab fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--================= Product-details Section End Here =================-->

@endsection