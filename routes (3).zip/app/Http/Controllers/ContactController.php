<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail; // You may need to use this for sending emails

class ContactController extends Controller
{
    // Show the contact form
    public function showForm()
{
    return view('contact')->with('page', 'Contact Us');
}


    // Handle the form submission
    public function handleForm(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'message' => 'required|string',
        ]);

        // Here you can send an email or save the data to the database
        // For demonstration, we'll simply send an email (if configured)
        $data = $request->all();

        // Send email (requires configuration in config/mail.php)
        Mail::send([], [], function ($message) use ($data) {
            $message->to('your-email@example.com')
                ->subject('Contact Form Submission')
                ->setBody(
                    "Name: {$data['name']}\nEmail: {$data['email']}\nMessage: {$data['message']}",
                    'text/plain'
                );
        });

        // Return a response or redirect after handling the form
        return back()->with('success', 'Your message has been sent successfully!');
    }
}
