<?php

namespace App\Http\Controllers;

use DB;
use App\Models\Post;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\TeamMember;
use App\Models\Testimonial;
use App\Models\Portfolio;
use Stripe\Stripe;

class HomeController extends Controller
{
  public function getProductCategories()
  {
      $product_categories = ProductCategory::all();
      return $product_categories; 
  }
  public function getProducts($category = null, $perPage = 18, $limit = null)
  {
      $query = Product::query();
  
      // Filter by category if provided
      if ($category) {
          $query->where('category_id', $category);
      }
  
      // Apply limit if provided (for fetching a specific number of products)
      if ($limit) {
          return $query->limit($limit)->get();
      }
  
      // Apply pagination (default to 12 per page)
      return $query->paginate($perPage);
  }
  
  public function index() 
  {
      $settings = DB::table('settings')->where('id', 1)->first();
      if($settings->active!='on'){return view('under_construction');} 
      
      $banner = DB::table('posts')
            ->where('page', 'Home')
            ->where('active', 'on')
            ->where('position', 'banner')
            ->where('parent', null)
            ->get();  
            // dd($banner);   

      $section1 = Post::orderBy('id', 'desc')
      ->where('page', 'Home')
      ->where('position', 'Section 3')
      ->where('parent', null)
      ->where('active', 'on')
      ->first();   
      // dd($section1);  
      

      $blogs = DB::table('blogs')
      ->where('active', 'on')
      ->orderBy('id', 'desc') // Ensure blogs are ordered by ID in descending order
      ->limit(3)
      ->get();
      // dd($blogs);
       // 6 items per page


      $portfolios = DB::table('portfolios')
      ->where('active', 'on')
      ->orderBy('id', 'desc') // Ensure blogs are ordered by ID in descending order
      ->limit(3)
      ->get();
    

      // dd($blogs);
       // 6 items per page

      

      $categories = $this->getProductCategories();
      $products = $this->getProducts();
      $latest_products = $this->getProducts(null, 6, 8);

      $page = 'Home';
    
      return view('home', compact('page', 'blogs', 'banner', 'section1','categories', 'products', 'latest_products', 'portfolios'));
      

    }

    public function about(){
      $posts = DB::table('posts')
            ->where('page', 'About')
            ->where('active', 'on')
            ->get(); 

      $banner = Post::orderBy('id', 'desc')
            ->where('page', 'About')
            ->where('position', 'banner')
            ->where('parent', null)
            ->where('active', 'on')
            ->first();

      $top= Post::orderBy('id', 'desc')
            ->where('page', 'About')
            ->where('position', 'top')
            ->where('parent', null)
            ->where('active', 'on')
            ->first();
      return view('about',  ['page'=>'about', 'posts'=>$posts, 'banner'=>$banner, 'top'=>$top, ]);  
    }

    public function showContactPage()
    {
        $phoneNumber1 = '+8801713090271';
        $phoneNumber2 = '+8801332415060';

        return view('contact', compact('phoneNumber1', 'phoneNumber2'));
    }
    

    



    public function blog1(){
      $blogs = DB::table('blogs')
            // ->where('page', 'Bloge')
            ->where('active', 'on')
            ->get(); 
      

      return view('', ['page'=>'blog', 'blogs'=>$blogs,]); 
    }
  
    // public function shop(){   
    //   $categories = $this->getProductCategories();
    //   $products = $this->getProducts();
    //   $page = 'Shop';
    //   return view('shop', compact('page', 'categories', 'products'));
    // }

    public function shop(Request $request)
    {   
        $categories = $this->getProductCategories();

        // Get filter parameters from request
        $category = $request->input('category'); // Category ID
        $perPage = $request->input('per_page', 8); // Default 18 per page
        $limit = $request->input('limit'); // Specific limit

        $products = $this->getProducts($category, $perPage, $limit);
        
        $page = 'Shop';

        return view('shop', compact('page', 'categories', 'products'));
    }


    public function portfolio(){   
      $page = 'portfolio';
      $data = DB::table('portfolios')
            ->where('active', 'on')
            ->get();

      return view('portfolio', ['page'=>'Portfolio', 'data'=>$data]);
    }

    public function portfolioDetails($id){   
      $item = DB::table('portfolios')
                  ->where('id',$id)
                  ->first();
      $data['hit_count']= $item->hit_count+1;
      
      DB::table('portfolios')
                  ->where('id',$id)
                  ->update($data);

      $page = "Project: " . $item->name;

      $images = explode('|', $item->images);
      $loopImages = array_chunk($images, 5); 

      return view('portfolio_details', ['item' => $item, 'page' => $page, 'images' => $images, 'loopImages' => $loopImages]);
      }  




    public function productDetails(){   
      return view('portfolio_details', ['page'=>'Shop']); 
    }
    


    
    public function faqs(){
      return view('faqs'); 
    }
   
    public function chat() 
    {
      $settings = DB::table('settings')->where('id', 1)->first();
      if($settings->active!='on'){return view('under_construction');}  

      $banner = Post::orderBy('id', 'desc')
            ->where('page', 'Home')
            ->where('position', 'banner')
            ->where('parent', null)
            ->where('active', 'on')
            ->first();

      $section2 = Post::orderBy('id', 'desc')
            ->where('page', 'Home')
            ->where('position', 'Section 2')
            ->where('parent', null)
            ->where('active', 'on')
            ->first();

      $section3 = Post::orderBy('id', 'desc')
            ->where('page', 'Home')
            ->where('position', 'Section 3')
            ->where('parent', null)
            ->where('active', 'on')
            ->first();

      $section4 = Post::orderBy('id', 'desc')
            ->where('page', 'Home')
            ->where('position', 'Section 4')
            ->where('parent', null)
            ->where('active', 'on')
            ->first();

      $section6 = Post::orderBy('id', 'desc')
            ->where('page', 'Home')
            ->where('position', 'Section 6')
            ->where('parent', null)
            ->where('active', 'on')
            ->first();

      $section7 = Post::orderBy('id', 'desc')
            ->where('page', 'Home')
            ->where('position', 'Section 7')
            ->where('parent', null)
            ->where('active', 'on')
            ->first();

      $testimonial  = Testimonial::orderBy('id', 'asc')           
          ->where('ratings', null)
          ->where('active', 'on')
          ->get();

      $reviews  = Testimonial::orderBy('id', 'asc')           
            ->where('ratings', '!=', null)
            ->where('active', 'on')
            ->get();
   
    
      return view('chat', ['page'=>'home', 'banner'=>$banner, 'section2'=>$section2, 'section3'=>$section3, 'section4'=>$section4, 'section6'=>$section6, 'section7'=>$section7, 'testimonial'=>$testimonial, 'reviews'=>$reviews]); 

    }
   public function privacy(){
      $data = DB::table('posts')
            ->where('page', 'Privacy Policy')
            ->where('active', 'on')
            ->first(); 
      return view('privacy', ['page'=>'privacy', 'data'=>$data]); 
    }
   public function security(){
      $data = DB::table('posts')
            ->where('page', 'Security')
            ->where('active', 'on')
            ->first(); 
      return view('security', ['page'=>'security', 'data'=>$data]); 
    }
    public function accessibility(){
      $data = DB::table('posts')
            ->where('page', 'Accessibility')
            ->where('active', 'on')
            ->first(); 
      return view('accessibility', ['page'=>'accessibility', 'data'=>$data]); 
    }

    public function loadCategories(Request $request){
      $categories = ProductCategory::with('children')->has('children')->where('parent_id',null)->skip($request->count)->take(5)->get();
      $remaining = ProductCategory::with('children')->has('children')->where('parent_id',null)->skip($request->count)->take(5)->count();
      $total = ProductCategory::where('parent_id',null)->count();
      $remaining = $total - ($remaining + $request->count+5);
      $data = [
        "total"=>$total,
        "remaining"=>$remaining,
        "items"=>json_encode($categories)
      ];
      return response()->json($data);
    }

    public function show($id)
    {
        $fetch = Product::find($id);  
        $data = new Product;
        $data->hit_count = $fetch->hit_count;        
        $data->save();
      
        return view('product_details', ['data' => $fetch]);       
    }  

      /*============================
       products
       ============================*/
       public function products()
       {     

        $fetch = DB::table('products')
        ->join('product_categories', 'products.category_id', '=', 'product_categories.id')
        ->select('products.*', 'product_categories.name as catName')
        ->get();        
        
        $data=view('admin.products')
        ->with('data',$fetch);

        return view('admin.master')
        ->with('main_content',$data);
      } 

      public function create()
      {        
        return view('admin.product_add');
      }

      public function store(Request $request)
      {        
        $data = new Product;
        $data->title = $request->title;
        $data->slug = Str::slug($request->title);
        $data->price = $request->price;
        $data->msrp = $request->msrp;
        $data->measurement_unit = $request->measurement_unit;
        $data->category_id = $request->category_id;
        $data->description = $request->description;
        $data->short_description = $request->short_description;
        $data->meta_description = $request->meta_description;

        if($request->file('image')!= null){
            $data->image = $request->file('image')->store('images');
        } 
        $data->active = $request->active;
        $data->featured = $request->featured;
        $data->created_by = session('user.id');
        $data->updated_by = '';
        $data->save();

        return redirect()->back()->with(session()->flash('alert-success', 'Data has been inserted successfully.'));    

      }

      public function edit($id)
      {
       
        $data = DB::table('products')
        ->join('product_categories', 'products.category_id', '=', 'product_categories.id')
        ->select('products.*', 'product_categories.name as catName', 'product_categories.id as catID')
        ->where('products.id',$id)
        ->first();
        return view('admin.product_edit', ['data'=>$data]);
      }
   

      public function update(Request $request)
      {       
                
          $data = Product::find($request->id);
          $data->title = $request->title;
          $data->slug = Str::slug($request->title);
          $data->price = $request->price;
          $data->msrp = $request->msrp;
          $data->measurement_unit = $request->measurement_unit;
          $data->category_id = $request->category_id;
          $data->description = $request->description;
          $data->short_description = $request->short_description;
          $data->meta_description = $request->meta_description;
          
          if($request->file('image')!= null){
              $data->image = $request->file('image')->store('images');
          }else{
              $data->image = $request->hidden_image;
          }
          $data->active = $request->active;
          $data->featured = $request->featured;
          $data->updated_by = session('user.id');
          $data->save(); 

          return redirect('/products')->with(session()->flash('alert-success', 'Data has been updated successfully.'));
    }

    public function destroy($id)
    {
      DB::table('products')
      ->where('id',$id)
      ->delete();

      Session::put('message', 'Post deleted successfully!');
      return Redirect::to('/products');
    }

    /*============================
       End News Post
       ============================*/

     

}
