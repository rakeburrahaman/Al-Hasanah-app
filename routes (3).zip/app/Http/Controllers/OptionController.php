<?php

namespace App\Http\Controllers;

use App\Models\Option;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use DB;

class OptionController extends Controller
{
    public function index()
    {
        $data = Option::orderBy('id', 'asc')->get();


        
        return view('admin.options', ['data'=>$data]);        
    }

    public function show($slug)
    {
        $fetch = DB::table('Options')
                ->where('slug',$slug)
                ->first();
        $data['hit_count']= $fetch->hit_count+1;
        
        DB::table('Options')
        		->where('slug',$slug)
        		->update($data);
        //echo $data['hit_count'];exit();

        return view('post_details', ['data' => $fetch]);
        // return \Response::json($post_data);        
    }  

      /*============================
       Posts
       ============================*/
      

      public function create()
      {        
        return view('admin.add_option');
      }

      public function store(Request $request)
      {        
        $data = new Option;
        //$data->title = $request->title;       
        //$data->slug = Str::slug($request->title);
        // dd($request);
        $data->id = $request->id;
        $data->title = $request->title;
        $data->sub_title = $request->sub_title;
        $data->description = $request->description;
        //$data->description = $request->description;
        
        if($request->file('image')!= null){
            $data->image = $request->file('image')->store('images');
            
        } 
        
        $data->active = $request->active;
        $data->save();

        return redirect()->back()->with(session()->flash('alert-success', 'Data has been inserted successfully.'));    

      }
      public function edit($id){       
        $data = Option::find($id);      
        return view('admin.Option_edit', ['data'=>$data]);
      }

    public function update(Request $request)
    {       
          
          $data = Option::find($request->id);
          // dd($request->id);
          $data->id = $request->id;
          $data->title = $request->title;
          $data->sub_title = $request->sub_title;
          $data->description = $request->description;
          if($request->file('image')!= null){
              $data->image = $request->file('image')->store('images');
          }else{
              $data->image = $request->hidden_image;
          }

          // if($request->file('image_m')!= null){
          //     $data->image_m = $request->file('image_m')->store('images');
          // }else{
          //     $data->image_m = $request->hidden_image_m;
          // }

          $data->active = $request->active;
          $data->save(); 

          return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));
    }

    public function destroy($id)
    {
      DB::table('posts')
      ->where('id',$id)
      ->delete();

      return redirect()->back()->with(session()->flash('alert-success', 'Post has been deleted successfully.'));
    }

    /*============================
       End News Post
       ============================*/

     

}
