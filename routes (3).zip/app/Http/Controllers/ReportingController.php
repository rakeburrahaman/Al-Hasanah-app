<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade as PDF;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\UsersExport;
use App\Models\CustomerAccount;

class ReportingController extends Controller
{
    public function index() 
    {
        return view('admin.report_center');        
    }
    public function generateReport(Request $request)
    {
        if($request->start_date != null){
            $start_date = $request->start_date;
        }else{
            $start_date = date("Y-m-d");
        }
        $end_date = $request->end_date;
        $report_title = $request->report_title; 
        $product_id = $request->product_id; 
        $product_category = $request->product_category; 
        $expense_type = $request->expense_type; 
        $cashflow_type = $request->cashflow_type; 
        $store_id = $request->store_id; 
        //dd($start_date);
        //dd($end_date);
        
        // get table name
        if($report_title == 'Sales'){
            $table_name = 'payments';
            $total = 'amount'; 
        } 
        else if($report_title == 'Leads'){
            $table_name = 'customers';
            $total = 'amount'; 
        } 
        else if($report_title == 'Sales Category'){
            $table_name = 'payments';
            $total = 'amount'; 
        } 
        else if($report_title == 'Expense'){
            if($expense_type != null){
            }
            $table_name = 'expenses';
            $total = 'amount';
        } 
        else if($report_title == 'Cash Receive'){
            $table_name = 'cash_flows';
            $total = 'amount_in';
        }
        else if($report_title == 'Purchase'){
            $table_name = 'purchases';
            $total = 'total_price';
        }
        else if($report_title == 'DO Summary'){
            $table_name = 'order_details';
            $total = 'qty';
        }
        else if($report_title == 'Duty Summary'){
            $table_name = 'duties';
            $total = 'total_hours';
        }
        
        else if($report_title == 'Sales Profit'){           
            $table_name = 'order_details';
            $total = 'profit';  
        }
        else if($report_title == 'Stock'){           
            $table_name = 'product_stocks';
            $total = 'store_qty';  
        }
        else if($report_title == 'Stock Delivery'){
            $table_name = 'product_stocks';
            $total = 'qty';
            if($store_id != null){
                $store = DB::table('stores')
                ->where('id', $store_id)
                ->first();
                $store_title = $store->title;
            }else{
                $store_title = 'All Stock';
            }           
        }

        else if($report_title == 'Cash Sheet'){
            return $this->cashSheet($request);
        }
        else if($report_title == 'Customer Balance'){
            return redirect('customer-ledger-summary');
        }
        else if($report_title == 'Market Due'){
            return redirect('market-due');
        } 
        
        
       
      

        // daily or On Date
        if($end_date == null){
            $report_type = 'On Date';
            $date_range = bd($start_date); 

            if($start_date == null || $end_date == null){
                //return redirect()->back()->with(session()->flash('alert-warning', 'Start date and end date can not be entry.'));    
            } 

            if($report_title == 'Sales'){
                // Product based Daily sales
                if($product_id != null){                
                    $product = DB::table('products') 
                        ->where('id', $product_id)
                        ->first(); 
                    $product_name = $product->name;
                    //$report_title = $report_title."(".$product->name.")"; 
                    $data = DB::table($table_name)
                    ->where('product_id', $product_id)
                    ->where('created_at', 'like', '%' .$start_date. '%')
                    ->where('client_id', session('client_id'))->where('active', 'on')
                    ->orderBy('id', 'desc')
                    ->get();
                    $total_amount = DB::table($table_name)->where('created_at', 'like', '%' .$start_date. '%')->where('client_id', session('client_id'))->where('active', 'on')->sum($total);
                    return view('reports.sales_item', ['data' => $data, 'total_amount' => $total_amount, 'report_title' => $report_title." -".$product_id."-", 'report_type' => $report_type, 'date_range' => $date_range ]);   
                }
                else{
                    // all products daily sales
                    $data = DB::table('orders')
                    ->where('created_at', 'like', '%' .$start_date. '%')
                    ->where('client_id', session('client_id'))
                    ->where('active', 'on')
                    ->orderBy('id', 'asc')
                    ->get();
                    //dd($data);  
  
                    //in view page advance and due has been skiped
                    $total_amount = DB::table('order_details')
                    // ->where('product_type','!=', 'Advance')
                    // ->where('product_type','!=', 'Due')
                    ->where('client_id', session('client_id'))
                    ->where('created_at', 'like', '%' .$start_date. '%')
                    ->where('active', 'on')
                    ->sum('total_price');
                    
 
                    // $total_amount = DB::table($table_name)
                    // ->where('client_id', session('client_id'))
                    // ->where('created_at', 'like', '%' .$start_date. '%')->where('active', 'on')
                    // ->sum($total);
                    // dd($total_amount1, $total_amount); 

                    return view('reports.sales', ['data' => $data, 'total_amount' => $total_amount, 'report_title' => $report_title." -".$product_id."-", 'report_type' => $report_type, 'date_range' => $date_range ]); 
                }               
            }
            else if($report_title == 'Leads'){
                $data = DB::table($table_name)
                ->where('created_at', 'like', '%' .$start_date. '%')
                ->where('type', 'Lead')
                ->where('client_id', session('client_id'))
                ->where('active', 'on')
                ->orderBy('id', 'asc')
                ->get();                               
            }   
           
           

            else{
                $data = DB::table($table_name)
                ->where('created_at', 'like', '%' .$start_date. '%')
                ->where('client_id', session('client_id'))
                ->orderBy('id', 'desc')
                ->get();
                $total_amount = DB::table($table_name)->where('created_at', 'like', '%' .$start_date. '%')->where('client_id', session('client_id'))->sum($total);
            }

             
        }
        // date range start
        else{ 
            $report_type = 'Date Range';
            $bd_start_date = bd($start_date);
            $bd_end_date = bd($end_date);
            $date_range = "From {$bd_start_date} To {$bd_end_date}";
            $start_date_time = "{$start_date} 00:00:01";
            $end_date_time = "{$end_date} 23:59:59";

        if($report_title == 'Leads'){
                $data = DB::table($table_name)
                ->where('created_at', '>=', $start_date_time)
                ->where('created_at', '<=', $end_date_time)
                ->where('type', 'Lead')
                ->where('client_id', session('client_id'))
                ->where('active', 'on')
                ->orderBy('id', 'asc')
                ->get();                               
            }  
            else if($report_title == 'Duty Summary'){  
                
                //dd($start_date, $start_date);           
                $data = DB::table('duties')
                ->selectRaw('equipement_id, sum(total_hours) as hours, sum(bill) as bill')
                ->where('date', '>=', $start_date)
                ->where('date', '<=', $end_date)
                ->where('client_id', session('client_id'))
                ->groupBy('equipement_id')
                ->orderBy('hours', 'desc')
                ->get(); 
                //dd($data);
                return view('reports.duty_summary', ['data' => $data, 'report_title' => $report_title."-", 'report_type' => $report_type, 'date_range' => $date_range, 'start_date' => $start_date, 'end_date' => $end_date ]);     
            }   
            else if($report_title == 'Sales Profit'){
                $data = DB::table($table_name)
                ->selectRaw('product_id, sum(profit_unit) as profit_unit, sum(qty) as qty_sum, sum(profit) as profit_sum')
                ->where('created_at', '>=', $start_date_time)
                ->where('created_at', '<=', $end_date_time)
                ->where('client_id', session('client_id'))
                ->where('active', 'on')
                ->groupBy('product_id')
                ->orderBy('id', 'desc')
                ->get();
                $total_amount = DB::table($table_name)->where('created_at', '>=', $start_date_time)->where('created_at', '<=', $end_date_time)->where('client_id', session('client_id'))->where('active', 'on')->sum($total);
            }  
 
           
            else if($report_title == 'Expense' && $expense_type != null){
                $data = DB::table($table_name)
                ->where('expense_type', $expense_type)
                ->where('created_at', '>=', $start_date_time)
                ->where('created_at', '<=', $end_date_time)
                ->where('client_id', session('client_id'))->where('active', 'on')
                ->orderBy('id', 'asc')
                ->get();
                //dd($data);
                $total_amount = DB::table($table_name)->where('expense_type', $expense_type)->where('created_at', '>=', $start_date_time)->where('created_at', '<=', $end_date_time)->where('client_id', session('client_id'))->where('active', 'on')->sum($total);
            }    
            else if($report_title == 'Expense' && $expense_type == null){
                $data = DB::table($table_name)
                ->orWhere('expense_type', '!=', 'Boss Personal')
                ->where('expense_type', '!=', 'Bank Deposit')
                ->where('created_at', '>=', $start_date_time)
                ->where('created_at', '<=', $end_date_time)
                ->where('client_id', session('client_id'))->where('active', 'on')
                ->orderBy('id', 'asc')
                ->get();
                //dd($data); 
                $total_amount = DB::table($table_name)->orWhere('expense_type', '!=', 'Boss Personal')->where('expense_type', '!=', 'Bank Deposit')->where('created_at', '>=', $start_date_time)->where('created_at', '<=', $end_date_time)->where('client_id', session('client_id'))->where('active', 'on')->sum($total);
            } 

            else if($cashflow_type != null){
                $data = DB::table($table_name)
                ->where('cashflow_type', $cashflow_type)
                ->where('created_at', '>=', $start_date_time)
                ->where('created_at', '<=', $end_date_time)
                ->where('client_id', session('client_id'))->where('active', 'on')
                ->orderBy('id', 'desc')
                ->get();
                //dd($data);
                $total_amount = DB::table($table_name)->where('cashflow_type', $cashflow_type)->where('created_at', '>=', $start_date_time)->where('created_at', '<=', $end_date_time)->where('client_id', session('client_id'))->where('active', 'on')->sum($total);
            }
            else if($report_title == 'Stock Delivery' && $store_id != null){
                $data = DB::table($table_name)
                ->where('created_at', '>=', $start_date_time)
                ->where('created_at', '<=', $end_date_time)
                ->where('store_id', $store_id)
                ->where('type', 'Credit')
                ->get();
             
                $total_qty = DB::table($table_name)->where('store_id', $store_id)->where('created_at', '>=', $start_date_time)->where('created_at', '<=', $end_date_time)->where('type', 'Credit')->sum($total);
            }
            else if($report_title == 'Stock Delivery' && $store_id == null){
                $data = DB::table($table_name)
                ->where('created_at', '>=', $start_date_time)
                ->where('created_at', '<=', $end_date_time)
                ->where('type', 'Credit')
                ->get();
             
                $total_qty = DB::table($table_name)->where('created_at', '>=', $start_date_time)->where('created_at', '<=', $end_date_time)->where('type', 'Credit')->sum($total);
            }
            else{
                $data = DB::table($table_name)
                ->where('created_at', '>=', $start_date_time)
                ->where('created_at', '<=', $end_date_time)
                ->where('client_id', session('client_id'))
                ->orderBy('id', 'desc')  
                ->get();

                $total_amount = DB::table($table_name)->where('created_at', '>=', $start_date_time)->where('created_at', '<=', $end_date_time)->where('client_id', session('client_id'))->sum($total);
            } 

            
            //dd($total_amount);            
        }


        //dd($table_name); 
        if($report_title == 'Sales'){   
            if(isset($product_name)){
                $product_id = $product_name;
            }        
            return view('reports.sales', ['data' => $data, 'total_amount' => $total_amount, 'report_title' => $report_title." -".$product_id."-", 'report_type' => $report_type, 'date_range' => $date_range ]);          
        }        
        elseif($report_title == 'Leads'){ 
            return view('reports.leads', ['data' => $data, 'report_title' => $report_title."-", 'report_type' => $report_type, 'date_range' => $date_range ]);          
        }
       
        
      
        //return view('admin.report_center');        
    }
   
    public function companyLedger($company_id)
    {
        $company = DB::table('companies')
        ->where('id', $company_id)
        ->first();
        $company_name = $company->title;
        
        // $start_date= $request->start_date;
        // $end_date = $request->end_date;
        $report_title = "Company Ledger #".$company_name; 
        $report_type = "Not Defined";
        $date_range = date("Y-m-d");
               
        // purchase or sold
        $purchases = DB::table('purchases')
        ->where('company_id', $company_id)
        ->orderBy('id', 'asc')
        ->get();
        //dd($purchases);
        $total_purchase = DB::table('purchases')->where('company_id', $company_id)->sum('total_price');
        //dd($company_id);


        // bill pay
        $bill_paid = DB::table('expenses')
        ->where('company_id', $company_id)
        ->where('client_id', session('client_id'))
        ->where('active', 'on')        
        ->where('expense_type', 'Product Purchase')
        // ->orWhere('expense_type', 'Advance Payment')
        // ->orWhere('expense_type', 'Company Due Pay')
        ->orderBy('id', 'asc') 
        ->get();
        //dd( $bill_paid);
        $total_bill_paid = DB::table('expenses')->where('company_id', $company_id)->where('client_id', session('client_id'))->where('active', 'on')->where('expense_type', 'Product Purchase')
        // ->orWhere('expense_type', 'Advance Payment')->orWhere('expense_type', 'Company Due Pay')
        ->sum('amount');

        return view('reports.company_ledger', ['company_name' => $company_name,'company_id' => $company_id, 'purchases' => $purchases, 'total_purchase' => $total_purchase, 'bill_paid' => $bill_paid, 'total_bill_paid' => $total_bill_paid, 'report_title' => $report_title, 'report_type' => $report_type, 'date_range' => $date_range ]);        
    } 
   
    public function exportUser()  {
        return Excel::download(new UsersExport, 'sales_report.xlsx');
    }
    
    public function exportPDF(Request $request){
        //dd($request);
        $starting_month = $request->starting_month;
        $ending_month = $request->ending_month;        
        if($ending_month == null){
            $starting_month = substr($starting_month,0,7);
            //dd($starting_month);
            $data = DB::table('order_details')
            ->join('products', 'order_details.product_id', '=', 'products.id')       
            ->select('products.*', 'order_details.created_at as order_date')
            ->where('order_details.created_at', 'like', '%' . $request->starting_month . '%')
            ->get();
        } 
        else{           
            $data = DB::table('order_details')
            ->join('products', 'order_details.product_id', '=', 'products.id')       
            ->select('products.*', 'order_details.created_at as order_date')
            ->whereBetween('order_details.created_at', [$starting_month, $ending_month])
            ->get();
        }
        $total = $data->count();   
        //dd($data);
        $pdf = PDF::loadView('pdf/sales_report', ['data' => $data, 'total' => $total, 'starting_month' => $starting_month, 'ending_month' => $ending_month,]);
        $name = 'sales';
        return $pdf->download($name.'_report.pdf');


    }


    public function sales(Request $request){
        dd($request);
        $starting_month = $request->starting_month;
        $starting_month = $starting_month.'-01';
        $ending_month = $request->ending_month;        
        if($ending_month == null){
            $data = DB::table('order_details')
            ->join('products', 'order_details.product_id', '=', 'products.id')       
            ->select('products.*', 'order_details.created_at as order_date')
            ->where('order_details.created_at', 'like', '%' . $request->starting_month . '%')
            ->get();
        } 
        else{ 

            $ending_month = $ending_month.'-31';
            $from = date($starting_month);
            $to = date($ending_month);
            $data = DB::table('order_details')
            ->join('products', 'order_details.product_id', '=', 'products.id')       
            ->select('products.*', 'order_details.created_at as order_date')
            ->whereBetween('order_details.created_at', [$from, $to])
            ->get();
        }
        $total = $data->count();
       
        //dd($data);
        return view('admin.report_sales', ['data' => $data, 'total' => $total, 'starting_month' => $starting_month, 'ending_month' => $ending_month,]);

    }



    public function exportExcel(Request $request)
    {
      $starting_month = $request->starting_month;
      $ending_month = $request->ending_month; 

      if($ending_month == null){
        $data = DB::table('order_details')
        ->join('products', 'order_details.product_id', '=', 'products.id')       
        ->select('products.*', 'order_details.created_at as order_date')
        ->where('order_details.created_at', 'like', '%' . $request->starting_month . '%')
        ->get()->toArray();
    } 
    else{
        $ending_month = $ending_month.'-31';
        $data = DB::table('order_details')
        ->join('products', 'order_details.product_id', '=', 'products.id')       
        ->select('products.*', 'order_details.created_at as order_date')
        ->whereBetween('order_details.created_at', [$starting_month, $ending_month])
        ->get()->toArray();
    }
   

     $file_name = 'sales_report_'.$starting_month.'_to_'.$ending_month;
   
     $product_array[] = array('name', 'id', 'price', 'created_at');

     foreach($data as $item)
     {
      $product_array[] = array(
       'product name'  => $item->name,
       'product id'   => $item->id,
       'price'   => $item->price,
       'order date'   => $item->created_at       
      );
     }
     
     //Excel::download/Excel::store($product_array);
    //  Excel::create('Customer Data', function($excel) use ($product_array){
    //     $excel->setTitle('Customer Data');
    //     $excel->sheet('Customer Data', function($sheet) use ($product_array){
    //      $sheet->fromArray($product_array, null, 'A1', false, false);
    //     });
    //    })->download('xlsx');

       //Excel::download/Excel::store($product_array);
       Excel::raw($product_array, Excel::XLSX);

    }


}

