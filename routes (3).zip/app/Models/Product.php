<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ProductCategory;
use DB;

class Product extends Model
{
    use HasFactory;
    
    public function category(){
        return $this->belongsTo(ProductCategory::class, 'category_id');
    }
    // public function subCategory(){
    //     return $this->belongsTo(ProductCategory::class, 'sub_category_id');
    // }

  

}
