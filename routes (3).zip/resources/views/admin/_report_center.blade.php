<div class="row mt-5">
    <div class="col-12">
      <h5 class="text-center" style="background: #edf2f9; padding: 5px;">All Reports</h5>
      <div class="card dcard">
        <div class="card-body px-1 px-md-3">                                   
          <div role="main" class="main-content">         
            <div class="page-content container container-plus">   

             
              <form action="report" method="post">
                @csrf
                <div class="form-row">
                    <div class="col-md-3">
                        <div class="col">
                            <label>Start Date</label>
                            <input type="date" name="start_date" class="form-control">
                          </div>
                    </div>
                    <div class="col-md-3" id="endDate">
                        <div class="col">
                            <label>End Date</label>
                            <input type="date" name="end_date" class="form-control">
                          </div>
                    </div>
                    <div class="col-md-3">
                        <div class="col">
                            <label>Report Type</label>
                            <select name="report_title" required id="reportTitle" class="custom-select select2-single">
                                <option value="">Select report title</option>
                                <option value="Leads">Leads</option>                                
                                <option value="Sales">Sales</option>                                
                                <option value="Expense">Expense</option>
                                <option value="Cash Sheet">Cash Sheet</option>                                 
                                <option value="Market Due">Market Due</option> 
                                <option value="Customer Balance">Customer Balance</option>
                              </select>
                          </div>
                    </div>
                  
                    
                    
                    <div class="col-md-3" style="display: none" id="expenseType">
                        <div class="col">
                            <label>Expense Type</label> <br>
                            <select name="expense_type" class="custom-select select2-single form-control" style="width: 100%">
                              @include('admin._expense_type')
                            </select>
                          </div>
                    </div> 
                    

                    <div class="col-md-3" style="float: right">
                        <div class="col">
                            <label>&nbsp;</label>
                            <button type="submit" class="form-control">Submit</button>
                          </div>
                    </div>
                </div>
              </form>
                <br>
          
           </div>
          </div>
        </div>
      </div>           
    </div>
  </div>

  <script>
    $(document).ready(function() {  
      $(document).on('change', '#reportTitle', function () {       
        var title = $(this).val();
        console.log(title);
       
        if(title == 'Sales'){
          console.log(title);
          $("#productType").show();
          $("#expenseType").hide();
          $("#endDate").show();
          $("#stockDelivery").hide();
          $("#productCategory").hide();
        } 
        else if(title == 'Sales Category'){
          console.log(title);
          $("#productCategory").show();
          $("#expenseType").hide();
          $("#endDate").show();
          $("#stockDelivery").hide();
        } 
        else if(title == 'Expense'){
          $("#expenseType").show();
          $("#endDate").show();
          $("#productType").hide();
          $("#cashFlowType").hide();
          $("#productCategory").hide();
          $("#stockDelivery").hide();
        } 
        else if(title == 'Cash Receive'){
          $("#cashFlowType").show();
          $("#endDate").show();
          $("#expenseType").hide();
          $("#productType").hide();
          $("#productCategory").hide();
          $("#stockDelivery").hide();
        }
        else if(title == 'Cash Sheet'){
          $("#endDate").hide();
          $("#productType").hide();
          $("#expenseType").hide();
          $("#cashFlowType").hide();
          $("#productCategory").hide();
          $("#stockDelivery").hide();
        }
        else if(title == 'Stock Delivery'){
          $("#stockDelivery").show();
          $("#endDate").show();
          $("#productType").hide();
          $("#expenseType").hide();
          $("#productCategory").hide();
          $("#cashFlowType").hide();
        }
        else{
          $("#productType").hide();
          $("#expenseType").hide();
          $("#cashFlowType").hide();
          $("#productCategory").hide();
          $("#stockDelivery").hide();
        }       
      });
    });
  </script>

  {{-- <script>
    $(document).ready(function() {  
      $(document).on('change', '#reportTitle', function () {       
        var title = $(this).val();
        console.log(title);
       
        if(title == 'Sales'){
          console.log(title);
          $("#productType").show();
          $("#expenseType").hide();
        } 
        else if(title == 'Expense'){
          $("#productType").hide();
          $("#expenseType").show();
        }
        else{
          $("#productType").hide();
          $("#expenseType").hide();
        }       
      });
    });
  </script> --}}



    
