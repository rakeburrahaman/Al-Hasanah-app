
@extends('admin.master')
@section('main_content')    

  <div class="page-content container container-plus">
  
<style>
  .bad_lead{
    background: #df4b30; 
    color: #fff;
  } 
  .bad_lead:hover{
    color: #000;
  }
</style>

    <div class="row mt-3">
      <div class="col-12">
        <div class="card dcard">
          <div class="card-body px-1 px-md-3">                                   
            <div role="main" class="main-content">         
              <div class="page-content container container-plus">
                <div class="page-header mb-2 pb-2 flex-column flex-sm-row align-items-start align-items-sm-center py-25 px-1">              

                <h1 class="page-title text-primary-d2 text-140">
                  All Announcement
                @if(session('user.client') == null)
                | <a href="add-announcement" class="add_new">Add New
                </a>    
                @endif

                              
                </h1>           

                <div class="page-tools mt-3 mt-sm-0 mb-sm-n1">
                  <!-- dataTables search box will be inserted here dynamically -->
                </div>
              </div>

              <div class="card bcard h-auto">
               
                  <table id="datatable" class="d-style w-100 table text-dark-m1 text-95 border-y-1 brc-black-tp11 collapsed">
                    <thead class="sticky-nav text-secondary-m1 text-uppercase text-85">
                      <tr>
                          <th class="border-0 bgc-white bgc-h-yellow-l3 shadow-sm"></th>
                          <th class="border-0 bgc-white bgc-h-yellow-l3 shadow-sm">SN</th>
                          {{-- @if(session('user.user_type') != 'User')
                          <th> Client </th>
                          @endif --}}
                          <th>Title</th>
                          <th class=""> Sub Title</th>
                          <th class="m_hdn">Link Title </th>
                          <th class="m_hdn"> Link Action </th>
                          <th class=""> Action </th>  
                      </tr>
                    </thead>

                    <tbody class="pos-rel">
                      
                    @foreach($data as $item)   
                      <tr class="d-style bgc-h-default-l4 @if($item->lead_type == 'Unemployed' || $item->lead_type == 'Bad number/Disc number' || $item->lead_type == 'Low liability/no unfiled') bad_lead @endif" id="row_{{$item->id}}" >
                        <td class="pl-3 pl-md-4 align-middle pos-rel"></td>
                        <td class="pl-3 pl-md-4 align-middle pos-rel"> {{$loop->iteration}} </td>

                        {{-- @if(session('user.user_type') != 'User') 
                          <td class="left">{{$item->client}}</td> 
                        @endif	 --}}
                        <td class="left">{{$item->title}}</td>
                        <td class="left m_hdn">{{$item->sub_title}}</td>

                        <td class="left m_hdn">{{$item->link_title}}</td>

                        <td class="left m_hdn">{{$item->link_action}}</td>	


                        @if(session('user.user_type') == 'Manager')
                        <td> 
                          {{-- <a href="#" id="thumbs_down_{{$loop->iteration}}" class="thumbs_down" title="Double Click to Dislike"><i class="fa fa-thumbs-down text-blue-m1 text-120"  style="margin-top: 5px"></i></a>  
                          &nbsp; &nbsp;  --}}

                          <span class="d-none d-lg-inline">
                            <a  title="Edit" href="edit-announcement/{{$item->id}}" class="v-hover">
                                <i class="fa fa-edit text-blue-m1 text-120"></i>
                            </a>
                          </span>
                        </td>
                        @else 
                        <td class="align-middle">
                          <span class="d-none d-lg-inline">
                              <a  title="Edit" href="edit-announcement/{{$item->id}}" class="v-hover">
                                  <i class="fa fa-edit text-blue-m1 text-120"></i>
                              </a>
                          </span>
  
                          <span class="d-lg-none text-nowrap">
                              <a title="Edit" href="edit-announcement/{{$item->id}}" class="btn btn-outline-info shadow-sm px-4 btn-bgc-white">
                                  <i class="fa fa-pencil-alt mx-1"></i>
                                  <span class="ml-1 d-md-none">Edit</span>
                              </a>
                          </span>
                          <span class="d-lg-inline">
                            <a data-rel="tooltip" title="Delete" href="javascript:void(0)" data-target="#confirm_delete_modal" data-toggle="modal" data-id="{{$item->id}}" class="delete-btn v-hover">
                                <i class="fa fa-trash text-blue-m1 text-120"></i>
                            </a>
                            <div id="confirm_delete_modal" class="modal fade" aria-modal="true">
                              <div class="modal-dialog modal-dialog-centered modal-confirm">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <div class="icon-box">
                                      <i class="fa fa-times fa-4x"></i>
                                    </div>				
                                    <h4 class="modal-title w-100">Warning!</h4>	
                                  </div>
                                  <div class="modal-body">
                                    <p class="text-center">Are you sure? This action can't be undone.</p>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <a href="" class="btn btn-danger delete-lead">Delete</a>
                                  </div>
                                </div>
                              </div>
                            </div>                              
                          </span>
                          <span class="d-lg-none text-nowrap">
                            <a title="Edit" href="#" class="btn btn-outline-info shadow-sm px-4 btn-bgc-white">
                                <i class="fa fa-trash-alt mx-1"></i>
                                <span class="ml-1 d-md-none">Delete</span>
                            </a>
                          </span>
                        </td>
                        @endif
					
                      
                    </tr>
                    @endforeach
                  </tbody>
                </table>

              </div>
            </div>
           </div>
          </div>

  </div>
  <script>  
    $(document).ready(function () {
      //change on qty
      $(document).on('click', '.thumbs_down', function (event) {
        event.preventDefault(); 
        var row_id = $(this).parent().parent().attr('id').split('_').pop();
        // alert(row_id);
        $($(this).parent().parent()).addClass('bad_lead');
        $($(this).parent().parent()).css('background-color', 'red!important');

        $.ajax({
          url: "dislike_lead",
          data: {
            _token: '{{csrf_token()}}',
            lead_id: row_id
          },
          type: 'POST',
          success: function (response) {
            console.log(response.data);
          }
        });


      });


    });
</script>

@endsection