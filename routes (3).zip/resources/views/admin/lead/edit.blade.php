
@extends('admin.master')
@section('main_content')    

  <div class="page-content container container-plus">
    <div class="page-header pb-2">
      <h1 class="page-title text-primary-d2 text-150">
        Update Lead     
      </h1> 
      <a href="leads"class="btn btn-default px-3 text-95 radius-round border-2 brc-black-tp10 float-left">
        <i class="fa fa-plus mr-1"></i>
        <span class="d-sm-none d-md-inline">All</span> Leads
      </a>
    </div>   


    <div class="row-md-3">
      <div class="col-12">
        <div class="card dcard">
          <div class="card-body px-1 px-md-3">                                   
            <div role="main" class="main-content">         
              <div class="page-content container container-plus">               

                <form action="update-lead" method="post" enctype="multipart/form-data">
                  @csrf
                    <div class="row">                      
                      
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">Notes</label>
                          <textarea name="clients_note" rows="1" class="form-control" placeholder="notes">{{$data->clients_note}}</textarea>
                        </div>  
                      </div> 
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="">TI Notes</label>
                          <textarea name="ti_notes" rows="1" id="" class="form-control">{{$data->clients_note}}</textarea>
                        </div>  
                      </div>

                      <div class="col-md-4">
                        
                          <div class="form-group">
                            <label for="">Lead Type</label>
  
                            <select class="form-control ss" name="lead_type" >
                              <option value="{{$data->lead_type}}">{{$data->lead_type}}</option>
                                  <option value="No Answer">No Answer</option>
                                  <option value="Unemployed">Unemployed</option>
                                  <option value="Bad number/Disc number">Bad number/Disc number</option>
                                  <option value="Low liability/no unfiled">Low liability/no unfiled</option>
                            </select>
                          </div>  
                        </div>
                    </div>
                   
                  <input type="hidden" name="id" value="{{$data->id}}">
                  <button type="submit" class="btn btn-primary">Update</button>
                  <a href="add-lead" class="btn btn-default">Cancel</a>
                </form>
              </div>
            </div>    
          </div>
        </div>           
      </div>
    </div>
  </div>
@endsection