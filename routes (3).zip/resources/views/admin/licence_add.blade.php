
@extends('admin.master')
@section('main_content')    

  <div class="page-content container container-plus">
    <div class="page-header pb-2">
      <h1 class="page-title text-primary-d2 text-150">
        Add New Lincence     
      </h1> 
      <a href="tasks"class="btn btn-default px-3 text-95 radius-round border-2 brc-black-tp10 float-left">
        <i class="fa fa-plus mr-1"></i>
        <span class="d-sm-none d-md-inline">All</span> Lincences
      </a>
    </div>   

    <div class="row mt-3">
      <div class="col-12">
        <div class="card dcard">
          <div class="card-body px-1 px-md-3">                                   
            <div role="main" class="main-content">         
              <div class="page-content container container-plus">               

                <form action="save_task" method="post" enctype="multipart/form-data">
                  @csrf
                  <div class="row">
                   
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Company</label>
                        <select class="form-control ss" name="company_id" id="company">  
                          <option value="">-- Select Company --</option>                   
                            <?php                            
                             $companies=DB::table('clients')
                             ->where('active', 'on')
                             ->orderBy('name','asc')
                             ->get();
                             ?>
                            @foreach($companies as $item) 
                            <option value="{{$item->id}}">{{$item->name}}</option>
                            @endforeach  
                        </select>
                      </div>
                    </div>

                   

                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Applied Date</label>
                        <input type="datetime-local" class="form-control" id="" name="due_date">
                      </div>
                    </div>
    
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Priority</label>
                        <select class="form-control" name="customer_id" id="company">  
                          <option value="">-- Select priority --</option>                   
                           
                          <option value="{{$item->id}}">Normal</option>
                          <option value="{{$item->id}}">High</option>
                           
                        </select>
                        
                      </div>
                    </div>
    
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Status</label>
                        <select class="form-control ss" name="status" required="">
                            <option value="">Select status</option>
                            <option value="Assigned">Applied</option>
                            <option value="Pending">Pending</option>
                            <option value="Processing">Granted</option>  

                  
                        </select>
                      </div>
                    </div>
                    
                          
               
                <div class="col-md-12">
                
                  <div class="form-group">
                    <label for="">Description</label>
                    <textarea id="summernote" name="description" class="form-control" rows="2"></textarea>  
                  </div>
                </div>

               

                

                </div>


                  <div class="form-group">                    
                    <label class="form-check-label" for="exampleCheck1">
                     Active
                    </label>
                    <input type="checkbox" name="active" checked class="form-check-input" id="exampleCheck1">
                  </div>
                  <br>
                  <button type="submit" class="btn btn-primary">Submit</button>
                  <button type="button" class="btn btn-default">Cancel</button>
                </form>
                
             </div>
            </div>
          </div>
        </div>           
      </div>
    </div>

  </div>

  <script>

    $("#category_id").change(function(){
      var category_id = $(this).val();
      $.ajax({
        url: "find_subcategory",
        data: {
          _token: '{{csrf_token()}}',
          category_id: category_id
        },
        type: 'POST',
        success: function (response) {
            //console.log(response.data);
              if(response.total>0){
                  $('#sub_category_id').empty();
                  $('#sub_category_id').focus;
                  $('#sub_category_id').append('<option value="">-- Select Sub Category --</option>'); 
                  $.each(response.data, function(key, value){
                      $('select[name="sub_category_id"]').append('<option value="'+ value.id +'">' + value.name+ '</option>');
                  });
              }else{
                  $('#sub_category_id').empty();
              }
        }
      });
    });


</script>
 
@endsection