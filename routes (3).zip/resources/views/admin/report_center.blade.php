re
@extends('admin.master')
@section('main_content')    

  <div class="page-content container container-plus">
    <div class="page-header pb-2">
      <h1 class="page-title text-primary-d2 text-150 d-none">
        All Reports   
      </h1> 
    
    </div>   

<style>
  h5.text-center {
    text-align: left!important;
    font-weight: 600;
}

.row.mt-5 {
    margin-top: 0px!important;
}
</style>
    @include('admin._report_center')

</div>
  

@endsection