<?php $posts = DB::table('posts')->where('page', 'Blog')->where('active', 'on')->get(); ?>
@extends('layouts.master')
@section('main_content')
<section class="page-header">
	<div class="page-header__bg" style="background-image: url('{{ asset('frontend/assets/images/about.png') }}');"></div>
<!-- /.page-header__bg -->
	<div class="container">
		<div class="page-header__content">
			<h2 class="page-header__title">faqs </h2>
			<ul class="cherito-breadcrumb list-unstyled">
				<li><a href="/">Home</a></li>
				<li><span>faqs</span></li>
			</ul><!-- /.cherito-breadcrumb list-unstyled -->
		</div><!-- /.page-header__content -->
	</div><!-- /.container -->
</section><!-- /.page-header -->
<section class="faq-one section-space-top">
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				<img src="{{ asset('frontend/assets/images/shapes/sec-title-s-1-1.png') }}" alt="shape" class="sec-title__shape">
				<h6 class="sec-title__tagline">FAQS</h6><!-- /.sec-title__tagline -->
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">Have Questions in Your <br> Mind? Get the Answers Now</h3><!-- /.sec-title__title -->
		</div><!-- /.sec-title -->
		<div class="row gutter-y-50 align-items-center">
			<div class="col-lg-6 wow fadeInLeft" data-wow-duration="1800ms">
				<div class="faq-one__image">
					<img src="{{ asset('frontend/assets/images/resources/faq-1-2.jpg') }}" alt="faq">

					<div class="faq-one__info">
						<div class="faq-one__info__inner">
							<div class="faq-one__info__logo">
								<img src="{{ asset('frontend/assets/images/shapes/faq-logo-1-2.png') }}" alt="faq logo">
							</div><!-- /.faq-one__info__logo -->
							<h3 class="faq-one__info__title">Still have Questions?</h3><!-- /.faq-one__info__title -->
							<p class="faq-one__info__text">
								Sent to <a href="mailto:needhelp@company.com">needhelp@company.com</a>
							</p><!-- /.faq-one__info__text -->
						</div><!-- /.faq-one__info__inner -->
					</div><!-- /.faq-one__info -->
				</div><!-- /.faq-one__image -->
			</div><!-- /.col-lg-6 -->
			<div class="col-lg-6">
				<div class="faq-one__content">
					<div class="faq-accordion cherito-accordion" data-grp-name="cherito-accordion">
						<div class="accordion wow fadeInUp" data-wow-duration="1500ms">
							<div class="accordion-title">
								<h4>How do I choose a long-term care facility?</h4>
								<span class="accordion-title__box"></span><!-- /.accordion-title__box -->
							</div><!-- /.accordion-title -->
							<div class="accordion-content">
								<div class="inner">
									<p>If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't
										anything embarrassing hidden in the middle of text.</p>
								</div><!-- /.inner -->
							</div><!-- /.accordion-content -->
						</div><!-- /.accordion-item -->
						<div class="accordion active wow fadeInUp" data-wow-duration="1500ms">
							<div class="accordion-title">
								<h4>How can I help my older parents from afar?</h4>
								<span class="accordion-title__box"></span><!-- /.accordion-title__box -->
							</div><!-- /.accordion-title -->
							<div class="accordion-content">
								<div class="inner">
									<p>There are many variations of passages of Lorem Ipsum available, but the majority
										have suffered alteradution in some form by injected humour, or randomised words
										which don't look even slightly.</p>
								</div><!-- /.inner -->
							</div><!-- /.accordion-content -->
						</div><!-- /.accordion-item -->
						<div class="accordion wow fadeInUp" data-wow-duration="1500ms">
							<div class="accordion-title">
								<h4>How can we pay for long-term care?</h4>
								<span class="accordion-title__box"></span><!-- /.accordion-title__box -->
							</div><!-- /.accordion-title -->
							<div class="accordion-content">
								<div class="inner">
									<p>Bring to the table win-win survival strategies to ensure proactive domination. At
										the end of the day, going forward, a new normal that has evolved.</p>
								</div><!-- /.inner -->
							</div><!-- /.accordion-content -->
						</div><!-- /.accordion-item -->
						<div class="accordion wow fadeInUp" data-wow-duration="1500ms">
							<div class="accordion-title">
								<h4>How can I talk with an older person’s doctor?</h4>
								<span class="accordion-title__box"></span><!-- /.accordion-title__box -->
							</div><!-- /.accordion-title -->
							<div class="accordion-content">
								<div class="inner">
									<p>Prior to joining company, she spent 20+ years at Inmosys, where he held a wide
										range of global leadership roles, from services to products.</p>
								</div><!-- /.inner -->
							</div><!-- /.accordion-content -->
						</div><!-- /.accordion-item -->
						<div class="accordion wow fadeInUp" data-wow-duration="1500ms">
							<div class="accordion-title">
								<h4>I’m new to caregiving. Where do I start?</h4>
								<span class="accordion-title__box"></span><!-- /.accordion-title__box -->
							</div><!-- /.accordion-title -->
							<div class="accordion-content">
								<div class="inner">
									<p>Out of scope critical mass. Can you put it on my calendar? price point. Herding
										cats we don't need to boil the ocean here. Per my previous email we need to get
										all stakeholders.</p>
								</div><!-- /.inner -->
							</div><!-- /.accordion-content -->
						</div><!-- /.accordion-item -->
					</div><!-- /.faq-accordion -->
				</div><!-- /.faq-one__content -->
			</div><!-- /.col-lg-6 -->
		</div><!-- /.row gutter-y-50 -->
	</div><!-- /.container -->
</section><!-- /.faq-one section-space-top -->

<section class="faq-contact section-space-bottom">
	<div class="container">
		<div class="faq-contact__inner">
			<div class="faq-contact__row">
				<div class="faq-contact__info faq-contact__info--1 wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
					<span class="faq-contact__info__icon">
						<i class="icon-envelope-2"></i>
					</span><!-- /.faq-contact__info__icon -->
					<div class="faq-contact__info__content">
						<h4 class="faq-contact__info__title">Ask the Help Community Write Now!</h4>
						<!-- /.faq-contact__info__title -->
						<a href="mailto:needhelp@company.com" class="faq-contact__info__link">needhelp@company.com</a>
						<!-- /.faq-contact__info__link -->
					</div><!-- /.faq-contact__info__content -->
				</div><!-- /.faq-contact__info -->
				<div class="faq-contact__info wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
					<span class="faq-contact__info__icon">
						<i class="icon-phone-call-2"></i>
					</span><!-- /.faq-contact__info__icon -->
					<div class="faq-contact__info__content">
						<h4 class="faq-contact__info__title">Still have Questions? Call Now!</h4>
						<!-- /.faq-contact__info__title -->
						<a href="tel:+9238008060" class="faq-contact__info__link">+92 3800 8060</a>
						<!-- /.faq-contact__info__link -->
					</div><!-- /.faq-contact__info__content -->
				</div><!-- /.faq-contact__info -->
			</div><!-- /.row gutter-y-40 -->
		</div><!-- /.faq-contact__inner -->
	</div><!-- /.container -->
</section><!-- /.faq-contact section-space-bottom -->


 @endsection