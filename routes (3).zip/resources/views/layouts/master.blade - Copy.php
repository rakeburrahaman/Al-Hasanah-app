<?php
use App\Models\Setting;
$settings = Setting::find(1);
if($settings->active != 'on'){  ?>
    <script>
        window.location.href = '{{url("maintenance")}}';
    </script>	
<?php } ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>{{$settings->title}}</title>
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('frontend/assets/images/logo-1.png') }}" />
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('frontend/assets/images/logo-1.png') }}" />
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('frontend/assets/images/logo-1.png') }}" />
    <link rel="manifest" href="{{ asset('frontend/assets/images/favicons/site.webmanifest') }}" />
    <meta name="description" content="{{$settings->meta_description}}" />

    

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/bootstrap/css/bootstrap.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/bootstrap-select/bootstrap-select.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/animate/animate.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/fontawesome/css/all.min.css') }}" />
	{{-- <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/fontawesome/css/all.min.css') }}" /> --}}



    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/jquery-ui/jquery-ui.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/jarallax/jarallax.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/nouislider/nouislider.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/nouislider/nouislider.pips.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/ion.rangeSlider/css/ion.rangeSlider.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/tiny-slider/tiny-slider.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/cherito-icons/style.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/owl-carousel/css/owl.carousel.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/owl-carousel/css/owl.theme.default.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/vendors/slick-slider/css/slick.css') }}" />

    <!-- template styles -->
    <link rel="stylesheet" href="{{ asset('frontend/assets/css/cherito.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/css/custom.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/assets/css/color-2.css') }}">
</head>

<body class="custom-cursor">

    <div class="custom-cursor__cursor"></div>
    <div class="custom-cursor__cursor-two"></div>

    <div class="preloader">
        <div class="preloader__image" style="background-image: url(assets/images/loader-3.png);"></div>
    </div>
    <!-- /.preloader -->
    <div class="page-wrapper">
        <div class="topbar topbar--three">
            <div class="topbar__logo logo-retina">
                <a href="/">
                    {{-- <img src="assets/images/logo-3-dark.png" alt="Cherito HTML" width="150"> --}}
					<img src="{{ URL::asset('storage/app/public/'.$settings->logo_header.'')}}" alt="{{$settings->title}}">

                </a>
            </div><!-- /.topbar__logo -->
            <div class="container">
                <div class="topbar__inner">
                    <ul class="topbar__contact list-unstyled">
                        <li>
                            <div class="topbar__contact__info">
                                <span class="topbar__contact__icon">
                                    <i class="icon-phone-call"></i>
                                </span><!-- /.topbar__contact__icon -->
                                <div class="topbar__contact__info__content">
                                    <p class="topbar__contact__title">Call for Donation</p><!-- /.info-title -->
                                    <h4 class="topbar__contact__link">
                                        <a href="tel:{{ $settings->mobile }}">{{ $settings->mobile }}</a>
                                    </h4><!-- /.topbar__contact__link -->
                                </div><!-- /.topbar__contact__info__content -->
                            </div><!-- /.topbar__contact__info -->
                        </li>
                        <li>
                            <div class="topbar__contact__info">
                                <span class="topbar__contact__icon">
                                    <i class="icon-envelope"></i>
                                </span><!-- /.topbar__contact__icon -->
                                <div class="topbar__contact__info__content">
                                    <p class="topbar__contact__title">Send Mail</p><!-- /.info-title -->
                                    <h4 class="topbar__contact__link">
                                        <a href="mailto:{{ $settings->email }}">{{ $settings->email }}</a>
                                    </h4><!-- /.topbar__contact__link -->
                                </div><!-- /.topbar__contact__info__content -->
                            </div><!-- /.topbar__contact__info -->
                        </li>
                        <li>
                            <div class="topbar__contact__info">
                                <span class="topbar__contact__icon">
                                    <i class="icon-location"></i>
                                </span><!-- /.topbar__contact__icon -->
                                <div class="topbar__contact__info__content">
                                    <p class="topbar__contact__title">Visit Office</p><!-- /.info-title -->
                                    <h4 class="topbar__contact__link">
                                        <a href="#">{{ $settings->address }}</a>
                                    </h4><!-- /.topbar__contact__link -->
                                </div><!-- /.topbar__contact__info__content -->
                            </div><!-- /.topbar__contact__info -->
                        </li>
                    </ul><!-- /.topbar__contact list-unstyled -->
                    <div class="topbar__social">
                        <div class="social-links">
                            <a href="{{ $settings->fb_link }}">
                                <span class="social-links__icon">
                                    <i class="fab fa-facebook-f" aria-hidden="true"></i>
                                    <span class="sr-only">Facebook</span>
                                </span><!-- /.social-links__icon -->
                            </a>
                            <a href="{{ $settings->twitter_link }}">
                                <span class="social-links__icon">
                                    <i class="fab fa-twitter" aria-hidden="true"></i>
                                    <span class="sr-only">Twitter</span>
                                </span><!-- /.social-links__icon -->
                            </a>
                            <a href="{{ $settings->pinterest_link }}">
                                <span class="social-links__icon">
                                    <i class="fab fa-pinterest-p" aria-hidden="true"></i>
                                    <span class="sr-only">Pinterest</span>
                                </span><!-- /.social-links__icon -->
                            </a>
                            <a href="{{ $settings->youtube_link }}">
                                <span class="social-links__icon">
                                    <i class="fab fa-youtube" aria-hidden="true"></i>
                                    <span class="sr-only">Youtube</span>
                                </span><!-- /.social-links__icon -->
                            </a>
                        </div><!-- /.social-links -->
                    </div><!-- /.topbar__social -->
                </div><!-- /.topbar__inner -->
            </div><!-- /.container -->
        </div><!-- /.topbar -->
        <header class="main-header main-header--three sticky-header sticky-header--normal">
            <div class="container">
                <div class="main-header__inner">
                    <div class="main-header__left">
                        <div class="main-header__logo logo-retina">
                            <a href="/">
								<img src="{{ asset('frontend/assets/images/logo-1.png') }}" alt="Cherito HTML" width="150">
                            </a>
                        </div><!-- /.main-header__logo -->
                        <nav class="main-header__nav main-menu">
                            <ul class="main-menu__list">

								<li>
                                    <a href="/">Home</a>
                                </li>
								<li>
                                    <a href="/about">About</a>
                                </li>
                                {{-- <li class="dropdown">
                                    <a href="#">Events
									</a>
                                </li> --}}
                                <li class="dropdown1">
                                    <a href="/program/ramadan-connect-2025">Ramadan Connect 2025
									</a>
                                </li>
                                <li class="dropdown1">
                                    <a href="/program">Programs</a>
                                </li>
                                <li class="dropdown">
                                    <a href="/blog">Blog</a>
                                </li>
                                <li>
                                    <a href="/contact">Contact</a>
                                </li>
                            </ul>
                        </nav><!-- /.main-header__nav -->
                    </div><!-- /.main-header__left -->
                    <div class="main-header__right">
                        <div class="mobile-nav__btn mobile-nav__toggler">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- /.mobile-nav__toggler -->
                        <a href="#" class="main-header__search search-toggler">
                            <span class="main-header__search__icon">
                                <i class="icon-search" aria-hidden="true"></i>
                                <span class="sr-only">Search</span>
                            </span>
                        </a><!-- /.main-header__search -->
                        <!-- /.main-header__cart -->
                        <a href="/contact" class="main-header__btn cherito-btn cherito-btn--black">
                            <span class="cherito-btn__text">Donate Now</span>
                            <span class="cherito-btn__hover cherito-btn__hover--1"></span>
                            <span class="cherito-btn__hover cherito-btn__hover--2"></span>
                            <span class="cherito-btn__hover cherito-btn__hover--3"></span>
                            <span class="cherito-btn__hover cherito-btn__hover--4"></span>
                            <span class="cherito-btn__hover cherito-btn__hover--5"></span>
                        </a>
                        <!-- /.cherito-btn -->
                    </div><!-- /.main-header__right -->
                </div><!-- /.main-header__inner -->
            </div><!-- /.container -->
        </header><!-- /.main-header -->
		
 
		 

@yield('main_content') 
		

			
<footer class="main-footer main-footer--home3">
	<div class="main-footer__top">
		<div class="main-footer__bg">
			<div class="main-footer__bg__inner" style="background-image: url('{{ asset('frontend/assets/images/backgrounds/footer-bg-3.jpg') }}');"></div>

		</div><!-- /.main-footer__bg -->
		<div class="container">
			<div class="row gutter-y-40">
				<div class="col-xl-4 col-lg-6 col-md-8 wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
					<div class="footer-widget footer-widget--about">
						<a href="/" class="footer-widget__logo">
							<img src="{{ asset('frontend/assets/images/logo-1.png') }}" width="150" alt="Cherito HTML Template">
						</a><!-- /.footer-widget__logo -->
						<p class="footer-widget__about">{{ $settings->short_description }}</p><!-- /.footer-widget__about -->
						<form action="#" class="footer-widget__subscribe mc-form" data-url="MAILCHIMP_FORM_URL">
							<input type="email" name="EMAIL" id="subscribe" placeholder="Email Address">
							<button type="submit"><span class="icon-paper-plane"></span></button>
						</form><!-- /.footer-widget__subscribe -->
						<div class="social-links">
							<a href="{{ $settings->fb_link }}">
								

								<span class="social-links__icon">
									<i class="fab fa-facebook-f" aria-hidden="true"></i>
									<span class="sr-only">Facebook</span>
								</span><!-- /.social-links__icon -->
							</a>
							<a href="{{ $settings->twitter_link }}">
								<span class="social-links__icon">
									<i class="fab fa-twitter" aria-hidden="true"></i>
									<span class="sr-only">Twitter</span>
								</span><!-- /.social-links__icon -->
							</a>
							<a href="{{ $settings->pinterest_link }}">
								<span class="social-links__icon">
									<i class="fab fa-pinterest-p" aria-hidden="true"></i>
									<span class="sr-only">Pinterest</span>
								</span><!-- /.social-links__icon -->
							</a>
							<a href="{{ $settings->youtube_link }}">
								<span class="social-links__icon">
									<i class="fab fa-youtube" aria-hidden="true"></i>
									<span class="sr-only">Youtube</span>
								</span><!-- /.social-links__icon -->
							</a>
						</div><!-- /.social-links -->
					</div><!-- /.footer-widget -->
				</div><!-- /.col-xl-4 col-lg-6 col-md-8 -->
				<div class="col-xl-2 col-lg-3 col-md-4 wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
					<div class="footer-widget footer-widget--links footer-widget--links-1">
						<h2 class="footer-widget__title">Links</h2><!-- /.footer-widget__title -->
						<ul class="list-unstyled footer-widget__links">
							<li><a href="/about">About Us</a></li>
							<li><a href="/program/ramadan-connect-2025">Ramadan 2025</a></li>
							<li><a href="/Program">Programs</a></li>
							<li><a href="/contact">Contact</a></li>
						</ul><!-- /.list-unstyled footer-widget__links -->
					</div><!-- /.footer-widget -->
				</div><!-- /.col-xl-2 col-lg-3 col-md-4 -->
				<div class="col-xl-1 d-none d-xl-block">
					<div class="footer-widget footer-widget--border"></div><!-- /.footer-widget -->
				</div><!-- /.col-xl-1 -->
				<div class="col-xl-2 col-lg-3 col-md-5 wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
					<div class="footer-widget footer-widget--links footer-widget--links-2">
						<h2 class="footer-widget__title">Explore</h2><!-- /.footer-widget__title -->
						<ul class="list-unstyled footer-widget__links">
							<li><a href="#">Donate</a></li>
							{{-- <li><a href="#">Campaigns</a></li>
							<li><a href="#">Fundraise</a></li>
							<li><a href="#">Online Service</a></li>
							<li><a href="#">Volunteers</a></li> --}}
							<li><a href="/contact">Help</a></li>
						</ul><!-- /.list-unstyled footer-widget__links -->
					</div><!-- /.footer-widget -->
				</div><!-- /.col-xl-2 col-lg-3 col-md-5 -->
				<div class="col-xl-3 col-lg-4 col-md-7 wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="300ms">
					<div class="footer-widget footer-widget--info">
						<h2 class="footer-widget__title">Contact</h2><!-- /.footer-widget__title -->
						<ul class="list-unstyled footer-widget__info">
							<li>
								<div class="footer-widget__info__icon-box">
									<span class="footer-widget__info__icon">
										<i class="icon-phone-call-2"></i>
									</span>
								</div><!-- /.footer-widget__info__icon-box -->
								<div class="footer-widget__info__text-box">
									<h3 class="footer-widget__info__text"><a href="tel:{{$settings->mobile}}">{{$settings->mobile}}</a>
									</h3>
									{{-- <h3 class="footer-widget__info__text"><a href="tel:+219555-0114">+21 9555-0114</a>
									</h3> --}}
								</div><!-- /.footer-widget__info__text-box -->
							</li>
							<li>
								<div class="footer-widget__info__icon-box">
									<span class="footer-widget__info__icon">
										<i class="icon-glove"></i>
									</span>
								</div><!-- /.footer-widget__info__icon-box -->
								<div class="footer-widget__info__text-box">
									<h3 class="footer-widget__info__text"><a href="mailto:{{$settings->email}}">{{$settings->email}}
									</a></h3>
									
								</div><!-- /.footer-widget__info__text-box -->
							</li>
							<li>
								<div class="footer-widget__info__icon-box">
									<span class="footer-widget__info__icon">
										<i class="icon-location"></i>
									</span>
								</div><!-- /.footer-widget__info__icon-box -->
								<div class="footer-widget__info__text-box">
									<h3 class="footer-widget__info__text"><a href="../../www.google.com/maps.html">{{$settings->map}}</a></h3>
								</div><!-- /.footer-widget__info__text-box -->
							</li>
						</ul><!-- /.list-unstyled -->
					</div><!-- /.footer-widget -->
				</div><!-- /.col-xl-3 col-lg-4 col-md-7 -->
			</div><!-- /.row gutter-y-40 -->
		</div><!-- /.container -->
	</div><!-- /.main-footer__top -->
	<div class="main-footer__bottom">
		<div class="container">
			<div class="main-footer__bottom__inner">
				<p class="main-footer__copyright">
					&copy; Copyright <span class="dynamic-year"></span> by <a style="color: orange" href="https://ordevs.com/">orDevs</a>.
				</p>
			</div><!-- /.main-footer__inner -->
		</div><!-- /.container -->
	</div><!-- /.main-footer__bottom -->
</footer><!-- /.main-footer -->

</div><!-- /.page-wrapper -->

<div class="mobile-nav__wrapper">
<div class="mobile-nav__overlay mobile-nav__toggler"></div><!-- /.mobile-nav__overlay -->
<div class="mobile-nav__content">
	<span class="mobile-nav__close mobile-nav__toggler"><i class="icon-close"></i></span>
	<div class="logo-box logo-retina">
		<a href="/" aria-label="logo image">
			<img src="assets/images/logo-3-light.png" width="150" alt="logo" />
		</a>
	</div><!-- /.logo-box -->
	<div class="mobile-nav__container"></div><!-- /.mobile-nav__container -->
	<ul class="mobile-nav__contact list-unstyled">
		<li>
			<span class="mobile-nav__contact__icon"><i class="fa fa-envelope"></i></span>
			<a href="mailto:{{$settings->email}}">{{$settings->email}}</a>
		</li>
		<li>
			<span class="mobile-nav__contact__icon"><i class="fa fa-phone-alt"></i></span>
			<a href="tel:+9156980036420">{{$settings->mobile}}</a>
		</li>
	</ul><!-- /.mobile-nav__contact -->
	<div class="mobile-nav__social social-links">
		<a href="{{ $settings->fb_link }}">
			<span class="social-links__icon">
				<i class="fab fa-facebook-f" aria-hidden="true"></i>
				<span class="sr-only">Facebook</span>
			</span><!-- /.social-links__icon -->
		</a>
		<a href="{{ $settings->twitter_link }}">
			<span class="social-links__icon">
				<i class="fab fa-twitter" aria-hidden="true"></i>
				<span class="sr-only">Twitter</span>
			</span><!-- /.social-links__icon -->
		</a>
		<a href="{{ $settings->pinterest_link }}">
			<span class="social-links__icon">
				<i class="fab fa-pinterest-p" aria-hidden="true"></i>
				<span class="sr-only">Pinterest</span>
			</span><!-- /.social-links__icon -->
		</a>
		<a href="{{ $settings->youtube_link }}">
			<span class="social-links__icon">
				<i class="fab fa-youtube" aria-hidden="true"></i>
				<span class="sr-only">Youtube</span>
			</span><!-- /.social-links__icon -->
		</a>
	</div><!-- /.mobile-nav__social -->
</div><!-- /.mobile-nav__content -->
</div><!-- /.mobile-nav__wrapper -->

<div class="search-popup">
<div class="search-popup__overlay search-toggler"></div>
<!-- /.search-popup__overlay -->
<div class="search-popup__content">
	<form role="search" method="get" class="search-popup__form" action="#">
		<input type="text" id="search" placeholder="Search Here..." />
		<button type="submit" aria-label="search submit" class="cherito-btn">
			<i class="icon-search"></i>
		</button>
	</form>
</div>
<!-- /.search-popup__content -->
</div>
<!-- /.search-popup -->

<a href="#" data-target="html" class="scroll-to-target scroll-to-top">
<span class="scroll-to-top__text">back top</span>
<span class="scroll-to-top__wrapper"><span class="scroll-to-top__inner"></span></span>
</a>

{{-- <script src="{{ asset('frontend/assets/vendors/jquery/jquery-3.7.0.min.js') }}"></script> --}}

<script src="{{ asset('frontend/assets/vendors/jquery/jquery-3.7.0.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/bootstrap-select/bootstrap-select.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/jarallax/jarallax.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/jquery-ui/jquery-ui.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/jquery-appear/jquery.appear.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/jquery-validate/jquery.validate.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/nouislider/nouislider.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/ion.rangeSlider/js/ion.rangeSlider.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/tiny-slider/tiny-slider.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/wnumb/wNumb.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/owl-carousel/js/owl.carousel.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/slick-slider/js/slick.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/wow/wow.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/imagesloaded/imagesloaded.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/isotope/isotope.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/countdown/countdown.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/jquery-circleType/jquery.circleType.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/jquery-lettering/jquery.lettering.min.js') }}"></script>
<script src="{{ asset('frontend/assets/vendors/circle-progress/circle-progress.min.js') }}"></script>
<!-- template js -->
<script src="{{ asset('frontend/assets/js/cherito.js') }}"></script>

</body>

</html>