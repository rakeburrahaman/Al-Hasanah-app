Hey There, <br><br>

I’m Vee, the owner of Beach Yoga SoCal and I’d like to personally thank you for signing up to our Soundbath Meditation App.<br><br>

Inner Wonders Soundbath app was developed with hopes that everyone will get to experience sound healing from the comfort of their homes. <br><br>

I’d love to hear what you think of Inner Wonders App and if there is anything we can improve. If you have any questions, please reply to this email. I’m always happy to help!<br><br>

To download the app please Click here or go to: https://bit.ly/innerwondersapp

Use promo code: BEACHYOGA<br><br>

Thank you!
<br>
Walter 
