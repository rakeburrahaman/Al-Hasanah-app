Please click the below link to reset pasword.
<br><br>
<a href="{{env('APP_URL')}}/new-password?code={{$email_data['reset_pass_code']}}">Reset Password Link</a>
<br><br>

Thank you!
<br>
{{env('APP_NAME')}} Team.
