@extends('layouts.master')
@section('main_content')

   <!--================= Product-details Section Start Here =================-->
   <div class="rts-product-details-section section-gap">
    <div class="container">
        <div class="details-product-area mb--70">
            <div class="product-thumb-area">
                <div class="cursor"></div>
            
                @foreach ($images as $index => $image)
                    <div class="thumb-wrapper {{ $index === 0 ? 'one' : ($index === 1 ? 'two' : 'three') }} filterd-items {{ $index === 0 ? '' : 'hide' }}">
                        <div class="product-thumb zoom" onmousemove="zoom(event)"
                            style="background-image: url('{{ asset('storage/images/' . $image) }}')">
                            <img src="{{ asset('images/' . $image) }}" alt="product-thumb">
                        </div>
                    </div>
                @endforeach
            
                <div class="product-thumb-filter-group">
                    @foreach ($images as $index => $image)
                        <div class="thumb-filter filter-btn {{ $index === 0 ? 'active' : '' }}" data-show=".{{ $index === 0 ? 'one' : ($index === 1 ? 'two' : 'three') }}">
                            <img src="{{ asset('images/' . $image) }}" alt="product-thumb-filter">
                        </div>
                    @endforeach
                </div>
            </div>
            
            <div class="contents">
                <div class="product-status">
                    <span class="product-catagory">{{$item->category->name}}</span>
                    <div class="rating-stars-group">
                        <div class="rating-star"><i class="fas fa-star"></i></div>
                        <div class="rating-star"><i class="fas fa-star"></i></div>
                        <div class="rating-star"><i class="fas fa-star-half-alt"></i></div>
                        <span>10 Reviews</span>
                    </div>
                </div>
                <h2 class="product-title">
                        {{ $item->name }}
                    <span class="stock">In Stock</span>
                </h2>
                
                <span class="product-price">
                    @if ($item->mrsp != null)
                        <span class="old-price">{{ $item->mrsp }}৳</span>
                    @endif
                    {{ $item->price }}৳</span>
                <p>
                    {{ $item->short_description }}
                </p>
                <div class="product-bottom-action">
                    <div class="cart-edit">
                        <div class="quantity-edit action-item">
                            <button class="button"><i class="fal fa-minus minus"></i></button>
                            <input type="text" class="input" value="01" />
                            <button class="button plus">+<i class="fal fa-plus plus"></i></button>
                        </div>
                    </div>
                    <a href="cart.html" class="addto-cart-btn action-item"><i class="rt-basket-shopping"></i> Add To
                        Cart</a>
                    <a href="wishlist.html" class="wishlist-btn action-item"><i class="rt-heart"></i></a>
                </div>
                <div class="product-uniques">
                    <span class="sku product-unipue"><span>SKU: </span> BO1D0MX8SJ</span>
                    <span class="catagorys product-unipue"><span>Categories: </span> {{$item->category->name}}</span>
                    <span class="tags product-unipue"><span>Tags:  </span> {{$item->tags}}  </span>
                </div>
                <div class="share-social">
                    <span>Share:</span>
                    <a class="platform" href="http://facebook.com/" target="_blank"><i
                            class="fab fa-facebook-f"></i></a>
                    <a class="platform" href="http://twitter.com/" target="_blank"><i class="fab fa-twitter"></i></a>
                    <a class="platform" href="http://behance.com/" target="_blank"><i class="fab fa-behance"></i></a>
                    <a class="platform" href="http://youtube.com/" target="_blank"><i class="fab fa-youtube"></i></a>
                    <a class="platform" href="http://linkedin.com/" target="_blank"><i
                            class="fab fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div class="product-full-details-area">
            <div class="details-filter-bar2">
                <button class="details-filter filter-btn active" data-show=".dls-one">Description</button>
                <button class="details-filter filter-btn" data-show=".dls-two">Additional information</button>
                <button class="details-filter filter-btn" data-show=".dls-three">Reviews (0)</button>
            </div>
            <div class="full-details dls-one filterd-items">
                <div class="full-details-inner">
                    <p class="mb--30">{{ $item->description }}</p>
                </div>
            </div>
            <div class="full-details dls-two filterd-items hide">
                <div class="full-details-inner">
                    <p class="mb--30">{{$item->short_description}}</p>
                </div>
            </div>
            <div class="full-details dls-three filterd-items hide">
                <div class="full-details-inner">
                    <p>There are no reveiws yet.</p>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 mr-10">
                            <div class="reveiw-form">
                                <h2 class="section-title">
                                    Be the first to reveiw <strong> <a href="product-details.html">"Wide Cotton Tunic Dress"</a></strong></h2>
                                    <h4 class="sect-title">Your email address will not be published. Required fields are marked* </h4>
                                    <div class="reveiw-form-main mb-10">
                                        <div class="contact-form">
                                            <div class="row">
                                                <div class="col-lg-6 col-sm-12">
                                                    <div class="input-box text-input mb-20">
                                                        <textarea name="Message" id="validationDefault01"  cols="30" rows="10"
                                                            placeholder="Your Review*" required></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6 col-sm-12">
                                                    <div class="col-lg-12">
                                                        <div class="input-box mb-20">
                                                            <input type="text" id="validationDefault02" placeholder="Name*" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="input-box mail-input mb-20">
                                                            <input type="text" id="validationDefault03" placeholder="E-mail*" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="rating">
                                                            <p>Your Rating :</p>
                                                            <div class="rating-icon">
                                                                <span class="one"><a href="#"> <i class="fal fa-star"></i></a></span>
                                                                <span class="two"><a href="#"> <i class="fal fa-star"></i></a></span>
                                                                <span class="three"><a href="#"> <i class="fal fa-star"></i></a></span>
                                                                <span class="four"><a href="#"> <i class="fal fa-star"></i></a></span>
                                                                <span class="five"><a href="#"> <i class="fal fa-star"></i></a></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12 mb-15">
                                                        <button class="form-btn form-btn4">
                                                            Submit <i class="fal fa-long-arrow-right"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
        
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--================= Product-details Section End Here =================-->

<!--================= Related Product Section Start Here =================-->
<div class="rts-featured-product-section1 related-product related-product1">
    <div class="container">
        <div class="rts-featured-product-section-inner">
            <div class="section-header section-header3 section-header6">
                <div class="wrapper">
                    <h2 class="title">RELATED PRODUCT</h2>
                </div>
            </div>
            <div class="row">

                @foreach ($related_products as $item)
                @php
                    $image = explode('|', $item->images); 
                @endphp
                <div class="col-xl-3 col-md-4 col-sm-6 col-12">
                    <div class="product-item element-item1">
                        <a href="{{ route('product.show', $item->slug) }}" class="product-image image-hover-variations">
                            <div class="image-vari1 image-vari">
                                <img src="{{ asset('images/' . $image[0]) }}" alt="{{ $item->name }}">
                            </div>
                            <div class="image-vari2 image-vari">
                                <img src="{{ asset('images/' . $image[0]) }}" alt="{{ $item->name }}">
                            </div>
                        </a>
                        <div class="bottom-content">
                            <div class="star-rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <a href="{{ route('product.show', $item->slug) }}" class="product-name">{{ $item->name }}</a>
                            <div class="action-wrap">
                                <span class="price">৳{{ number_format($item->price, 2) }}</span>
                            </div>
                        </div>
                        <div class="quick-action-button">
                            <div class="cta-single cta-plus">
                                <a href="#"><i class="rt-plus"></i></a>
                            </div>
                            <div class="cta-single cta-quickview">
                                <a href="#"><i class="far fa-eye"></i></a>
                            </div>
                            <div class="cta-single cta-wishlist">
                                <a href="#"><i class="far fa-heart"></i></a>
                            </div>
                            <div class="cta-single cta-addtocart">
                                <a href="#"><i class="rt-basket-shopping"></i></a>
                            </div>
                        </div>
                    </div>
                </div>   
            @endforeach
            
                 

            </div>
        </div>
    </div>
</div>
<!--================= Related Product Section End Here =================-->


<div class="rts-account-section"></div>

@endsection