<?php

namespace App\Exports;

use App\Models\Lead;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromQuery;
use DB;


class LeadsExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */

    public function __construct($source, $client, $report_from, $report_to)
    {
        $this->source = $source;
        $this->client = $client;
        $this->report_from = $report_from;
        $this->report_to = $report_to;
    }

    public function collection()
    {
        $from = date("$this->report_from H:i:s", mktime(00,00,00)); 
        $to = date("$this->report_to H:i:s", mktime(23,59,59));
        
        if($this->report_to == ""){
            $to = date("Y-m-d H:i:s", mktime(23,59,59));
        }    

        if($this->source != ''){
            if($this->client==''){   
              $fetch = DB::table('leads')
              ->where('lead_provider_id', $this->source)
              ->whereBetween('created_at', [$from, $to])
              ->get();
            }              
            else{
              $fetch = DB::table('leads')
              ->where('client', $this->client)
              ->where('lead_provider_id', $this->source)
              ->whereBetween('created_at', [$from, $to]) 
              ->get();  
            }
        }else{
            if($this->client==''){   
              $fetch = DB::table('leads')
              ->whereBetween('created_at', [$from, $to])
              ->get();
            }              
            else{
              $fetch = DB::table('leads')
              ->where('client', $this->client)
              ->whereBetween('created_at', [$from, $to]) 
              ->get();  
            }
        }

        //return Lead::all()->where('client', $this->client);
        return $fetch;
    }
}
