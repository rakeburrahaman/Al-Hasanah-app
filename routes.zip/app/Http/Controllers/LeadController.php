<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\LeadsExport;
use DB;
// use Excel;
use Session;
session_start(); //this will control back btn click effect

use Carbon\Carbon;

use Barryvdh\DomPDF\Facade as PDF;
use Twilio\Rest\Client;  

class LeadController
{
    public function __construct(){
        //echo $user_id = Session::get('user_id');
     }
     public function authCheck() 
     {
       $user_id = Session::get('user_id');
       $name = Session::get('name');
 
       if ($user_id) {
         return;
       }else{
         return Redirect::to('/xyz')->send();
       }
     }
    
    public function export()  {
        // return Excel::download(new LeadsExport, 'leads_report.csv')->with('id', '50');
        $id=10;
        return Excel::download(new LeadsExport($id), 'leads_report.csv');
    }  
    

    public function todaysLead($client)
    {
        $data = DB::table('leads')
        ->where('client', $client)
        ->whereDate('created_at', [Carbon::today()])
        ->get();
        return $data->count();
    }
    public function last7Days($client)
    {
        $data = DB::table('leads')
        ->where('client', $client)
        ->whereBetween('created_at', [date('Y-m-d', strtotime('-7 days')), Carbon::today()])
        ->get();
        return $data->count();
    }
    public function thisMonth($client)
    {
        $data = DB::table('leads')
        ->where('client', $client)
        ->whereBetween('created_at', [date('Y-m-01'), date('Y-m-t')])
        ->get();
        return $data->count();
    }
    public function lastMonth($client)
    {
      $first_day_last = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1));
      $last_day_last = date("Y-m-d", mktime(0, 0, 0, date("m"), 0));
      
      $data = DB::table('leads')
        ->where('client', $client)
        ->whereBetween('created_at', [$first_day_last, $last_day_last])
        ->get();
        return $data->count();
    }
    public function tillNow($client)
    {
        $data = DB::table('leads')
        ->where('client', $client)
        ->get();
        return $data->count();
    }

    

   
    public function dashboard()
    {
       
        $fedtax_today_leads = $this->todaysLead('fedtax');
        $fedtax_last_7_days = $this->last7Days('fedtax');
        $fedtax_this_month = $this->thisMonth('fedtax');
        $fedtax_last_month = $this->lastMonth('fedtax');
        $fedtax_till_now = $this->tillNow('fedtax');

        $taxadvocate_today_leads = $this->todaysLead('taxadvocate');
        $taxadvocate_last_7_days = $this->last7Days('taxadvocate');
        $taxadvocate_this_month = $this->thisMonth('taxadvocate');
        $taxadvocate_last_month = $this->lastMonth('taxadvocate');
        $taxadvocate_till_now = $this->tillNow('taxadvocate');

        $ftlg_today_leads = $this->todaysLead('ftlg');
        $ftlg_last_7_days = $this->last7Days('ftlg');
        $ftlg_this_month = $this->thisMonth('ftlg');
        $ftlg_last_month = $this->lastMonth('ftlg');
        $ftlg_till_now = $this->tillNow('ftlg');


        //dd($ftlg_last_7_days);
        
        $this->authCheck();

      // todays_lead
      $today_leads = DB::table('leads')
          ->whereDate('created_at', [Carbon::today()])
          ->get();  

      // last_7_days
      $last_7_days = DB::table('leads')
            ->whereBetween('created_at', [date('Y-m-d', strtotime('-7 days')), Carbon::today()])
            ->get();         
          

      // this_month
      $this_month = DB::table('leads')
            ->whereBetween('created_at', [date('Y-m-01'), date('Y-m-t')])
            ->get();    
  

      // last_month
      $first_day_last = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1));
      $last_day_last = date("Y-m-d", mktime(0, 0, 0, date("m"), 0));

      $last_month = DB::table('leads')
            ->whereBetween('created_at', [$first_day_last, $last_day_last])
            ->get();       
            
      return view('admin.dashboard', ['today_leads'=>$today_leads, 'last_7_days'=>$last_7_days, 'this_month'=>$this_month, 'last_month'=>$last_month, 'fedtax_today_leads'=>$fedtax_today_leads, 'fedtax_last_7_days'=>$fedtax_last_7_days, 'fedtax_this_month'=>$fedtax_this_month, 'fedtax_last_month'=>$fedtax_last_month, 'fedtax_till_now'=>$fedtax_till_now, 'taxadvocate_today_leads'=>$taxadvocate_today_leads, 'taxadvocate_last_7_days'=>$taxadvocate_last_7_days, 'taxadvocate_this_month'=>$taxadvocate_this_month, 'taxadvocate_last_month'=>$taxadvocate_last_month, 'taxadvocate_till_now'=>$taxadvocate_till_now, 'ftlg_today_leads'=>$ftlg_today_leads, 'ftlg_last_7_days'=>$ftlg_last_7_days, 'ftlg_this_month'=>$ftlg_this_month, 'ftlg_last_month'=>$ftlg_last_month, 'ftlg_till_now'=>$ftlg_till_now ]);

    }

    public function myDashboard()
    {
       $this->authCheck();

       $client = Session::get('user');

      // todays_lead
      $today_leads = DB::table('leads')
          ->where('client', $client)
          ->whereDate('created_at', [Carbon::today()])
          ->get();  

      // last_7_days
      $last_7_days = DB::table('leads')
            ->where('client', $client)
            ->whereBetween('created_at', [date('Y-m-d', strtotime('-7 days')), Carbon::today()])
            ->get();         
          

      // this_month
      $this_month = DB::table('leads')
            ->where('client', $client)
            ->whereBetween('created_at', [date('Y-m-01'), date('Y-m-t')])
            ->get();    
  

      // last_month
      $first_day_last = date("Y-m-d", mktime(0, 0, 0, date("m")-1, 1));
      $last_day_last = date("Y-m-d", mktime(0, 0, 0, date("m"), 0));

      $last_month = DB::table('leads')
            ->where('client', $client)
            ->whereBetween('created_at', [$first_day_last, $last_day_last])
            ->get();  

      $till_now = DB::table('leads')
            ->where('client', $client)
            ->get();       
            
      return view('admin.my_dashboard', ['today_leads'=>$today_leads, 'last_7_days'=>$last_7_days, 'this_month'=>$this_month, 'last_month'=>$last_month, 'till_now'=>$till_now]);

    }


    public function create()
    {
      if(Session::get('user_type')=='User'){
        return Redirect::to('/logout'); 
      }
      return view('admin.lead.create');
    }


    public function store(Request $request)
    {
      $CELL_PHONE= $request['CELL_PHONE'];    
      $BEST_TIME_TO_CALL= $request['BEST_TIME_TO_CALL'];    
      $LEAD_PROVIDER_ID= $request['LEAD_PROVIDER_ID'];      
      
      $OFFICERNAME = $request['OFFICERNAME'];    
      $NOTES = $request['NOTES'];
      $NOTES = str_replace(' ', '_', $NOTES);  
      $client_id= $request['client'];       
      
      $data=array();        
      $data['fname']=$request['FNAME'];
      $data['lname']=$request['LNAME']; 
      $data['email']=$request['EMAIL'];
      $data['cell_phone']=$CELL_PHONE; 
      $data['best_time_to_call']=$BEST_TIME_TO_CALL;
      $data['lead_provider_id']=$LEAD_PROVIDER_ID;
      $data['officer_name'] = $OFFICERNAME;
      $data['notes'] = $NOTES;
      $data['client'] = $client_id;
      $data['created_by'] = Session::get('user_id');
      DB::table('leads')->insert($data);  

      return redirect()->back()->with(session()->flash('alert-success', 'Data has been inserted successfully.'));
    }



    public function edit($id)
    {
      $data = Lead::find($id);     
      return view('admin.lead.edit', ['data'=>$data]);
    }

    public function update(Request $request) 
    {       
          $data = Lead::find($request->id);
          $data->clients_note = $request->clients_note;
          $data->lead_type = $request->lead_type;
          $data->updated_by = session('user_id');
          $data->save(); 

          return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));
    }
    

    public function index() 
    {
      $this->authCheck();
      
      $fetch = DB::table('leads')
      ->orderBy('id', 'desc')
      ->limit(1000)
      ->get(); 
      
      if(session('user.client') != null){
        $fetch = DB::table('leads')
        ->where('client', session('user.client')) 
        ->orderBy('id', 'desc')
        ->limit(1000)
        ->get(); 
      }

      if(Session::get('user_type')=='User'){
        $fetch = DB::table('leads')
        ->where('client', Session::get('user')) 
        ->orderBy('id', 'desc')
        ->limit(1000)
        ->get();
      }
      $data=view('admin.lead.index')->with('data',$fetch);

      return view('admin.master')
      ->with('main_content',$data);
    } 
    public function dislikeLead(Request $request){
      $data = Lead::find($request->lead_id);
      $data->lead_type = 'Bad';
      $data->save();
      return response()->json(['success'=>true]);
  }

    
    public function myAccount() 
    {
      $this->authCheck();

      $fetch = DB::table('leads')
      ->where('client', Session::get('user')) 
      ->orderBy('id', 'desc')
      ->limit(1000)
      ->get();
      
      $data=view('admin.my_account')->with('data',$fetch);

      return view('admin.master')
      ->with('main_content',$data);
    } 

  
    public function viewReport(Request $request)
    {
             
      $report_from= $request['report_from']; 
      $from = date("$report_from H:i:s", mktime(00,00,00)); 

      $report_to= $request['report_to'];
      $to = date("$report_to H:i:s", mktime(23,59,59));
      
      if($report_to == ""){
        $to = date("Y-m-d H:i:s", mktime(23,59,59));
      }    

      $client= $request['client']; 
      $source= $request['source']; 
      
      if($source != ''){
          if($client==''){   
            $fetch = DB::table('leads')
            ->where('lead_provider_id', $source)
            ->whereBetween('created_at', [$from, $to])
            ->get();
          }              
          else{
            $fetch = DB::table('leads')
            ->where('client', $client)
            ->where('lead_provider_id', $source)
            ->whereBetween('created_at', [$from, $to]) 
            ->get();  
          }
      }else{
          if($client==''){   
            $fetch = DB::table('leads')
            ->whereBetween('created_at', [$from, $to])
            ->get();
          }              
          else{
            $fetch = DB::table('leads')
            ->where('client', $client)
            ->whereBetween('created_at', [$from, $to]) 
            ->get();  
          }
      }

      $data=array('data'=>$fetch, 'report_from'=>$report_from, 'report_to'=>$report_to, 'client'=>$client);   
      $data=view('admin.lead.report')->with($data);     
       
      $total = count($fetch);
      //dd('Complete');

      Session::put('total', $total); 

      return view('admin.master')
      ->with('main_content',$data);
    }

    public function excelFilter(Request $request)
    {
 
      $report_from= $request['report_from']; 
      $from = date("$report_from H:i:s", mktime(00,00,00)); 
      
      $report_to= $request['report_to'];
      $to = date("$report_to H:i:s", mktime(23,59,59));
      
      if($report_to == ""){
        $to = date("Y-m-d H:i:s", mktime(23,59,59));
      }
      
      $client= $request['client'];        
      $source= $request['source'];

      if($source != ''){
          if($client==''){   
            $fetch = DB::table('leads')
            ->where('lead_provider_id', $source)
            ->whereBetween('created_at', [$from, $to])
            ->get();
          }              
          else{
            $fetch = DB::table('leads')
            ->where('client', $client)
            ->where('lead_provider_id', $source)
            ->whereBetween('created_at', [$from, $to]) 
            ->get();  
          }
      }else{
          if($client==''){   
            $fetch = DB::table('leads')
            ->whereBetween('created_at', [$from, $to])
            ->get();
          }              
          else{
            $fetch = DB::table('leads')
            ->where('client', $client)
            ->whereBetween('created_at', [$from, $to]) 
            ->get();  
          }
      }    
     

      $file_name = 'lead_data_'.$client.'_'.$from.'_'.$to;
   
     $lead_array[] = array('fname', 'lname', 'email', 'cell_phone', 'best_time_to_call', 'lead_provider_id', 'created_at', 'notes');
     foreach($fetch as $lead)
     {
      $lead_array[] = array(
       'first name'  => $lead->fname,
       'last name'   => $lead->lname,
       'email'   => $lead->email,
       'cell_phone'   => $lead->cell_phone,
       'best_time_to_call'   => $lead->best_time_to_call,
       'lead_provider_id'   => $lead->lead_provider_id,
       'created_at'   => $lead->created_at,
       'notes'   => $lead->notes
       
      );
     }
     Excel::create($file_name, function($excel) use ($lead_array){
      $excel->setTitle('Lead Data');
      $excel->sheet('Lead Data', function($sheet) use ($lead_array){
      $sheet->fromArray($lead_array, null, 'A1', false, false);
      });
     })->download('xlsx');
    }


  public function destroy($id)
    {            
        $data = Lead::find($id);
        $data->delete();
        return redirect()->back()->with(session()->flash('alert-success', 'Data has been deleted successfully.'));
    }





}
