<?php

namespace App\Http\Controllers;

use App\Models\Portfolio;
use App\Models\Product;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use DB;

class PortfolioController extends Controller
{
    public function index()
    {
        $data = Portfolio::orderBy('id', 'asc')->get();

        return view('admin.portfolios', ['data' => $data]);               
    }



    public function show($id)
    {
        $fetch = DB::table('portfolios')
                ->where('id',$id)
                ->first();
        $data['hit_count']= $fetch->hit_count+1;
        
        DB::table('portfolios')
        		->where('id',$id)
        		->update($data);

        $page = "Project: " . $fetch->title;

        return view('portfolio_details', ['item' => $fetch, 'page' => $page]);
    }  

     
    

      public function create()
      
      {  
        return view('admin.add_portfolio');
      }

 
    

      
    public function store(Request $request)
    {        
      // $settings = Setting::where('client_id', session('client_id'))->first();
      $settings = Setting::where('client_id', 1)->first();
      if(Portfolio::where('name', $request->name)->first())
      {
          return redirect()->back()->with(session()->flash('alert-warning', 'A term with the name provided already exists!'));       
      } 
      if(is_numeric($request->price) == null){
        return redirect()->back()->with(session()->flash('alert-danger', 'Price should be a number!'));    
      }          

      $input=$request->all();
      $all_images=array();

      if($request->file('productImages') == null){
        //return redirect('add-product')->with(session()->flash('alert-danger', 'Product images can not be null.'));    
      }
      
        //upload images
      $removed_images =$request->excludeImages;   
      $removed_items= explode("*",$removed_images);  

      if($files=$request->file('productImages')){
        foreach($files as $file){
            
            $name_original=$file->getClientOriginalName();               
            if (in_array($name_original, $removed_items)) {
                //echo "Just skip";
            }else{
              $name = time().rand(100,999).'_'.$name_original;                
              $file->move('images',$name);                
              $all_images[]=$name;   
            }             
        }          
      }      
      $final_images = implode('|', $all_images);
      //end upload image   


      $data = new Portfolio;
    
      $data->name = $request->name;
      if(session('client_id') == 11 & $request->category_id == 1847){
        //$data->name = $request->name . ' - ' . $request->brand;
      }

      $data->slug = preg_replace('/\s+/u', '-', trim($request->name));
      $data->tp = $request->tp;
      $data->price = $request->price;
      $data->msrp = $request->msrp;
      $data->category_id = $request->category_id;      
      $data->sub_category_id = $request->sub_category_id;
      $data->description = $request->description;
      $data->short_description = $request->short_description;        
      $data->meta_description = $request->meta_description;
      $data->tags = $request->tags;

      if($request->usages != null)$data->usages = implode(', ', $request->usages);
      if($request->materials != null)$data->materials = implode(', ', $request->materials);
      if($request->hidden_data != null)$data->hidden_data = implode(', ', $request->hidden_data);
      
      $data->code = $request->code;
      $data->sort_order = $request->sort_order;
      $data->barcode = $request->barcode;
      $data->brand = $request->brand;
      $data->model = $request->model;
      $data->pack_size = $request->pack_size;
      $data->particular = $request->particular;
      $data->measurement_unit = $request->measurement_unit;
      $data->warranty = $request->warranty;
      $data->images = $final_images;
      if($request->file('video')!= null){
          $data->video = $request->file('video')->store('videos');
      } 

      $data->product_type = 'Portfolio';
      

      $data->active = $request->active;
      $data->featured = $request->featured;
      $data->is_set = $request->is_set;
      $data->client_id = session('client_id');
      $data->created_by = session('user_id');
      $data->updated_by = '';
      $data->save();    

      return redirect('portfolios')->with(session()->flash('alert-success', 'Data has been inserted successfully.'));    

    }

    public function update(Request $request) 
    {       
      if(Portfolio::where('name', $request->name)->get()->count() > 1)
      {
          return redirect()->back()->with(session()->flash('alert-warning', 'A term with the name provided already exists!'));       
      } 
      //validation
       if(is_numeric($request->price) == null){
          return redirect()->back()->with(session()->flash('alert-danger', 'Price should be a number!'));    
      }   

        $input=$request->all(); 
        $new_images=array();

        $hidden_image =$request->hidden_image;   
        $hidden_image_array= explode("|",$hidden_image); 
        
        $removed_images =$request->excludeImages;   
        $removed_items= explode("*",$removed_images);
  
        if($files=$request->file('productImages')){
            foreach($files as $file){
                $name_original=$file->getClientOriginalName();               
                if (in_array($name_original, $removed_items)) {
                    //echo "Just skip";
                }else{
                  $name = time().rand(100,999).'_'.$name_original;                
                  $file->move('images',$name);                
                  $new_images[]=$name;   
                }
              } 
          }    
      
      $all_selected_images = array_merge($hidden_image_array,$new_images);
      //print_r($all_selected_images);       

      // getting all removed items
      $removed_image = $request->excludeImages;
      $removed_image_array = explode('*',$removed_image);
      $removed_image_name = Array();
      
      foreach($removed_image_array as $image){       
        if($image!=""){
          if(filter_var($image,FILTER_VALIDATE_URL)){
            $pathinfo = pathinfo($image);
            $filename = $pathinfo['basename'];                       
            array_push($removed_image_name,$filename);                
          }
          else{                
              $filtered_image_path = explode('/images/',$image);                
              $filtered_image_path = $filtered_image_path[1];
              array_push($removed_image_name, $filtered_image_path);
          } 
        }            
      }

      // delete removed items
      foreach($removed_image_name as $filename){
        if($filename!=""){
          if (file_exists("images/".$filename)) {              
            // dd("images/".$filename);
            $status = unlink("images/".$filename);
          }
        }
      }
    

        $final_images =  array_diff($all_selected_images, $removed_image_name);          
        $final_images = implode('|', $final_images);
        $final_images = ltrim($final_images, '|'); // Removes leading |

        if($final_images == null){
          //return redirect()->back()->with(session()->flash('alert-danger', 'Product images can not be null.'));    
        }

        $data = Portfolio::find($request->id);
        $data->name = $request->name;
        $data->slug = preg_replace('/\s+/u', '-', trim($request->name));
        $data->images = $final_images;

        if($request->file('video')!= null){
          $data->video = $request->file('video')->store('videos');
        }else{
            $data->video = $request->hidden_video;
        }

        $data->tp = $request->tp;
        $data->price = $request->price;
        $data->msrp = $request->msrp;
        $data->measurement_unit = $request->measurement_unit;
        
        //if($request->sub_category_id != null){
          //$data->category_id = $request->sub_category_id;
        //}else{
          $data->category_id = $request->category_id;
        //}     
        $data->sub_category_id = $request->sub_category_id;
        $data->description = $request->description;
        $data->short_description = $request->short_description;
        $data->meta_description = $request->meta_description;

        if($request->usages != null) $data->usages = implode(', ', $request->usages);
        if($request->materials != null) $data->materials = implode(', ', $request->materials);
        if($request->hidden_data != null)$data->hidden_data = implode(', ', $request->hidden_data);

        $data->code = $request->code;
        $data->sort_order = $request->sort_order;
        $data->barcode = $request->barcode; 
        $data->brand = $request->brand;
        $data->model = $request->model;
        $data->pack_size = $request->pack_size;
        $data->particular = $request->particular;
        $data->warranty = $request->warranty;
        $data->tags = $request->tags;
        $data->active = $request->active;
        $data->featured = $request->featured;
        $data->is_set = $request->is_set;
        $data->updated_by = session('user_id');
        $data->save(); 

        return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));
    }





      public function edit($id){       
        $data = Portfolio::find($id);      
        return view('admin.portfolio_edit', ['data'=>$data]);
      }


    public function destroy($id)
    {
      DB::table('posts')
      ->where('id',$id)
      ->delete();

      return redirect()->back()->with(session()->flash('alert-success', 'Post has been deleted successfully.'));
    }

    /*============================
       End News Post
       ============================*/

     

}
