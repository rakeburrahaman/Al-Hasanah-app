<?php

namespace App\Http\Controllers;

use App\Models\SampleModel;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use DB;

class SampleModelController extends Controller
{
    public function index()
    {
        $data = SampleModel::orderBy('id', 'desc')
              ->where('client_id', session('client_id'))
              ->where('active', 'on')
              ->get();
        return view('admin.folder.index', ['data'=>$data]);        
    }

    public function create()
    {        
      return view('admin.folder.create');
    }

    public function store(Request $request)
    {        
      $data = new SampleModel;
      $data->title = $request->title;   
      
      
      // if($request->file('image')!= null){
      //     $data->image = $request->file('image')->store('images');
      // } 
      $data->active = $request->active;
      $data->created_by = session('user_id');
      $data->client_id = session('client_id');
      $data->updated_by = '';
      $data->save();  
      $data->id;

      return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));

    }

    public function edit($id){
      $data = SampleModel::find($id);      
      return view('admin.folder.edit', ['data'=>$data]);
    }

    public function update(Request $request)
    {       
          $data = SampleModel::find($request->id);
          $data->title = $request->title;
        
          // if($request->file('image')!= null){
          //     $data->image = $request->file('image')->store('images');
          // }else{
          //     $data->image = $request->hidden_image;
          // }
          $data->active = $request->active;
          $data->updated_by = session('user_id');
          $data->save(); 

          return redirect()->back()->with(session()->flash('alert-success', 'Data has been updated successfully.'));
    }

    public function show($id){
      $data = SampleModel::find($id);      
      return view('admin.folder.show', ['data'=>$data]);
    }
    public function destroy($id)
    {
      // DB::table('SampleModels')
      // ->where('id',$id)
      // ->delete();
      $data = SampleModel::find($id);
      $data->active = null;
      $data->save();

      return redirect()->back()->with(session()->flash('alert-success', 'SampleModel has been deleted successfully.'));
    }
}
