
  {{-- end nav item --}}

  {{-- single nav item --}}
  {{-- <li class="nav-item">
    <a href="spl" class="nav-link">
      <i class="nav-icon fas fa-sort-amount-up-alt"></i>
      <span class="nav-text fadeable"><span>Sponsored Licence</span></span>
    </a>
    <b class="sub-arrow"></b>
  </li> --}}
  {{-- end single nav item --}}

  

  {{-- nav item --}}
  <li class="nav-item">
    <a class="nav-link dropdown-toggle collapsed"><i class="nav-icon fas fa-sort-amount-up-alt"></i>
      <span class="nav-text fadeable"><span>Recruitment</span></span><b class="caret fa fa-angle-left rt-n90"></b>
    </a>
    <div class="hideable submenu collapse">
      <ul class="submenu-inner">
        <li class="nav-item">
          <a href="add-job-post" class="nav-link">
              <span class="nav-text"><span style="color: #000">Add Job Post</span></span>
          </a>
        </li>  
        <li class="nav-item">
          <a href="job-posts" class="nav-link">
              <span class="nav-text"><span style="color: #000">All Job List</span></span>
          </a>
        </li> 
        
        <li class="nav-item">
          <a href="job-applications" class="nav-link">
              <span class="nav-text"><span style="color: #000"> Job Applied </span></span>
          </a>
        </li>  
        <li class="nav-item">
          <a href="/job-application/{{'Short Listed'}}" class="nav-link">
              <span class="nav-text"><span style="color: #000"> Short Listed </span></span>
          </a>
        </li>  
        <li class="nav-item">
          <a href="/job-application/{{'Interview Taken'}}" class="nav-link">
              <span class="nav-text"><span style="color: #000"> Interview Taken</span></span>
          </a>
        </li>  
        <li class="nav-item">
          <a href="#" class="nav-link">
              <span class="nav-text"><span style="color: #000"> Mock Interview </span></span>
          </a>
        </li>  
        <li class="nav-item">
          <a href="/job-application/{{'Hired'}}" class="nav-link">
              <span class="nav-text"><span style="color: #000"> Hired </span></span>
          </a>
        </li>  
        <li class="nav-item">
          <a href="add-offer-letter" class="nav-link">
              <span class="nav-text"><span style="color: #000"> Offer Letters </span></span>
          </a>
        </li>    
        <li class="nav-item">
          <a href="#" class="nav-link">
              <span class="nav-text"><span style="color: #000"> Contract Letters </span></span>
          </a>
        </li>  
        <li class="nav-item">
          <a href="#" class="nav-link">
              <span class="nav-text"><span style="color: #000">Recruitement Report</span></span>
          </a>
        </li>       

      </ul>
    </div>
    <b class="sub-arrow"></b>
  </li>
  {{-- end nav item --}}

    {{-- nav item --}}
    <li class="nav-item">
      <a class="nav-link dropdown-toggle collapsed"><i class="nav-icon fas fa-sort-amount-up-alt"></i>
        <span class="nav-text fadeable"><span>Employees</span></span><b class="caret fa fa-angle-left rt-n90"></b>
      </a>
      <div class="hideable submenu collapse">
        <ul class="submenu-inner">
          <li class="nav-item">
            <a href="add-employee" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Add Employee </span></span>
            </a>
          </li> 
          
          <li class="nav-item">
            <a href="employees" class="nav-link">
                <span class="nav-text"><span style="color: #000"> All Employees </span></span>
            </a>
          </li>   
          <li class="nav-item">
            <a href="add-coc" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Change Of Circumstances </span></span>
            </a>
          </li> 
          <li class="nav-item">
            <a href="employees" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Contract Agreement </span></span>
            </a>
          </li>  
  
        </ul>
      </div>
      <b class="sub-arrow"></b>
    </li>
    {{-- end nav item --}}

   

     {{-- nav item --}}
     <li class="nav-item">
      <a class="nav-link dropdown-toggle collapsed"><i class="nav-icon fas fa-sort-amount-up-alt"></i>
        <span class="nav-text fadeable"><span>Attendance</span></span><b class="caret fa fa-angle-left rt-n90"></b>
      </a>
      <div class="hideable submenu collapse">
        <ul class="submenu-inner">
          <li class="nav-item">
            <a href="clock-in-out" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Clock-in/Clock-out</span></span>
            </a>
          </li> 
          
          <li class="nav-item">
            <a href="attendance-sheet" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Attendance Sheet </span></span>
            </a>
          </li>          
         
        </ul>
      </div>
      <b class="sub-arrow"></b>
    </li>
    {{-- end nav item --}}


    {{-- nav item --}}
    <li class="nav-item">
      <a class="nav-link dropdown-toggle collapsed"><i class="nav-icon fas fa-sort-amount-up-alt"></i>
        <span class="nav-text fadeable"><span>Leave Management</span></span><b class="caret fa fa-angle-left rt-n90"></b>
      </a>
      <div class="hideable submenu collapse">
        <ul class="submenu-inner">
          <li class="nav-item">
            <a href="add-leave-type" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Leave Type </span></span>
            </a>
          </li> 
          
          <li class="nav-item">
            <a href="add-leave-rule" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Leave Rule </span></span>
            </a>
          </li>          
          <li class="nav-item">
            <a href="add-leave-allocation" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Leave Allocation </span></span>
            </a>
          </li> 
          <li class="nav-item">
            <a href="" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Leave Balance </span></span>
            </a>
          </li> 
          
          <li class="nav-item">
            <a href="" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Leave Report </span></span>
            </a>
          </li> 

          <li class="nav-item">
            <a href="" class="nav-link">
                <span class="nav-text"><span style="color: #000"> LR Employee wise </span></span>
            </a>
          </li> 
         
          
  
        </ul>
      </div>
      <b class="sub-arrow"></b>
    </li>
    {{-- end nav item --}}
    {{-- nav item --}}
    <li class="nav-item">
      <a class="nav-link dropdown-toggle collapsed"><i class="nav-icon fas fa-sort-amount-up-alt"></i>
        <span class="nav-text fadeable"><span>Holiday Management</span></span><b class="caret fa fa-angle-left rt-n90"></b>
      </a>
      <div class="hideable submenu collapse">
        <ul class="submenu-inner">
          <li class="nav-item">
            <a href="add-holiday-type" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Holiday Type </span></span>
            </a>
          </li> 
          
          <li class="nav-item">
            <a href="holidays" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Holiday List </span></span>
            </a>
          </li>          

        </ul>
      </div>
      <b class="sub-arrow"></b>
    </li>
    {{-- end nav item --}}

      {{-- nav item --}}
      <li class="nav-item">
        <a class="nav-link dropdown-toggle collapsed"><i class="nav-icon fas fa-sort-amount-up-alt"></i>
          <span class="nav-text fadeable"><span>Rota</span></span><b class="caret fa fa-angle-left rt-n90"></b>
        </a>
        <div class="hideable submenu collapse">
          <ul class="submenu-inner">
            <li class="nav-item">
              <a href="add-employee" class="nav-link">
                  <span class="nav-text"><span style="color: #000"> Leave Type </span></span>
              </a>
            </li> 
            
            <li class="nav-item">
              <a href="" class="nav-link">
                  <span class="nav-text"><span style="color: #000"> Leave Rule </span></span>
              </a>
            </li>          
           
          </ul>
        </div>
        <b class="sub-arrow"></b>
      </li>
      {{-- end nav item --}}

        {{-- nav item --}}
     <li class="nav-item">
      <a class="nav-link dropdown-toggle collapsed"><i class="nav-icon fas fa-sort-amount-up-alt"></i>
        <span class="nav-text fadeable"><span>Payroll</span></span><b class="caret fa fa-angle-left rt-n90"></b>
      </a>
      <div class="hideable submenu collapse">
        <ul class="submenu-inner">
          <li class="nav-item">
            <a href="add-employee" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Leave Type </span></span>
            </a>
          </li> 
          
          <li class="nav-item">
            <a href="" class="nav-link">
                <span class="nav-text"><span style="color: #000"> Leave Rule </span></span>
            </a>
          </li>          
         
        </ul>
      </div>
      <b class="sub-arrow"></b>
    </li>
    {{-- end nav item --}}

  


  {{-- nav item --}}
  <li class="nav-item">
    <a class="nav-link dropdown-toggle collapsed"><i class="nav-icon fas fa-sort-amount-up-alt"></i>
      <span class="nav-text fadeable"><span>COS</span></span><b class="caret fa fa-angle-left rt-n90"></b>
    </a>
    <div class="hideable submenu collapse">
      <ul class="submenu-inner">
        <li class="nav-item">
          <a href="#" class="nav-link">
              <span class="nav-text"><span style="color: #000"> --- </span></span>
          </a>
        </li> 
        
        <li class="nav-item">
          <a href="#" class="nav-link">
              <span class="nav-text"><span style="color: #000"> --- </span></span>
          </a>
        </li>  

      </ul>
    </div>
    <b class="sub-arrow"></b>
  </li>
  {{-- end nav item --}}

  {{-- nav item --}}
  <li class="nav-item">
    <a class="nav-link dropdown-toggle collapsed"><i class="nav-icon fas fa-sort-amount-up-alt"></i>
      <span class="nav-text fadeable"><span>Visa Apply</span></span><b class="caret fa fa-angle-left rt-n90"></b>
    </a>
    <div class="hideable submenu collapse">
      <ul class="submenu-inner">
        <li class="nav-item">
          <a href="#" class="nav-link">
              <span class="nav-text"><span style="color: #000"> --- </span></span>
          </a>
        </li> 
        
        <li class="nav-item">
          <a href="#" class="nav-link">
              <span class="nav-text"><span style="color: #000"> --- </span></span>
          </a>
        </li>  

      </ul>
    </div>
    <b class="sub-arrow"></b>
  </li>
  {{-- end nav item --}}
