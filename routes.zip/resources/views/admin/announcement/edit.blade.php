
@extends('admin.master')
@section('main_content')    

  <div class="page-content container container-plus">
    <div class="page-header pb-2">
      <h1 class="page-title text-primary-d2 text-150">
        Update Announcement    
      </h1> 
      <a href="announcements"class="btn btn-default px-3 text-95 radius-round border-2 brc-black-tp10 float-left">
        <i class="fa fa-list mr-1"></i>
        <span class="d-sm-none d-md-inline">All</span> Announcement
      </a>
    </div>   


    <div class="row-md-3">
      <div class="col-12">
        <div class="card dcard">
          <div class="card-body px-1 px-md-3">                                   
            <div role="main" class="main-content">         
              <div class="page-content container container-plus">               

                <form action="update_announcement" method="post" enctype="multipart/form-data">
                  @csrf
                    <div class="row">                      
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="">Title</label>
                          <input type="text" class="form-control" name="title" id="FNAME" placeholder="" required="" value="{{$data->title}}" />
                        </div>  
                      </div>

                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="">Sub Title</label>
                          <input type="text" class="form-control" name="sub_title" id="LNAME" value="{{$data->sub_title}}" />
                        </div>  
                      </div>
                      
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="">Link Title</label>
                          <input type="text" class="form-control" name="link_title"   value="{{$data->link_title}}" />
                        </div>  
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="">Link Action</label>
                          <input type="text" class="form-control" name="link_action" id="CELL_PHONE" value="{{$data->link_action}}" />
                        </div>  
                      </div>
                     
                    </div>
                    <input type="hidden" name="id" value="{{$data->id}}">
                  <button type="submit" class="btn btn-primary">Update</button>
                  <a href="add-lead" class="btn btn-default">Cancel</a>
                </form>
              </div>
            </div>    
          </div>
        </div>           
      </div>
    </div>
  </div>
@endsection