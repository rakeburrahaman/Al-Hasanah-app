
@extends('admin.master')
@section('main_content')
    
@php
  $sells = DB::table('orders')
  ->where('created_at', 'like', '%' .date("Y-m-d"). '%')
  ->where('active', 'on')
  ->sum('total_price');
  $expenses = DB::table('expenses')->where('created_at', 'like', '%' .date("Y-m-d"). '%')->sum('amount');
@endphp

<style>
.text-nowrap.text-100.text-dark-l2 {
  font-weight: 600;
  border-bottom: 1px solid #e9e9e9;
}
</style>
  <div class="page-content container container-plus">
    <div class="page-header pb-2">
      <h1 class="page-title text-primary-d2 text-150">
        Admin Panel
        <small class="page-info text-secondary-d2 text-nowrap">
          <i class="fa fa-angle-double-right text-80"></i>
          {{-- overview &amp; stats --}}
          Hi {{session('user.name')}},  welcome to your Admin Dashboard!
        </small>
      </h1>
    </div>

 
  </div>
 
@endsection