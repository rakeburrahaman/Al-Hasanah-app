@extends('layouts.master')
@section('main_content')


<section class="main-slider-three">
	<div class="main-slider-three__carousel cherito-owl__carousel cherito-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
"items": 1,
"margin": 0,
"animateIn": "fadeIn",
"animateOut": "fadeOut",
"loop": true,
"smartSpeed": 700,
"nav": false,
"dots": true,
"autoplay": true,
"navText": ["<i class=\"icon-left-arrow\"></i>","<i class=\"icon-right-arrow\"></i>"]
}'>
		@foreach ($banner as $item)
			<div class="main-slider-three__item">
				<div class="main-slider-three__bg" style="background-image: url('{{ asset('frontend/assets/images/backgrounds/main-slider-bg-3-1.jpg') }}');">
				</div>
				{{-- <img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->title}}" class="main-slider-three__shape"> --}}
				
				<!-- /.main-slider-three__bg -->
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-xl-10">
							<div class="main-slider-three__content">
								<div class="main-slider-three__top">
									<h6 class="main-slider-three__tagline">Markham Community Connect</h6>
								</div><!-- /.main-slider-three__top -->
								<h2 class="main-slider-three__title">
									<span class="main-slider-three__title__inner">
										{{$item->title}}
									</span>
								</h2><!-- /.main-slider-three__title -->
								<div class="main-slider-three__description">
									<p class="main-slider-three__text">{{$item->short_description}}</p><!-- /.text -->
								</div><!-- /.main-slider-three__description -->
								<div class="about-three__button wow fadeInUp " data-wow-duration="1500ms">
									<a href="/about" class="cherito-btn">
										<span class="cherito-btn__text">Contact Us</span>
										<span class="cherito-btn__hover cherito-btn__hover--1"></span>
										<span class="cherito-btn__hover cherito-btn__hover--2"></span>
										<span class="cherito-btn__hover cherito-btn__hover--3"></span>
										<span class="cherito-btn__hover cherito-btn__hover--4"></span>
										<span class="cherito-btn__hover cherito-btn__hover--5"></span>
									</a><!-- /.cherito-btn -->
								</div><!-- /.about-three__button -->
							</div><!-- /.main-slider-three__content -->
						</div><!-- /.col-xl-10 -->
					</div><!-- /.row -->
				</div><!-- /.container -->
					<img src="{{ asset('frontend/assets/images/shapes/main-slider-shape-3-1.png') }}" alt="shape" class="main-slider-three__shape">
			</div><!-- /.main-slider-three__item -->
		@endforeach
	</div><!-- /.main-slider-three__carousel -->
</section><!-- /.main-slider-three -->


{{-- <div class="image_area_d">
	<img src="{{ URL::asset('storage/app/public/'.$section4->image.'')}}" alt="{{$section4->title}}" class="gr_img"  data-aos="fade-right"> --}}

	<section class="about-three">
		<div class="container">
			<div class="row gutter-y-60 align-items-center">
				<div class="col-lg-6">
					<div class="about-three__content">
						<div class="sec-title @@extraClassName wow fadeInUp" data-wow-duration="1500ms">
							<div class="sec-title__top">
								<h6 class="sec-title__tagline">Join Us For Fun & Development</h6><!-- /.sec-title__tagline -->
							</div><!-- /.sec-title__top -->
							<h3 class="sec-title__title">{{$section1->title}}</h3><!-- /.sec-title__title -->
						</div><!-- /.sec-title -->
						<div class="about-three__text-box wow fadeInUp" data-wow-duration="1500ms">
							<p class="about-three__text">{!!$section1->description!!}</p><!-- /.about-three__text -->
						</div><!-- /.about-three__text-box -->
						<div class="about-three__button wow fadeInUp " data-wow-duration="1500ms">
							<a href="/about" class="cherito-btn">
								<span class="cherito-btn__text">About Us</span>
								<span class="cherito-btn__hover cherito-btn__hover--1"></span>
								<span class="cherito-btn__hover cherito-btn__hover--2"></span>
								<span class="cherito-btn__hover cherito-btn__hover--3"></span>
								<span class="cherito-btn__hover cherito-btn__hover--4"></span>
								<span class="cherito-btn__hover cherito-btn__hover--5"></span>
							</a><!-- /.cherito-btn -->
						</div><!-- /.about-three__button -->
					</div><!-- /.about-three__content -->
				</div><!-- /.col-lg-6 -->
				

				<div class="col-lg-6 wow fadeInUp" data-wow-duration="1500ms">
					<div class="about-three__image">
						<div class="about-three__image__inner">
							<div class="about-three__image__one">
								<img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->title}}">
							</div><!-- /.about-three__image__one -->
							<img src="{{asset('frontend/assets/images/about-shape-3-2.png')}}" alt="shape" class="about-three__image__shape-1">
							<img src="{{asset('frontend/assets/images/about-shape-3-3.png')}}" alt="shape" class="about-three__image__shape-2">
						</div><!-- /.about-three__image__inner -->
					</div><!-- /.about-three__image -->
				</div><!-- /.col-lg-6 -->

				
			</div><!-- /.row gutter-y-60 -->
		</div><!-- /.container -->
		
		<img src="{{ URL::asset('storage/app/public/'.$section1->image.'')}}" alt="{{$section1->title}}" class="about-three__shape">
	</section><!-- /.about-three -->

<section class="pillar-one section-space-top">
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				<h6 class="sec-title__tagline">Impact</h6><!-- /.sec-title__tagline -->
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">Markham Community Connect Impact</h3><!-- /.sec-title__title -->
		</div><!-- /.sec-title -->
		<div class="pillar-one__carousel cherito-owl__carousel cherito-owl__carousel--with-shadow cherito-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
	"items": 1,
	"margin": 0,
	"loop": false,
	"smartSpeed": 700,
	"nav": false,
	"dots": true,
	"navText": ["<i class=\"icon-left-arrow\"></i>","<i class=\"icon-right-arrow\"></i>"],
	"autoplay": true,
	"responsive": {
		"0": {
			"items": 1,
			"nav": true,
			"dots": false
		},
		"576": {
			"items": 2
		},
		"768": {
			"items": 3
		},
		"992": {
			"items": 4
		},
		"1200": {
			"items": 5,
			"dots": false
		}
	}
}'>
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
				<div class="pillar-card pillar-card--1">
					<div class="pillar-card__overlay"></div><!-- /.pillar-card__overlay -->
					<div class="pillar-card__content">
						<div class="pillar-card__icon-box">
							<span class="pillar-card__icon">
								<i class="icon-quran"></i>
							</span><!-- /.pillar-card__icon -->
						</div><!-- /.pillar-card__icon-box -->
						<h3 class="pillar-card__title">Empowering Youth </h3><!-- /.pillar-card__title -->
						<div class="pillar-card__image">
							<img src="{{ asset('frontend/assets/images/pillar/pillar-1-1.jpg') }}" alt="Kalima">
						</div><!-- /.pillar-card__image -->
					</div><!-- /.pillar-card__content -->
				</div><!-- /.pillar-card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
				<div class="pillar-card pillar-card--2">
					<div class="pillar-card__overlay"></div><!-- /.pillar-card__overlay -->
					<div class="pillar-card__content">
						<div class="pillar-card__icon-box">
							<span class="pillar-card__icon">
								<i class="icon-salat"></i>
							</span><!-- /.pillar-card__icon -->
						</div><!-- /.pillar-card__icon-box -->
						<h3 class="pillar-card__title">Building Community</h3><!-- /.pillar-card__title -->
						<div class="pillar-card__image">
							<img src="{{ asset('frontend/assets/images/pillar/pillar-1-2.jpg') }}" alt="Salat">
						</div><!-- /.pillar-card__image -->
					</div><!-- /.pillar-card__content -->
				</div><!-- /.pillar-card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
				<div class="pillar-card pillar-card--3">
					<div class="pillar-card__overlay"></div><!-- /.pillar-card__overlay -->
					<div class="pillar-card__content">
						<div class="pillar-card__icon-box">
							<span class="pillar-card__icon">
								<i class="icon-crescent-moon"></i>
							</span><!-- /.pillar-card__icon -->
						</div><!-- /.pillar-card__icon-box -->
						<h3 class="pillar-card__title">Sportsmanship</h3><!-- /.pillar-card__title -->
						<div class="pillar-card__image">
							<img src="{{ asset('frontend/assets/images/pillar/pillar-1-3.jpg') }}" alt="Fasting">
						</div><!-- /.pillar-card__image -->
					</div><!-- /.pillar-card__content -->
				</div><!-- /.pillar-card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="300ms">
				<div class="pillar-card pillar-card--4">
					<div class="pillar-card__overlay"></div><!-- /.pillar-card__overlay -->
					<div class="pillar-card__content">
						<div class="pillar-card__icon-box">
							<span class="pillar-card__icon">
								<i class="icon-kaaba"></i>
							</span><!-- /.pillar-card__icon -->
						</div><!-- /.pillar-card__icon-box -->
						<h3 class="pillar-card__title">Supporting Growth</h3><!-- /.pillar-card__title -->
						<div class="pillar-card__image">
							<img src="{{ asset('frontend/assets/images/pillar/pillar-1-4.jpg') }}" alt="Hajj">
						</div><!-- /.pillar-card__image -->
					</div><!-- /.pillar-card__content -->
				</div><!-- /.pillar-card -->
			</div><!-- /.item -->
			<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="400ms">
				<div class="pillar-card pillar-card--5">
					<div class="pillar-card__overlay"></div><!-- /.pillar-card__overlay -->
					<div class="pillar-card__content">
						<div class="pillar-card__icon-box">
							<span class="pillar-card__icon">
								<i class="icon-pure-water"></i>
							</span><!-- /.pillar-card__icon -->
						</div><!-- /.pillar-card__icon-box -->
						<h3 class="pillar-card__title">Sports</h3><!-- /.pillar-card__title -->
						<div class="pillar-card__image">
							<img src="{{ asset('frontend/assets/images/pillar/pillar-1-5.jpg') }}" alt="Zakat">
						</div><!-- /.pillar-card__image -->
					</div><!-- /.pillar-card__content -->
				</div><!-- /.pillar-card -->
			</div><!-- /.item -->
		</div><!-- /.pillar-one__carousel -->
	</div><!-- /.container -->
</section><!-- /.pillar-one section-space-top -->


<div class="testimonials-three section-space">
	<div class="container">
		<div class="sec-title sec-title--center wow fadeInUp" data-wow-duration="1500ms">
			<div class="sec-title__top">
				<h6 class="sec-title__tagline">Testimonials</h6><!-- /.sec-title__tagline -->
			</div><!-- /.sec-title__top -->
			<h3 class="sec-title__title">What They are Talking <br> About MCC</h3><!-- /.sec-title__title -->
		</div><!-- /.sec-title -->
		<div class="testimonials-three__carousel cherito-owl__carousel cherito-owl__carousel--with-shaow cherito-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
	"items": 1,
	"margin": 10,
	"loop": true,
	"smartSpeed": 700,
	"nav": false,
	"dots": true,
	"navText": ["<i class=\"icon-left-arrow\"></i>","<i class=\"icon-right-arrow\"></i>"],
	"autoplay": true,
	"responsive": {
		"0": {
			"items": 1,
			"margin": 10,
			"nav": true,
			"dots": false
		},
		"768": {
			"items": 2,
			"margin": 30
		},
		"1200": {
			"items": 3,
			"margin": 30,
			"dots": false
		}
	}
}'>


@foreach ($testimonials as $item)
<div class="item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
	<div class="testimonial-card-two">
		<div class="testimonial-card-two__icon-box">
			<span class="testimonial-card-two__icon"><i class="icon-quote"></i></span>
			<div class="testimonial-card-two__icon-box__shape"></div><!-- /.testimonial-card-two__icon-box__shape -->
		</div><!-- /.testimonial-card-two__icon-box -->
		<div class="testimonial-card-two__content">
			<div class="testimonial-card-two__content__inner">
				<div class="cherito-ratings">
					<!-- Rating stars based on the rating value -->
					@for ($i = 1; $i <= 5; $i++)
						@if ($i <= $item->rating)
							<span class="cherito-ratings__icon">⭐</span> <!-- Full star for the rating -->
						@else
							<span class="cherito-ratings__icon">☆</span> <!-- Empty star for the remaining -->
						@endif
					@endfor
				</div><!-- /.cherito-ratings -->
				<p class="testimonial-card-two__quote">{{$item->review_details}}</p><!-- /.testimonial-card-two__quote -->
				<div class="testimonial-card-two__identity">
					<div class="testimonial-card-two__identity__inner">
						<img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->name}}" class="testimonial-card-two__image">
						<div class="testimonial-card-two__identity__info">
							<h3 class="testimonial-card-two__name">{{$item->name}}</h3><!-- /.testimonial-card-two__name -->
							<p class="testimonial-card-two__designation">{{$item->designation}}</p><!-- /.testimonial-card-two__designation -->
						</div><!-- /.testimonial-card-two__identity__info -->
					</div><!-- /.testimonial-card-two__identity__inner -->
				</div><!-- /.testimonial-card-two__identity -->
			</div><!-- /.testimonial-card-two__content__inner -->
		</div><!-- /.testimonial-card-two__content -->
	</div><!-- /.testimonial-card-two -->
</div><!-- /.item -->
@endforeach

	
		</div><!-- /.testimonials-three__carousel -->
	</div><!-- /.container -->
</div><!-- /.testimonials-three section-space -->

<section class="cta-two">
	<div class="cta-two__image">
		<img src="{{ asset('frontend/assets/images/resources/cta-2-1.jpg') }}" alt="cta">
	</div><!-- /.cta-two__image -->
	<div class="container">
		<div class="cta-two__content">
			<div class="cta-two__sec-title wow fadeInUp" data-wow-duration="1500ms">
				<h2 class="cta-two__title">We believe creativity, sportsmanship, engagement, and innovation can unite people and build a stronger, connected community.</h2><!-- /.cta-two__title -->
			</div><!-- /.cta-two__sec-title -->
			<div class="cta-two__button wow fadeInUp" data-wow-duration="1500ms">
				<a href="/contact" class="cherito-btn cherito-btn--primary">
					<span class="cherito-btn__text">Contact Us</span>
					<span class="cherito-btn__hover cherito-btn__hover--1"></span>
					<span class="cherito-btn__hover cherito-btn__hover--2"></span>
					<span class="cherito-btn__hover cherito-btn__hover--3"></span>
					<span class="cherito-btn__hover cherito-btn__hover--4"></span>
					<span class="cherito-btn__hover cherito-btn__hover--5"></span>
				</a><!-- /.cherito-btn -->
			</div><!-- /.cta-two__button -->
		</div><!-- /.cta-two__content -->
	</div><!-- /.container -->
	<div class="cta-two__shape">
		<img src="{{ asset('frontend/assets/images/shapes/cta-shape-2-1.png') }}" alt="shape" class="cta-two__shape__1">
		<img src="{{ asset('frontend/assets/images/shapes/cta-shape-2-2.png') }}" alt="shape" class="cta-two__shape__2">
		<img src="{{ asset('frontend/assets/images/shapes/cta-shape-2-3.png') }}" alt="shape" class="cta-two__shape__3">
	</div><!-- /.cta-two__shape -->
</section><!-- /.cta-two -->

<section class="funfact-two">
	<div class="container">
		<div class="row">
			<div class="funfact-two__image wow fadeInUp" data-wow-duration="1500ms">
				<img src="{{ asset('frontend/assets/images/resources/funfact-2-1.jpg') }}" alt="funfact">
			</div><!-- /.funfact-two__image -->
			<div class="funfact-two__content">
				<div class="funfact-two__grid">
					<div class="funfact-card wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
						<div class="funfact-card__inner">
							<span class="funfact-card__icon">
								<i class="icon-user-2"></i>
							</span><!-- /.funfact-card__icon -->
							<div class="funfact-card__content">
								<h3 class="funfact-card__count count-box">
									<span class="count-text" data-stop="26" data-speed="1500">0</span>
									<span>K</span>
								</h3><!-- /.funfact-card__count -->
								<p class="funfact-card__text">Team Support</p><!-- /.funfact-card__text -->
							</div><!-- /.funfact-card__content -->
						</div><!-- /.funfact-card__inner -->
					</div><!-- /.funfact-card -->
					<div class="funfact-card wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
						<div class="funfact-card__inner">
							<span class="funfact-card__icon">
								<i class="icon-charity"></i>
							</span><!-- /.funfact-card__icon -->
							<div class="funfact-card__content">
								<h3 class="funfact-card__count count-box">
									<span class="count-text" data-stop="360" data-speed="1500">0</span>
									<span>K</span>
								</h3><!-- /.funfact-card__count -->
								<p class="funfact-card__text">Total Donation</p><!-- /.funfact-card__text -->
							</div><!-- /.funfact-card__content -->
						</div><!-- /.funfact-card__inner -->
					</div><!-- /.funfact-card -->
					<div class="funfact-card wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
						<div class="funfact-card__inner">
							<span class="funfact-card__icon">
								<i class="icon-help"></i>
							</span><!-- /.funfact-card__icon -->
							<div class="funfact-card__content">
								<h3 class="funfact-card__count count-box">
									<span class="count-text" data-stop="80" data-speed="1500">0</span>
									<span>M</span>
								</h3><!-- /.funfact-card__count -->
								<p class="funfact-card__text">Clients Help</p><!-- /.funfact-card__text -->
							</div><!-- /.funfact-card__content -->
						</div><!-- /.funfact-card__inner -->
					</div><!-- /.funfact-card -->
					<div class="funfact-card wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
						<div class="funfact-card__inner">
							<span class="funfact-card__icon">
								<i class="icon-book"></i>
							</span><!-- /.funfact-card__icon -->
							<div class="funfact-card__content">
								<h3 class="funfact-card__count count-box">
									<span class="count-text" data-stop="320" data-speed="1500">0</span>
									<span>K</span>
								</h3><!-- /.funfact-card__count -->
								<p class="funfact-card__text">Poor Educate</p><!-- /.funfact-card__text -->
							</div><!-- /.funfact-card__content -->
						</div><!-- /.funfact-card__inner -->
					</div><!-- /.funfact-card -->
				</div><!-- /.funfact-two__grid -->
				<div class="funfact-two__logo">
					<div class="funfact-two__logo__inner">
						<img src="{{ asset('frontend/assets/images/shapes/funfact-logo-2-1.png') }}" alt="logo">
					</div><!-- /.funfact-two__logo__inner -->
				</div><!-- /.funfact-two__logo -->
			</div><!-- /.funfact-two__content -->
		</div><!-- /.row -->
	</div><!-- /.container -->
</section><!-- /.funfact-two -->



	<section class="blog-page section-space">
		<div class="container">
			<div class="row gutter-y-30">
				@foreach ($blogs as $item)
				
					<div class="col-lg-4 col-md-6">
						<div class="blog-card-five wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='00ms'>
							<div class="blog-card-five__image">
								<img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->title}}">
								<a href="/blog/{{$item->slug}}" class="blog-card-five__image__link"><span class="sr-only">{{$item->title}}</span></a>
							</div><!-- /.blog-card-five__image -->
							<div class="blog-card-five__content">
								<div class="blog-card-five__meta d-none">
									<div class="blog-card-five__admin">
										<div class="blog-card-five__admin__image">

											<img src="{{ URL::asset('storage/app/public/'.$item->image.'')}}" alt="{{$item->title}}">
										</div><!-- /.blog-card-five__admin__image -->
										<div class="blog-card-five__admin__content">
											<h3 class="blog-card-five__admin__name"><a href="#">Darrell Steward</a></h3>
											<p class="blog-card-five__admin__designation">Admin</p>
										</div><!-- /.blog-card-five__admin__content -->
									</div><!-- /.blog-card-five__admin -->
									<div class="blog-card-five__date">
										<div class="blog-card-five__date__1">10</div><!-- /.blog-card-five__date__1 -->
										<div class="blog-card-five__date__2">
											<div>
												<span>Mar,</span>
												<span>2024</span>
											</div>
										</div><!-- /.blog-card-five__date__2 -->
									</div><!-- /.blog-card-five__date -->
								</div><!-- /.blog-card-five__meta -->
								<h3 class="blog-card-five__title"><a href="/blog/{{$item->slug}}">{{$item->title}}</a></h3><!-- /.blog-card-five__title -->
								<p class="blog-card-five__text">{{$item->short_description}}</p><!-- /.blog-card-five__text -->
								<div class="blog-card-five__button">
									<a href="/blog/{{$item->slug}}" class="cherito-btn">
										<span class="cherito-btn__text">Read More</span>
										<span class="cherito-btn__hover cherito-btn__hover--1"></span>
										<span class="cherito-btn__hover cherito-btn__hover--2"></span>
										<span class="cherito-btn__hover cherito-btn__hover--3"></span>
										<span class="cherito-btn__hover cherito-btn__hover--4"></span>
										<span class="cherito-btn__hover cherito-btn__hover--5"></span>
									</a><!-- /.cherito-btn -->
								</div><!-- /.blog-card-five__button -->
							</div><!-- /.blog-card-five__content -->
						</div><!-- /.blog-card-five -->
					</div><!-- /.col-lg-4 col-md-6 -->
				@endforeach

			</div><!-- /.row -->
		</div><!-- /.container -->
	</section><!-- /.blog-page section-space  -->








@endsection