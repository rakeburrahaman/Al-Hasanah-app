Hey Admin,
<br><br>
A new lead has been registered in your subscription list.<br><br>
Email address: {{$email_data['email']}}

Thank you!
<br>
System 
