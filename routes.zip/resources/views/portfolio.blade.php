@extends('layouts.master')
@section('main_content')


<style>
    /* General Styles */
    body {
        font-family: "Poppins", sans-serif;
        background: #f0f0f0;
        margin: 0;
        padding: 0;
    }

    /* Section Styling */
    .s101 {
        padding: 50px 0;
        text-align: center;
    }
    .s201 {
        padding: 50px 0 120px 0;
        text-align: center;
        background-color: #fff;
    }


    /* Grid Layout */
    .s103 {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        /* grid-template-rows: repeat(2, 1fr); */
        gap: 20px;
        padding: 20px;
        justify-content: center;
        align-items: center;
    }

    /* Image & Video Styling */
    .image-container {
        position: relative;
        overflow: hidden;
        border-radius: 15px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .image-container:hover {
        transform: scale(1.08);
        box-shadow: 0 12px 25px rgba(0, 0, 0, 0.3);
    }

    .image-container img {
        width: 100%;
        display: block;
        border-radius: 15px;
        transition: transform 0.3s ease-in-out;
    }

    .image-container:hover img {
        transform: scale(1.1);
    }

    /* Image Overlay Heading */
    .image-heading {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: white;
        font-size: 24px;
        font-weight: bold;
        text-transform: uppercase;
        text-align: center;
        background: rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(10px);
        padding: 12px 24px;
        border-radius: 10px;
        opacity: 0;
        transition: opacity 0.4s ease-in-out;
    }

    .image-container:hover .image-heading {
        opacity: 1;
    }

    /* Video Styling */
    .s103 video {
        width: 100%;
        border-radius: 15px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .s103 video:hover {
        transform: scale(1.05);
        box-shadow: 0 12px 25px rgba(0, 0, 0, 0.3);
    }

    /* Buttons */
    .more-btn {
        display: inline-block;
        padding: 12px 30px;
        background: linear-gradient(135deg, #dc3545, #ee403d);
        color: white;
        border: none;
        border-radius: 30px;
        cursor: pointer;
        font-size: 18px;
        font-weight: bold;
        transition: background 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
        text-transform: uppercase;
    }

    .more-btn:hover {
        background: linear-gradient(135deg, #b9b9b7, #b9b9b1);
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(118, 66, 66, 0.6);
    }
</style>
@php
@endphp

<section class="s101">
    <div class="container">
        <div class="row">

            @foreach ($data as $item)
            <div class="col-md-4 mt-5">
                <a href="/portfolio-details/{{ $item->id }}" class="image-container">
                    <img src="{{ asset('frontend/assets/images/about/design2.jpg') }}" alt="img">
                    <h2 class="image-heading">{{ $item->title }}</h2>
                </a>            
            </div>
            @endforeach

        </div>
     

        <div class="product-pagination-area mt--20">
            <button class="prev"><i class="far fa-long-arrow-left"></i></button>
            <button class="number active">01</button>
            <button class="number">02</button>
            <button class="skip-number">---</button>
            <button class="number">07</button>
            <button class="number">08</button>
            <button class="next"><i class="far fa-long-arrow-right"></i></button>
        </div>


        
    </div>
</section>

<section class="s201">
    <div class="container">
        <div class="s102">
                
           
        </div>
    </div>
</section>


@endsection