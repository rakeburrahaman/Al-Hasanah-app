@extends('layouts.master')
@section('main_content')

<!--================= About Us Start Here =================-->
<section class="about-us-area pt-120 pb-75 pt-md-60 pb-md-15 pt-xs-50 pb-xs-10">
    <div class="container">
        <div class="image-section">
            <div class="row">
                <div class="col-lg-6">
                    <div class="image-1">
                        <img src="{{ asset('/images'.$item->image) }}" alt="img">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="image-2">
                        <img src="{{ asset('/images'.$item->image) }}" alt="img">
                    </div>
                </div>
            </div>
            <div class="section-title">
                <div class="title-inner">
                    <div class="wrapper">
                        <div class="sub-content">
                            <img class="line-1" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="">
                            <span class="sub-text">title</span>
                            <img class="line-2" src="{{ asset('frontend/assets/images/banner/wvbo-icon.png') }}" alt="">
                        </div>
                        <h2 class="title">{{$item->title}}</h2>
                    </div>
                </div>
            </div>
            <div class="row" style="padding-top: 20px;">
                <div class="col-lg-4">
                    <div class="image-1">
                        <img src="{{ asset('/images'.$item->image) }}" alt="img">
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="image-2">
                        <img src="{{ asset('/images'.$item->image) }}" alt="img">
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="image-2">
                        <img src="{{ asset('/images'.$item->image) }}" alt="img">
                    </div>
                </div>
            </div>
        </div>
        <div class="section-text">
            <div class="row">
                <div class="col-lg-8">
                    <h3>Description</h3>
                    <p class="description"></p>
                </div>
                <div class="col-lg-4">
                    <div class="service-list" style="border: 1px solid #ebeaea; padding: 20px;">
                        <ul>
                            <H4>Client:</H4>
                            <li><a href="#">ACI</a></li>
                            <h4>Date:</h4>
                            <li><a href="#">April 14, 2023</a></li>
                            <h4>Category:</h4>
                            <li><a href="#">Office Interior</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<!--================= About Us End Here =================-->

<!--================= Team Area Start Here =================-->
<div class="team-area">
    <div class="container">
        <div class="slider-div">
            <div class="swiper rts-cmmnSlider-over2" data-swiper="pagination">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="team-wraper">
                            <div class="team-thumb">
                                <a href="#"><img src="{{ asset('/images'.$item->image) }}" alt="collection-image"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--================= Team Area End Here =================-->

<!--================= Feature Area Start Here =================-->
<div class="rts-video-section">
    <div class="container">
        <div class="video-section-inner">
            <div class="rts-video">
                <div class="about-video-wrapper">
                    <a href="{{ '/videos'. $item->video }}" class="popup-videos" target="_blank" type="video/mp4">
                        <i class="rt-play"></i>
                    </a>

                    <!-- Video Embed -->
                    <video controls>
                        <source src="{{ '/videos'. $item->video }}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>
            </div>
        </div>
    </div>
</div>


<!--================= Feature Area End Here =================-->

@endsection