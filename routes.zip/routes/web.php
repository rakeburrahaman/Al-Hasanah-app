<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\OptionController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\LeadController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DataMigrationController; 
use App\Http\Controllers\ReportingController;
use App\Http\Controllers\UsersExportController;
use App\Http\Controllers\CartController; 
use App\Http\Controllers\ContactController; 
use App\Http\Controllers\PostController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductCategoryController;
use App\Http\Controllers\PortfolioController;
use App\Http\Controllers\AnnouncementController;
use App\Http\Controllers\CaseStudyController;
use App\Http\Middleware\admin;
use App\Http\Middleware\user;
use App\Models\Page;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

 
Route::get('/', [HomeController::class, 'index']);
Route::get('/about', [HomeController::class, 'about']);
Route::get('/portfolio', [HomeController::class, 'portfolio']);
Route::get('/portfolio-details/{id}', [PortfolioController::class, 'show']);
Route::get('/shop', [HomeController::class, 'shop']);
Route::get('/product-details', [HomeController::class, 'productDetails']);
Route::get('/contact', [ContactController::class, 'showContactPage']);




// Route::get('/blog', [HomeController::class, 'blog']);

// Route::get('/faqs', [HomeController::class, 'faqs']);
Route::get('/chat', [HomeController::class, 'chat']);
Route::get('/privacy-policy', [HomeController::class, 'privacy']);
Route::get('/security', [HomeController::class, 'security']);
Route::get('/accessibility', [HomeController::class, 'accessibility']);
Route::view('contact', 'contact');
Route::view('about-us', 'about');
Route::view('my-account', 'my_account');
Route::view('instructors', 'instructors');
Route::view('faq', 'faq');

Route::view('press', 'press');
Route::get('blog',[BlogController::Class,'index']);
Route::get('/blog/{slug}',[BlogController::Class,'show']);
Route::get('/program', [ProgramController::class, 'program']);
Route::get('/program/{slug}', [ProgramController::class, 'show']);
// Route::get('page/{id}',[PageController::Class,'show']);

Route::get('404', function () {
    return view('404');  
});
Route::get('maintenance', function () {
    return view('under_construction');  
});
Route::post('/save_contact', [ContactController::class, 'store']);
Route::post('/save_donetion', [ContactController::class, 'donetion']);

Route::get('/classes', [ClassController::class, 'classes']); 
Route::get('class/{id}', [ClassController::class, 'show']);
Route::get('/events', [EventController::class, 'events']);
Route::get('event/{id}', [EventController::class, 'show']);
Route::post('store_email', [EmailSubscriptionController::class, 'store']);


Route::get('/signup', function () {
    return view('signup');
})->name('signup');

Route::get('/signin', function () {
    //dd(session('user.user_type'));
    if(session('user.user_type') == 'User'){
        if(session('source')=='cart'){
            return redirect('/checkout');
        }
        return redirect('/');
    }
    else if(session('user.user_type') == 'Admin'){
        return redirect('/admin'); 
    }
    return view('signin');
})->name('signin');

Route::get('/login', function () {
//     dd(session('user.user_type'));
//     if(session('user.user_type') == 'User'){
//         if(session('source')=='cart'){
//             return redirect('/checkout');
//         }
//         return redirect('/');
//     }
//     else if(session('user.user_type') == 'Admin'){
//         return redirect('/admin');
//     }
    return view('user_login');
});


Route::get('/dashboard', function(){
    if(session('user.user_type') == 'User'){
        return view('home');
    }
    else if(session('user.user_type') == 'Admin'){
        return redirect('/admin');
    }
    return redirect('/signin')->name('signin');
});

Route::get('/admin', function(){
    if(session('user.user_type') == 'Admin'){
        return view('admin.index');
    }
    return redirect('/signin')->name('signin');
});

Route::get('logout', [UserController::class, 'logout'])->name('logout');
Route::get('no-access', function(){
    return redirect('signin');
});
Route::view('contact', 'contact');
Route::view('test', 'layouts/test');
Route::post('contact_form', [EmailSubscriptionController::class, 'contactForm']);

/*user section*/
Route::post('create_user', [UserController::class, 'store']);
//Route::view('signin', 'signin')->name('signin');
Route::post('access-user', [UserController::class, 'signin']);
Route::view('main', 'home_main');
Route::get('verify', [UserController::class, 'verifyUser'])->name('verify.user');
Route::post('reset-password', [UserController::class, 'resetPassword']);
Route::get('reset', [UserController::class, 'resetPass'])->name('reset');
Route::view('new-password', 'new_password')->name('newPassword');
Route::post('new-password-store', [UserController::class, 'newPasswordStore']);


//user
Route::middleware([user::class])->group(function () {   
    // resume section
    Route::get('profile', [UserController::class, 'edit']);
    Route::post('update-user', [UserController::class, 'update']);

    Route::post('update_user', [UserController::class, 'update_user']);
    
    //customer
    Route::get('/my-account', [UserController::class,'myAccount']); 
   
});

Route::get('/documentation', function(){
    return view('admin.documentation');    
}); 

Route::get('/view-report', [LeadController::class, 'viewReportGet'])->name('view-report');

Route::get('/product-details/{slug}', [ProductController::class, 'show'])->name('product.show');


/************************************************************
 //admin section
 ************************************************************/

Route::middleware([admin::class])->group(function () { 
    
    // Route::get('/admin', function(){
    //     return view('admin.index'); 
    // }   
    Route::get('/admin', [AdminController::class, 'index']);

    
    Route::get('/report-center', function(){ 
        return view('admin/lead/report');  
    });  
    Route::get('/dashboard', [LeadController::class, 'dashboard']);
    Route::get('/my-dashboard', [LeadController::class, 'myDashboard']);
    Route::get('/add-lead', [LeadController::class, 'create']);
    Route::post('/save-lead', [LeadController::class, 'store']);
    Route::get('/leads', [LeadController::class, 'index']);
    Route::get('/my-account', [LeadController::class, 'index']);
    
    Route::post('/view-report', [LeadController::class, 'viewReport']);
    Route::post('/reports', [LeadController::class, 'reports']);   
    
    //Route::get('/leads/excel', 'AdminController@excel')->name('leads.excel');
    //Route::post('/download-excel', [LeadController::class, 'excelFilter']);
    Route::post('/download-excel', [LeadController::class, 'exportLead']);
    Route::get('leads/export/', [LeadController::class, 'export']);
    Route::get('users/export/', [UsersExportController::class, 'export']);


    Route::get('settings', [SettingController::class, 'index']);
    Route::get('settings1', [SettingController::class, 'index1']);
    Route::get('resetall', [SettingController::class, 'reset']);
    Route::post('update_settings', [SettingController::class, 'update']);

    Route::get('options', [OptionController::class, 'index']);
    Route::get('add-option', [OptionController::class, 'create']);
    Route::post('save-option', [OptionController::class, 'store']);
    Route::post('update_options', [OptionController::class, 'update']);
    Route::get('/edit-option/{id}', [UserController::class, 'edit']);
    Route::post('/update_option', [OptionController::class, 'update']);

   

    Route::get('profile', [UserController::class, 'edit']);
    Route::post('update-user', [UserController::class, 'update']);    
    Route::post('update_user_type', [UserController::class, 'update_user_type']);
    
    Route::view('resume-list', 'resume_list');

    Route::get('users', [UserController::class, 'index']);
    Route::get('/add-user', [UserController::class, 'create']);
    Route::post('/save_user', [UserController::class, 'storeUser'])->name('save_user');
    Route::post('/upload_user', [UserController::class, 'upload'])->name('upload_user');
    Route::get('/edit-user/{id}', [UserController::class, 'edit']);
    Route::post('/update_user', [UserController::class, 'update']);
    Route::get('/delete-user/{id}', [UserController::class, 'destroy']);

    /*product*/
    Route::get('/products', [ProductController::class, 'products']); 
    Route::get('/services', [ProductController::class, 'services']); 
    Route::get('/add-product', [ProductController::class, 'create']);
    Route::get('/add-product2', [ProductController::class, 'create2']);
    
    Route::get('/add-product3', [ProductController::class, 'create3']);
    Route::post('/generate_product', [ProductController::class, 'generate_product'])->name('generate_product');
         
     
      Route::post('/save_product', [ProductController::class, 'store'])->name('save_product');
      Route::post('/upload_product', [ProductController::class, 'upload'])->name('upload_product');
      Route::get('/edit-product/{id}', [ProductController::class, 'edit'])->name('edit-product');
      Route::get('/edit-service/{id}', [ProductController::class, 'editService']);
      Route::post('/update_product', [ProductController::class, 'update']);
      Route::get('/delete-product/{id}', [ProductController::class, 'destroy']);
      Route::post('/upload_price', [ProductController::class, 'updatePrice'])->name('update_price');
      Route::get('/add-stock/{id}', [ProductController::class, 'addStock']);
      Route::get('/product-stock/{id}', [ProductController::class, 'productStock']);
      Route::get('/product-stock-details/{id}', [ProductController::class, 'productStockDetails']);
     


    /*product_category*/
    Route::get('/product-categories', [ProductCategoryController::class, 'index']);
    Route::post('/store_product_category', [ProductCategoryController::class, 'store']);
    Route::post('/update_product_category', [ProductCategoryController::class, 'update']);
    Route::get('/delete_product_category/{id}', [ProductCategoryController::class, 'destroy']);
    Route::get('/delete_product_sub_category/{id}', [ProductCategoryController::class, 'destroySubCat']); 

    // data migration
    // Route::get('/g_product', [DataMigrationController::class, 'g_product']); 
    // Route::get('/g_cat', [DataMigrationController::class, 'g_cat']); 
    // Route::get('/g_data_lookup', [DataMigrationController::class, 'g_data_lookup']); 
    //Route::get('/g_company_acc', [DataMigrationController::class, 'g_company_acc']); 
    Route::get('/g_inv_id', [DataMigrationController::class, 'g_inv_id']); 


    
     /*reporting*/    
     Route::get('sales-report', function () {
        return view('admin/report_sales'); 
    });
    Route::post('/report', [ReportingController::class, 'generateReport']);   

    Route::get('/company-ledger/{id}', [ReportingController::class, 'companyLedger']); 

     /*customer*/
     Route::get('/customers', [CustomerController::class, 'index']);
     Route::get('/add-customer', [CustomerController::class, 'create']);
     Route::post('/save_customer', [CustomerController::class, 'store']);
     Route::get('/edit-customer/{id}', [CustomerController::class, 'edit']);
     Route::get('/customer-details/{id}', [CustomerController::class, 'show']);
     Route::post('/update_customer', [CustomerController::class, 'update']);
     Route::get('/delete-customer/{id}', [CustomerController::class, 'destroy']);     

     /*case-study*/
     Route::get('/case-studies', [CaseStudyController::class, 'index']);
     Route::get('/add-case-study', [CaseStudyController::class, 'create']);
     Route::post('/save_case_study', [CaseStudyController::class, 'store']);
     Route::get('/edit-case-study/{id}', [CaseStudyController::class, 'edit']);
     Route::get('/case-study-details/{id}', [CaseStudyController::class, 'show']);
     Route::post('/update_case_study', [CaseStudyController::class, 'update']);
     Route::get('/delete-case-study/{id}', [CaseStudyController::class, 'destroy']);   

    //  *cart*//
    Route::get('/cart', [CartController::class, 'index']);
    Route::post('cart/add/{productId}', [CartController::class, 'add'])->name('cart.add');
    Route::post('cart/remove/{productId}', [CartController::class, 'remove'])->name('cart.remove');
    Route::post('cart/update/{productId}', [CartController::class, 'update'])->name('cart.update');

     /*Contact*/
     Route::get('/contact', [ContactController::class, 'showForm'])->name('contact.show');
    
     //Portfolio//
     Route::get('/portfolios', [PortfolioController::class, 'index']);
     Route::get('/all_portfolios', [PortfolioController::class, 'index']);
     Route::get('/add-portfolio', [PortfolioController::class, 'create']);
     Route::post('/save_portfolio', [PortfolioController::class, 'store'])->name('save_portfolio');
     Route::get('/edit-portfolio/{id}', [PortfolioController::class, 'edit']);
     Route::post('/update_portfolio', [PortfolioController::class, 'update']);
     Route::get('/delete-portfolio/{id}', [PortfolioController::class, 'destroy']);


    //  /announcement/
     Route::get('/announcements', [AnnouncementController::class, 'index']);
     Route::get('/add-announcement', [AnnouncementController::class, 'create']);
     Route::post('/save_announcement', [AnnouncementController::class, 'store']);
     Route::get('/edit-announcement/{id}', [AnnouncementController::class, 'edit']);
     Route::get('/case-study-details/{id}', [AnnouncementController::class, 'show']);
     Route::post('/update_announcement', [AnnouncementController::class, 'update']);
    //  Route::get('/delete-case-study/{id}', [AnnouncementController::class, 'destroy']);
     
});
 